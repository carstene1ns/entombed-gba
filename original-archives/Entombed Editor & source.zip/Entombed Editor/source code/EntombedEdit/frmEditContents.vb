﻿Public Class frmEditContents
    Dim intContainerType As Integer ' Will be 23 or 25 for chest or vase
    Dim intSelectedType As Integer ' Contents type selected in combobox
    Dim objContents As MapObject ' Stores a persistent copy of this object's current contents data

    Private Sub cmdOK_Click(sender As System.Object, e As System.EventArgs) Handles cmdOK.Click
        Me.Hide()
    End Sub

    Private Sub frmEditContents_Load(sender As Object, e As System.EventArgs) Handles Me.Load

        ' Get the container type
        intContainerType = CMap.GetTileData(CMap.m_pntSelectedTilePos.X, _
                       CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer).m_intType

        ' Fill the contents type combo box
        cmbType.Items.Clear()
        ' Allow different contents depending on whether this is a chest or a vase
        If intContainerType = 23 Then
            ' Chest: Ankh, bow, coin, hourglass, key, quiver
            cmbType.Items.Add("Ankh") '17
            cmbType.Items.Add("Bow") '18
            cmbType.Items.Add("Coin") '19
            cmbType.Items.Add("Hourglass") '20
            cmbType.Items.Add("Key") '21
            cmbType.Items.Add("Quiver") '22
        Else
            ' Vase: Spears, Ankh, bow, coin, hourglass, key, quiver, snake, sphinx
            '       platform2, wall.
            cmbType.Items.Add("Spears") '16
            cmbType.Items.Add("Ankh") '17
            cmbType.Items.Add("Bow") '18
            cmbType.Items.Add("Coin") '19
            cmbType.Items.Add("Hourglass") '20
            cmbType.Items.Add("Key") '21
            cmbType.Items.Add("Quiver") '22
            cmbType.Items.Add("Snake") '26
            cmbType.Items.Add("Sphinx") '27
            cmbType.Items.Add("Switch") '30
            cmbType.Items.Add("Platform2") '32
            cmbType.Items.Add("Wall1") '1
            cmbType.Items.Add("Wall2") '2
        End If

        ' Get the contents values for the selected container tile
        objContents = CMap.GetTileData(CMap.m_pntSelectedTilePos.X, _
                       CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer).m_contents
        If objContents Is Nothing = False Then
            If intContainerType = 23 Then
                ' Chest
                cmbType.SelectedIndex = objContents.m_intType - 17
            Else
                ' Urn
                Select Case objContents.m_intType
                    Case 8 To 22
                        cmbType.SelectedIndex = objContents.m_intType - 16
                    Case 26 ' Snake
                        cmbType.SelectedIndex = 7
                    Case 27 ' Sphinx
                        cmbType.SelectedIndex = 8
                    Case 30 ' Switch
                        cmbType.SelectedIndex = 9
                    Case 32 ' Platform2
                        cmbType.SelectedIndex = 10
                    Case 1 ' Wall1
                        cmbType.SelectedIndex = 11
                    Case 1 ' Wall2
                        cmbType.SelectedIndex = 12
                End Select
            End If
        End If

        ' Get any properties into the combobox
        GetProperties()

        ' Set the description label
        lblDescription.Text = If(intContainerType = 23, "Chest", "Urn") & " - X: " & _
         CStr(CMap.m_pntSelectedTilePos.X) & " - Y: " & CStr(CMap.m_pntSelectedTilePos.Y)

        ' Disable the "Set" buttin for contents type.
        cmdSetType.Enabled = False

    End Sub

    Private Sub GetProperties()
        ' Load the property values for the container's object type.
        Dim n As Integer

        cmbProperties.Items.Clear()
        cmbProperties.Text = ""
        txtProperty.Text = ""

        If objContents.m_arrintPropertyValues Is Nothing = False Then
            For n = 0 To objContents.m_arrintPropertyValues.Count - 1
                cmbProperties.Items.Add(CTileMap.m_PropertyNames(objContents.m_intType)(n))
            Next n
            ' Select the first property and place its value in the text box.
            cmbProperties.SelectedIndex = 0
            txtProperty.Text = objContents.m_arrintPropertyValues(0)
        End If
    End Sub

    Private Sub cmdSetType_Click(sender As System.Object, e As System.EventArgs) Handles cmdSetType.Click

        ' Replace the contents type with the new type
        objContents = New MapObject(intSelectedType)
        CMap.SetContentsData(CMap.m_pntSelectedTilePos.X, _
         CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer, objContents)

        ' Get any properties into the combobox
        GetProperties()

        ' Disable the "Set" buttin for contents type.
        cmdSetType.Enabled = False

    End Sub

    Private Sub cmbType_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbType.SelectedIndexChanged
        ' If the selected type is the same as the current type, disable the "Set" buttton.

        If intContainerType = 23 Then
            ' Chest
            ' Get the selected contents type value
            intSelectedType = cmbType.SelectedIndex + 17
            ' If the selected type is different than the current type then enable the
            ' "Set" button, otherwise disable it
            If intSelectedType = objContents.m_intType Then
                cmdSetType.Enabled = False
            Else
                cmdSetType.Enabled = True
            End If
        Else
            ' Urn
            ' Get the selected contents type value
            Select Case cmbType.SelectedIndex
                Case Is < 7
                    ' Spears & collectables
                    intSelectedType = cmbType.SelectedIndex + 16
                Case 7 To 8
                    ' Enemies
                    intSelectedType = cmbType.SelectedIndex + 19
                Case 9
                    ' Switch
                    intSelectedType = 30
                Case 10
                    ' Platform2
                    intSelectedType = 32
                Case 11
                    ' Wall1
                    intSelectedType = 1
                Case 12
                    ' Wall2
                    intSelectedType = 2
            End Select
            
            ' If the selected type is different than the current type then enable the
            ' "Set" button, otherwise disable it
            If intSelectedType = objContents.m_intType Then
                cmdSetType.Enabled = False
            Else
                cmdSetType.Enabled = True
            End If
        End If
    End Sub

    Private Sub cmbProperties_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles cmbProperties.SelectedIndexChanged
        ' Get the property value from objContents into the text box
        txtProperty.Text = CStr(objContents.m_arrintPropertyValues(cmbProperties.SelectedIndex))
    End Sub

    Private Sub cmdSetProperty_Click(sender As System.Object, e As System.EventArgs) Handles cmdSetProperty.Click

        ' Make sure there's a property to change
        If cmbProperties.SelectedIndex >= 0 Then
            ' Make sure the entered value is valid
            If IsNumeric(txtProperty.Text) Then
                If CInt(txtProperty.Text) >= 0 Then
                    ' Set the property
                    objContents.m_arrintPropertyValues(cmbProperties.SelectedIndex) = CInt(txtProperty.Text)
                    CMap.SetContentsData(CMap.m_pntSelectedTilePos.X, _
                     CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer, objContents)

                Else
                    ' Reload the original value into the text box
                    txtProperty.Text = objContents.m_arrintPropertyValues(cmbProperties.SelectedIndex)
                End If
            Else
                ' Reload the original value into the text box
                txtProperty.Text = objContents.m_arrintPropertyValues(cmbProperties.SelectedIndex)
            End If
        End If

    End Sub
End Class