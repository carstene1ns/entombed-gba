﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCheckpoints
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmbCheckpoints = New System.Windows.Forms.ComboBox()
        Me.lblBows = New System.Windows.Forms.Label()
        Me.txtBows = New System.Windows.Forms.TextBox()
        Me.txtArrows = New System.Windows.Forms.TextBox()
        Me.lblArrows = New System.Windows.Forms.Label()
        Me.txtSeconds = New System.Windows.Forms.TextBox()
        Me.lblSeconds = New System.Windows.Forms.Label()
        Me.txtKeys = New System.Windows.Forms.TextBox()
        Me.lblKeys = New System.Windows.Forms.Label()
        Me.cmbSequences = New System.Windows.Forms.ComboBox()
        Me.lblSequences = New System.Windows.Forms.Label()
        Me.cmdSet = New System.Windows.Forms.Button()
        Me.cmdAddSeq = New System.Windows.Forms.Button()
        Me.cmdDelSeq = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.txtPlayerYPos = New System.Windows.Forms.TextBox()
        Me.lblPlayerYPos = New System.Windows.Forms.Label()
        Me.txtPlayerXPos = New System.Windows.Forms.TextBox()
        Me.lblPlayerXPos = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.Location = New System.Drawing.Point(155, 306)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(88, 31)
        Me.cmdClose.TabIndex = 5
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'cmbCheckpoints
        '
        Me.cmbCheckpoints.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCheckpoints.FormattingEnabled = True
        Me.cmbCheckpoints.Location = New System.Drawing.Point(15, 50)
        Me.cmbCheckpoints.Name = "cmbCheckpoints"
        Me.cmbCheckpoints.Size = New System.Drawing.Size(217, 21)
        Me.cmbCheckpoints.TabIndex = 6
        '
        'lblBows
        '
        Me.lblBows.AutoSize = True
        Me.lblBows.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBows.Location = New System.Drawing.Point(12, 128)
        Me.lblBows.Name = "lblBows"
        Me.lblBows.Size = New System.Drawing.Size(42, 16)
        Me.lblBows.TabIndex = 7
        Me.lblBows.Text = "Bows"
        '
        'txtBows
        '
        Me.txtBows.Location = New System.Drawing.Point(60, 127)
        Me.txtBows.Name = "txtBows"
        Me.txtBows.Size = New System.Drawing.Size(52, 20)
        Me.txtBows.TabIndex = 8
        '
        'txtArrows
        '
        Me.txtArrows.Location = New System.Drawing.Point(191, 127)
        Me.txtArrows.Name = "txtArrows"
        Me.txtArrows.Size = New System.Drawing.Size(52, 20)
        Me.txtArrows.TabIndex = 10
        '
        'lblArrows
        '
        Me.lblArrows.AutoSize = True
        Me.lblArrows.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblArrows.Location = New System.Drawing.Point(125, 129)
        Me.lblArrows.Name = "lblArrows"
        Me.lblArrows.Size = New System.Drawing.Size(52, 16)
        Me.lblArrows.TabIndex = 9
        Me.lblArrows.Text = "Arrows"
        '
        'txtSeconds
        '
        Me.txtSeconds.Location = New System.Drawing.Point(191, 158)
        Me.txtSeconds.Name = "txtSeconds"
        Me.txtSeconds.Size = New System.Drawing.Size(52, 20)
        Me.txtSeconds.TabIndex = 14
        '
        'lblSeconds
        '
        Me.lblSeconds.AutoSize = True
        Me.lblSeconds.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSeconds.Location = New System.Drawing.Point(125, 160)
        Me.lblSeconds.Name = "lblSeconds"
        Me.lblSeconds.Size = New System.Drawing.Size(62, 16)
        Me.lblSeconds.TabIndex = 13
        Me.lblSeconds.Text = "Seconds"
        '
        'txtKeys
        '
        Me.txtKeys.Location = New System.Drawing.Point(60, 158)
        Me.txtKeys.Name = "txtKeys"
        Me.txtKeys.Size = New System.Drawing.Size(52, 20)
        Me.txtKeys.TabIndex = 12
        '
        'lblKeys
        '
        Me.lblKeys.AutoSize = True
        Me.lblKeys.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKeys.Location = New System.Drawing.Point(12, 159)
        Me.lblKeys.Name = "lblKeys"
        Me.lblKeys.Size = New System.Drawing.Size(38, 16)
        Me.lblKeys.TabIndex = 11
        Me.lblKeys.Text = "Keys"
        '
        'cmbSequences
        '
        Me.cmbSequences.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSequences.FormattingEnabled = True
        Me.cmbSequences.Location = New System.Drawing.Point(190, 190)
        Me.cmbSequences.Name = "cmbSequences"
        Me.cmbSequences.Size = New System.Drawing.Size(53, 21)
        Me.cmbSequences.TabIndex = 15
        '
        'lblSequences
        '
        Me.lblSequences.AutoSize = True
        Me.lblSequences.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSequences.Location = New System.Drawing.Point(12, 190)
        Me.lblSequences.Name = "lblSequences"
        Me.lblSequences.Size = New System.Drawing.Size(141, 16)
        Me.lblSequences.TabIndex = 16
        Me.lblSequences.Text = "Activated Sequences"
        '
        'cmdSet
        '
        Me.cmdSet.Location = New System.Drawing.Point(89, 251)
        Me.cmdSet.Name = "cmdSet"
        Me.cmdSet.Size = New System.Drawing.Size(88, 31)
        Me.cmdSet.TabIndex = 17
        Me.cmdSet.Text = "Set"
        Me.cmdSet.UseVisualStyleBackColor = True
        '
        'cmdAddSeq
        '
        Me.cmdAddSeq.Location = New System.Drawing.Point(169, 217)
        Me.cmdAddSeq.Name = "cmdAddSeq"
        Me.cmdAddSeq.Size = New System.Drawing.Size(36, 19)
        Me.cmdAddSeq.TabIndex = 18
        Me.cmdAddSeq.Text = "Add"
        Me.cmdAddSeq.UseVisualStyleBackColor = True
        '
        'cmdDelSeq
        '
        Me.cmdDelSeq.Location = New System.Drawing.Point(222, 217)
        Me.cmdDelSeq.Name = "cmdDelSeq"
        Me.cmdDelSeq.Size = New System.Drawing.Size(36, 19)
        Me.cmdDelSeq.TabIndex = 19
        Me.cmdDelSeq.Text = "Del"
        Me.cmdDelSeq.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(13, 23)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(219, 24)
        Me.lblTitle.TabIndex = 20
        Me.lblTitle.Text = "Checkpoint Location"
        '
        'txtPlayerYPos
        '
        Me.txtPlayerYPos.Location = New System.Drawing.Point(191, 92)
        Me.txtPlayerYPos.Name = "txtPlayerYPos"
        Me.txtPlayerYPos.Size = New System.Drawing.Size(52, 20)
        Me.txtPlayerYPos.TabIndex = 24
        '
        'lblPlayerYPos
        '
        Me.lblPlayerYPos.AutoSize = True
        Me.lblPlayerYPos.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayerYPos.Location = New System.Drawing.Point(125, 94)
        Me.lblPlayerYPos.Name = "lblPlayerYPos"
        Me.lblPlayerYPos.Size = New System.Drawing.Size(38, 16)
        Me.lblPlayerYPos.TabIndex = 23
        Me.lblPlayerYPos.Text = "Plr Y"
        '
        'txtPlayerXPos
        '
        Me.txtPlayerXPos.Location = New System.Drawing.Point(60, 92)
        Me.txtPlayerXPos.Name = "txtPlayerXPos"
        Me.txtPlayerXPos.Size = New System.Drawing.Size(52, 20)
        Me.txtPlayerXPos.TabIndex = 22
        '
        'lblPlayerXPos
        '
        Me.lblPlayerXPos.AutoSize = True
        Me.lblPlayerXPos.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlayerXPos.Location = New System.Drawing.Point(12, 93)
        Me.lblPlayerXPos.Name = "lblPlayerXPos"
        Me.lblPlayerXPos.Size = New System.Drawing.Size(39, 16)
        Me.lblPlayerXPos.TabIndex = 21
        Me.lblPlayerXPos.Text = "Plr X"
        '
        'frmCheckpoints
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(265, 349)
        Me.Controls.Add(Me.txtPlayerYPos)
        Me.Controls.Add(Me.lblPlayerYPos)
        Me.Controls.Add(Me.txtPlayerXPos)
        Me.Controls.Add(Me.lblPlayerXPos)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.cmdDelSeq)
        Me.Controls.Add(Me.cmdAddSeq)
        Me.Controls.Add(Me.cmdSet)
        Me.Controls.Add(Me.lblSequences)
        Me.Controls.Add(Me.cmbSequences)
        Me.Controls.Add(Me.txtSeconds)
        Me.Controls.Add(Me.lblSeconds)
        Me.Controls.Add(Me.txtKeys)
        Me.Controls.Add(Me.lblKeys)
        Me.Controls.Add(Me.txtArrows)
        Me.Controls.Add(Me.lblArrows)
        Me.Controls.Add(Me.txtBows)
        Me.Controls.Add(Me.lblBows)
        Me.Controls.Add(Me.cmbCheckpoints)
        Me.Controls.Add(Me.cmdClose)
        Me.Name = "frmCheckpoints"
        Me.Text = "Checkpoint Editor"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmbCheckpoints As System.Windows.Forms.ComboBox
    Friend WithEvents lblBows As System.Windows.Forms.Label
    Friend WithEvents txtBows As System.Windows.Forms.TextBox
    Friend WithEvents txtArrows As System.Windows.Forms.TextBox
    Friend WithEvents lblArrows As System.Windows.Forms.Label
    Friend WithEvents txtSeconds As System.Windows.Forms.TextBox
    Friend WithEvents lblSeconds As System.Windows.Forms.Label
    Friend WithEvents txtKeys As System.Windows.Forms.TextBox
    Friend WithEvents lblKeys As System.Windows.Forms.Label
    Friend WithEvents cmbSequences As System.Windows.Forms.ComboBox
    Friend WithEvents lblSequences As System.Windows.Forms.Label
    Friend WithEvents cmdSet As System.Windows.Forms.Button
    Friend WithEvents cmdAddSeq As System.Windows.Forms.Button
    Friend WithEvents cmdDelSeq As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents txtPlayerYPos As System.Windows.Forms.TextBox
    Friend WithEvents lblPlayerYPos As System.Windows.Forms.Label
    Friend WithEvents txtPlayerXPos As System.Windows.Forms.TextBox
    Friend WithEvents lblPlayerXPos As System.Windows.Forms.Label
End Class
