﻿Public Class frmSaveAsC

    Private Sub frmSaveAsC_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        lstFiles.Items.Clear()
    End Sub

    Private Sub cmdAddMap_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddMap.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()
        ' Open a file selector at the maps folder location, or the program's
        ' location if the Maps folder doesn't exist for some reason.
        ' The Maps folder will be created upon trying to save a map if it
        ' does not exist.
        fd.Title = "Open File Dialog"
        If (Not System.IO.Directory.Exists(Application.StartupPath & "\Maps")) Then
            fd.InitialDirectory = Application.StartupPath
        Else
            fd.InitialDirectory = Application.StartupPath & "\Maps"
        End If
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            lstFiles.Items.Add(fd.FileName)
        End If
    End Sub

    Private Sub cmdRemoveMap_Click(sender As System.Object, e As System.EventArgs) Handles cmdRemoveMap.Click
        If lstFiles.SelectedItem <> Nothing Then
            lstFiles.Items.Remove(lstFiles.SelectedItem)
        End If
    End Sub

    Private Sub cmdClose_Click(sender As System.Object, e As System.EventArgs) Handles cmdClose.Click
        Me.Hide()
    End Sub

    Private Sub cmdMoveUp_Click(sender As System.Object, e As System.EventArgs) Handles cmdMoveUp.Click
        'Make sure our item is not the first one on the list.
        If lstFiles.SelectedIndex > 0 Then
            Dim i = lstFiles.SelectedIndex - 1
            lstFiles.Items.Insert(i, lstFiles.SelectedItem)
            lstFiles.Items.RemoveAt(lstFiles.SelectedIndex)
            lstFiles.SelectedIndex = i
        End If
    End Sub

    Private Sub cmdMoveDown_Click(sender As System.Object, e As System.EventArgs) Handles cmdMoveDown.Click
        'Make sure our item is not the last one on the list.
        If lstFiles.SelectedIndex < lstFiles.Items.Count - 1 Then
            'Insert places items above the index you supply, since we want
            'to move it down the list we have to do + 2
            Dim I = lstFiles.SelectedIndex + 2
            lstFiles.Items.Insert(I, lstFiles.SelectedItem)
            lstFiles.Items.RemoveAt(lstFiles.SelectedIndex)
            lstFiles.SelectedIndex = I - 1
        End If
    End Sub

    Private Sub cmdSaveMaps_Click(sender As System.Object, e As System.EventArgs) Handles cmdSaveMaps.Click
        ' Get the files into an array
        ' 
        Dim fileNames() As String
        Dim n, m As Integer

        n = lstFiles.Items.Count - 1
        If n > -1 Then
            ReDim fileNames(n)
            For m = 0 To n
                fileNames(m) = lstFiles.Items(m)
            Next m
            ' Try and save the file.
            If CMap.SaveMapAsC(fileNames) = 0 Then
                MsgBox(".c and .h files were created in level editor directory. Copy them to the EntombedGBA src and include directories.", MsgBoxStyle.OkOnly, "Files created")
            End If
        End If
    End Sub
End Class