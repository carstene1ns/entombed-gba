﻿Public Class TileMap
    Enum TileType
        WallTiles
        KillerTiles
        Collectables
        Containers
        Enemies
        Guns
        Platforms
        Ladders
        Exits
        Level5Objects
    End Enum

    ' Load the tile graphics
    Public m_bmpTiles = My.Resources.EntombedTiles

    ' Tile picker gfx
    Public m_bmpTilePicker As Bitmap
    Public m_gfxTilePicker As Graphics

    Public m_SelectedType As Integer
    Public m_SelectedTile As Integer
    Public m_TileTypes() As String = {"Wall Tiles", "Killer Tiles", "Collectables", "Containers",
                                       "Enemies", "Guns", "Switches", "Platforms", "Ladders", "Exits",
                                        "Level 5 objects"}
    Public m_TilesInTypes()() As Integer = {({0, 1, 2, 3, 4, 5, 6, 7}),
                                             ({8, 9, 10, 11, 12, 13, 14, 15, 16}),
                                             ({17, 18, 19, 20, 21, 22}),
                                             ({23, 24, 25}),
                                             ({26, 27}),
                                             ({28, 29}),
                                             ({30}),
                                             ({31, 32, 33, 36, 37}),
                                             ({34}),
                                             ({35}),
                                             ({38, 39, 40, 41, 42})}

    Public m_TileHeights() As Integer = {16, 16, 16, 16, 16, 16, 16, 16,
                                         16, 16, 16, 16, 16, 16, 16, 16,
                                         16, 16, 16, 16, 16, 16, 16, 16,
                                         32, 32, 32, 32, 16, 16, 16, 16,
                                         16, 16, 16, 32, 16, 16, 16, 16,
                                         16, 16, 32}

    Public m_TileLayers() As Integer = {0, 0, 0, 0, 0, 0, 0, 0,
                                        1, 1, 1, 1, 1, 1, 1, 1,
                                        1, 1, 1, 1, 1, 1, 1, 1,
                                        1, 1, 3, 3, 1, 1, 1, 1,
                                        1, 3, 1, 1, 1, 1, 1, 1,
                                        1, 3, 1}
    Public m_PropertyNames()() As String = {({""}), ({""}), ({""}), ({""}), ({""}), ({""}), ({""}), ({""}),
                                            ({""}), ({""}), ({""}), ({""}), ({""}), ({""}), ({""}), ({""}),
                                            ({""}), ({""}), ({""}),
                                            ({"Points"}), ({"Seconds"}), ({""}), ({"Arrows"}), ({""}),
                                            ({""}), ({"HitPoints"}),
                                            ({"HitPoints", "xMin", "xMax", "StartingDir", "FireRate"}),
                                            ({"HitPoints", "xMin", "xMax", "StartingDir", "Speed"}),
                                            ({"Bullets", "interval"}), ({"Bullets", "interval"}),
                                            ({"Sequence"}), ({""}), ({""}),
                                            ({"isMoving", "xMin", "xMax", "StartingDir", "Speed"}),
                                            ({""}), ({""}), ({""}), ({""}),
                                            ({"xDest", "yDest", "Remove"}),
                                            ({"Bullets", "interval", "lifespan", "weight"}),
                                            ({"Bullets", "interval", "lifespan", "weight"}),
                                            ({"type", "startDir", "lifespan"}),
                                            ({""})}


    Public Sub New()
        'Dim n As Integer
        '        For n = 0 To UBound(m_TileTypes) - 1
        '      Form1.ComboBox1.Items.Add(m_TileTypes(n))
        '        Next n
        '  Form1.ComboBox1.SelectedIndex = 0

        m_SelectedType = TileType.WallTiles
        m_SelectedTile = 0
    End Sub

    Public Sub InitComboBox(cboBox As ComboBox)
        For n = 0 To UBound(m_TileTypes)
            cboBox.Items.Add(m_TileTypes(n))
        Next n
        cboBox.SelectedIndex = 0
    End Sub

    Public Sub ProcessMouseClick(picbox As PictureBox, x As Integer, y As Integer, button As MouseButtons, down As Boolean)
        ' Work out if a different tile was clicked than the one currently selected
        'Tiles are in rows of 4 in the picturebox. Each is 64 x 64 pixels.
        Dim intTilePosClicked As Integer = ((y \ 64) * 4) + (x \ 64)
        If intTilePosClicked <= UBound(m_TilesInTypes(m_SelectedType)) Then
            m_SelectedTile = m_TilesInTypes(m_SelectedType)(intTilePosClicked)
            g_blnTilePickerChanged = True
            DrawTilesToPicBox(picbox)
        End If
    End Sub
    Public Sub DrawTilesToPicBox(picbox As PictureBox)
        Dim n As Integer
        ' Update the tile picker picturebox
        m_gfxTilePicker = Graphics.FromImage(m_bmpTilePicker)
        m_gfxTilePicker.Clear(Color.White)
        Dim rctSrc As Rectangle
        Dim rctDest As Rectangle
        Dim intPos As Integer = 0

        If g_blnTilePickerChanged = True Then
            ' If bmpMapView is not the same size as the picturebox then make it so.
            rctSrc.Width = 32
            rctSrc.Height = 32
            rctDest.Width = 64
            rctDest.Height = 64
            For n = 0 To UBound(CTileMap.m_TilesInTypes(CTileMap.m_SelectedType))
                ' There can be up to 4 tiles on a horizontal 'line', then the rest will be
                ' on lines below.
                ' Tiles are scaled x 2 and this is currently hard coded in the following lines
                rctSrc.X = (CTileMap.m_TilesInTypes(CTileMap.m_SelectedType)(n) Mod 8) * 32
                rctSrc.Y = Int(CTileMap.m_TilesInTypes(CTileMap.m_SelectedType)(n) \ 8) * 32
                rctDest.X = ((intPos Mod 4) * 64)
                rctDest.Y = (intPos \ 4) * 64
                m_gfxTilePicker.DrawImage(m_bmpTiles, rctDest, rctSrc, GraphicsUnit.Pixel)
                intPos = intPos + 1
            Next n

            ' Draw a rectangle around the selected tile
            ' Subtract the first tile's position in the category from the
            ' selected tile's position in the category.
            For n = 0 To UBound(CTileMap.m_TilesInTypes(CTileMap.m_SelectedType))
                If CTileMap.m_TilesInTypes(CTileMap.m_SelectedType)(n) = m_SelectedTile Then
                    intPos = n
                    Exit For
                End If
            Next n
            'i = intPos - CTileMap.m_TilesInTypes(CTileMap.m_SelectedType)(0)
            'i = intPos
            rctDest.X = ((n Mod 4) * 64)
            rctDest.Y = (n \ 4) * 64
            Dim myPen As New Pen(Color.Red)
            myPen.Width = 2
            m_gfxTilePicker.DrawRectangle(myPen, rctDest)

            picbox.Image = m_bmpTilePicker
            g_blnTilePickerChanged = False
        End If
    End Sub

End Class
