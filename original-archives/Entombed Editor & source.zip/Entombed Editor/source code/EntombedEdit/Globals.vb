﻿Module Globals
    ' Class instances
    Public CMap As Map
    Public CTileMap As TileMap

    ' Booleans for picture box updates
    Public g_blnMapViewChanged As Boolean
    Public g_blnTilePickerChanged As Boolean
    Public g_blnSelectedTileChanged As Boolean

    ' Stores the tile graphics
    Public g_bmpTiles As Bitmap

    ' Constants
    Public Const TILE_WIDTH = 32
    Public Const TILE_HEIGHT = 16
    Public Const MAP_WIDTH = 2560
    Public Const MAP_HEIGHT = 768


End Module
