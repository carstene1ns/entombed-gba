﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSaveAsC
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.lstFiles = New System.Windows.Forms.ListBox()
        Me.cmdMoveUp = New System.Windows.Forms.Button()
        Me.cmdMoveDown = New System.Windows.Forms.Button()
        Me.cmdAddMap = New System.Windows.Forms.Button()
        Me.cmdRemoveMap = New System.Windows.Forms.Button()
        Me.cmdSaveMaps = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.Location = New System.Drawing.Point(558, 182)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(88, 31)
        Me.cmdClose.TabIndex = 4
        Me.cmdClose.Text = "Close"
        Me.cmdClose.UseVisualStyleBackColor = True
        '
        'lstFiles
        '
        Me.lstFiles.FormattingEnabled = True
        Me.lstFiles.Location = New System.Drawing.Point(44, 23)
        Me.lstFiles.Name = "lstFiles"
        Me.lstFiles.Size = New System.Drawing.Size(537, 95)
        Me.lstFiles.TabIndex = 5
        '
        'cmdMoveUp
        '
        Me.cmdMoveUp.Location = New System.Drawing.Point(596, 23)
        Me.cmdMoveUp.Name = "cmdMoveUp"
        Me.cmdMoveUp.Size = New System.Drawing.Size(34, 34)
        Me.cmdMoveUp.TabIndex = 6
        Me.cmdMoveUp.Text = "/\"
        Me.cmdMoveUp.UseVisualStyleBackColor = True
        '
        'cmdMoveDown
        '
        Me.cmdMoveDown.Location = New System.Drawing.Point(596, 84)
        Me.cmdMoveDown.Name = "cmdMoveDown"
        Me.cmdMoveDown.Size = New System.Drawing.Size(34, 34)
        Me.cmdMoveDown.TabIndex = 7
        Me.cmdMoveDown.Text = "\/"
        Me.cmdMoveDown.UseVisualStyleBackColor = True
        '
        'cmdAddMap
        '
        Me.cmdAddMap.Location = New System.Drawing.Point(171, 124)
        Me.cmdAddMap.Name = "cmdAddMap"
        Me.cmdAddMap.Size = New System.Drawing.Size(81, 25)
        Me.cmdAddMap.TabIndex = 8
        Me.cmdAddMap.Text = "Add Map"
        Me.cmdAddMap.UseVisualStyleBackColor = True
        '
        'cmdRemoveMap
        '
        Me.cmdRemoveMap.Location = New System.Drawing.Point(419, 124)
        Me.cmdRemoveMap.Name = "cmdRemoveMap"
        Me.cmdRemoveMap.Size = New System.Drawing.Size(81, 25)
        Me.cmdRemoveMap.TabIndex = 9
        Me.cmdRemoveMap.Text = "Remove Map"
        Me.cmdRemoveMap.UseVisualStyleBackColor = True
        '
        'cmdSaveMaps
        '
        Me.cmdSaveMaps.Location = New System.Drawing.Point(281, 173)
        Me.cmdSaveMaps.Name = "cmdSaveMaps"
        Me.cmdSaveMaps.Size = New System.Drawing.Size(88, 31)
        Me.cmdSaveMaps.TabIndex = 10
        Me.cmdSaveMaps.Text = "Save Map(s)"
        Me.cmdSaveMaps.UseVisualStyleBackColor = True
        '
        'frmSaveAsC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(688, 216)
        Me.Controls.Add(Me.cmdSaveMaps)
        Me.Controls.Add(Me.cmdRemoveMap)
        Me.Controls.Add(Me.cmdAddMap)
        Me.Controls.Add(Me.cmdMoveDown)
        Me.Controls.Add(Me.cmdMoveUp)
        Me.Controls.Add(Me.lstFiles)
        Me.Controls.Add(Me.cmdClose)
        Me.Name = "frmSaveAsC"
        Me.Text = "Save Map(s) as .c/.h files"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents lstFiles As System.Windows.Forms.ListBox
    Friend WithEvents cmdMoveUp As System.Windows.Forms.Button
    Friend WithEvents cmdMoveDown As System.Windows.Forms.Button
    Friend WithEvents cmdAddMap As System.Windows.Forms.Button
    Friend WithEvents cmdRemoveMap As System.Windows.Forms.Button
    Friend WithEvents cmdSaveMaps As System.Windows.Forms.Button
End Class
