﻿Public Class frmCheckpoints

    Private Sub cmdClose_Click(sender As System.Object, e As System.EventArgs) Handles cmdClose.Click
        Me.Hide()
    End Sub

    Private Sub frmCheckpoints_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        UpdateCheckpoints()
    End Sub

    Private Sub cmbCheckpoints_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbCheckpoints.SelectedIndexChanged

        Dim n As Integer

        'Load the data
        txtPlayerXPos.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).playerXPos)
        txtPlayerYPos.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).playerYPos)
        txtBows.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).bows)
        txtArrows.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).arrows)
        txtKeys.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).keys)
        txtSeconds.Text = CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).seconds)
        cmbSequences.Items.Clear()
        If CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).sequences Is Nothing = False Then
            For n = 0 To CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).sequences.Count - 1
                cmbSequences.Items.Add(CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).sequences(n)))
            Next n
        End If
    End Sub

    Private Sub cmdSet_Click(sender As System.Object, e As System.EventArgs) Handles cmdSet.Click

        Dim xPos, yPos As Integer
        Dim playerXPos, playerYPos As Integer
        Dim bows As Integer
        Dim arrows As Integer
        Dim keys As Integer
        Dim seconds As Integer
        Dim sequences As List(Of Integer)
        Dim tempCheckpoint As Map.CheckPoint
        Dim n As Integer

        xPos = CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).xPos
        yPos = CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).yPos
        playerXPos = CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).xPos
        playerYPos = CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).yPos
        bows = 0
        arrows = 0
        keys = 0
        seconds = 0
        sequences = New List(Of Integer)

        If IsNumeric(txtPlayerXPos.Text) Then
            If Int(txtPlayerXPos.Text) <= 2528 And Int(txtPlayerXPos.Text) >= 32 Then
                playerXPos = Int(txtPlayerXPos.Text)
            End If
        End If
        If IsNumeric(txtPlayerYPos.Text) Then
            If Int(txtPlayerYPos.Text) <= 720 And Int(txtPlayerYPos.Text) >= 16 Then
                playerYPos = Int(txtPlayerYPos.Text)
            End If
        End If
        If IsNumeric(txtBows.Text) Then
            If Int(txtBows.Text) <= 5 Then
                bows = Int(txtBows.Text)
            End If
        End If
        If IsNumeric(txtArrows.Text) Then
            If Int(txtArrows.Text) <= 12 Then
                arrows = Int(txtArrows.Text)
            End If
        End If
        If IsNumeric(txtKeys.Text) Then
            If Int(txtKeys.Text) <= 5 Then
                keys = Int(txtKeys.Text)
            End If
        End If
        If IsNumeric(txtSeconds.Text) Then
            If Int(txtSeconds.Text) <= 30 Then
                seconds = Int(txtSeconds.Text)
            End If
        End If

        If cmbSequences.Items.Count > 0 Then
            For n = 0 To cmbSequences.Items.Count - 1
                sequences.Add(Int(cmbSequences.Items(n)))
            Next n
        End If

        tempCheckpoint = New Map.CheckPoint
        tempCheckpoint.xPos = xPos
        tempCheckpoint.yPos = yPos
        tempCheckpoint.playerXPos = playerXPos
        tempCheckpoint.playerYPos = playerYPos
        tempCheckpoint.bows = bows
        tempCheckpoint.arrows = arrows
        tempCheckpoint.keys = keys
        tempCheckpoint.seconds = seconds
        tempCheckpoint.sequences = sequences
        CMap.m_checkPoints(cmbCheckpoints.SelectedIndex) = tempCheckpoint

        'CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).SetVals(xPos, yPos, playerXPos, playerYPos, bows, arrows, keys, seconds, sequences)
        'CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).bows = bows
        txtPlayerXPos.Text = CStr(playerXPos)
        txtPlayerYPos.Text = CStr(playerYPos)
        txtBows.Text = CStr(bows)
        txtArrows.Text = CStr(arrows)
        txtKeys.Text = CStr(keys)
        txtSeconds.Text = CStr(seconds)

        MsgBox("Checkpoint Data for X:" & CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).xPos) & " Y:" & _
               CStr(CMap.m_checkPoints(cmbCheckpoints.SelectedIndex).yPos) & " has been set.", _
               MsgBoxStyle.OkOnly, "Checkpoint data set")
    End Sub

    Public Sub UpdateCheckpoints()
        Dim n, m, x As Integer
        Dim tempCheckpoint As Map.CheckPoint
        Dim isInList As Boolean
        ' Look through the checkpoint list and remove any where there's no longer a
        ' checkpoint at that location.
        ' Loop from the end to the beginning to avoid skipping items when one is removed
        If CMap.m_checkPoints Is Nothing = False Then
            For n = CMap.m_checkPoints.Count - 1 To 0 Step -1
                If CMap.m_arrMapTiles(CMap.m_checkPoints(n).yPos, CMap.m_checkPoints(n).xPos, 1).m_intType <> 30 Or
                    CMap.m_arrMapTiles(CMap.m_checkPoints(n).yPos, CMap.m_checkPoints(n).xPos, 1).m_arrintPropertyValues(0) <> -1 Then
                    CMap.m_checkPoints.RemoveAt(n)
                End If
            Next n
        End If


        ' Look through the map for switches that are checkpoints
        For n = 0 To 47
            For m = 0 To 79
                If CMap.m_arrMapTiles(n, m, 1).m_intType = 30 Then
                    If CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                        If CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) = -1 Then
                            ' If this wasn't already in the checkpoint list then add it.
                            isInList = False
                            If CMap.m_checkPoints Is Nothing = False Then
                                For x = 0 To CMap.m_checkPoints.Count - 1
                                    If CMap.m_checkPoints(x).xPos = m And CMap.m_checkPoints(x).yPos = n Then
                                        isInList = True
                                    End If
                                Next x
                            Else
                                CMap.m_checkPoints = New List(Of Map.CheckPoint)
                            End If
                            If isInList = False Then
                                tempCheckpoint.xPos = m
                                tempCheckpoint.yPos = n
                                tempCheckpoint.playerXPos = m
                                tempCheckpoint.playerYPos = n
                                tempCheckpoint.bows = 0
                                tempCheckpoint.arrows = 0
                                tempCheckpoint.keys = 0
                                tempCheckpoint.seconds = 0
                                tempCheckpoint.sequences = Nothing
                                CMap.m_checkPoints.Add(tempCheckpoint)
                            End If
                        End If
                    End If
                End If
            Next m
        Next n
        ' Load all checkpoints into the combobox
        cmbCheckpoints.Items.Clear()
        If CMap.m_checkPoints Is Nothing = False Then
            If CMap.m_checkPoints.Count > 0 Then
                For x = 0 To CMap.m_checkPoints.Count - 1
                    cmbCheckpoints.Items.Add("X: " & CStr(CMap.m_checkPoints(x).xPos) & "   Y: " & CStr(CMap.m_checkPoints(x).yPos))
                Next x
                ' Select the first checkpoint
                cmbCheckpoints.SelectedIndex = 0
            End If
        End If
    End Sub

    Private Sub cmdAddSeq_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddSeq.Click
        Dim tempStr As String
        tempStr = InputBox("Enter the sequence number. (Be sure it exists first)", "Enter sequence number")
        If IsNumeric(tempStr) = True Then
            If Int(tempStr) > 0 And Int(tempStr) < 1000 Then
                cmbSequences.Items.Add(tempStr)
                cmbSequences.SelectedIndex = cmbSequences.Items.Count - 1
            Else
                MsgBox("Invalid sequence number", MsgBoxStyle.Critical, "Invalid sequence number")
            End If
        Else
            MsgBox("Invalid sequence number", MsgBoxStyle.Critical, "Invalid sequence number")
        End If
    End Sub

    Private Sub cmdDelSeq_Click(sender As System.Object, e As System.EventArgs) Handles cmdDelSeq.Click
        If cmbSequences.SelectedIndex >= 0 Then
            cmbSequences.Items.RemoveAt(cmbSequences.SelectedIndex)
            If cmbSequences.Items.Count > 0 Then
                cmbSequences.SelectedIndex = 0
            End If
        End If
    End Sub
End Class

