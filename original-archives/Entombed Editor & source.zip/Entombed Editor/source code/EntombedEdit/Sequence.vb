﻿Public Class Sequence
    ' This class deals with dynamic changes on the map which are done in a sequence.
    ' There are two types of sequences:
    ' The first type runs once is triggered when the player touches a switch on the map. 
    ' The second type runs on a constant loop and can be always running or triggered by a switch.
    ' (e.g. there might be a set of spikes that toggles on and off repeatedly.)

    ' A sequence is basically a list of actions.
    ' Actions can be things like:
    ' Making map tiles appear or disappear. (Tiles of any type including sprites)
    ' Turning guns on or off.
    ' Making platforms start moving.

    ' Actions can be split up with delays in between. Often when a wall or fixture tile change is
    ' delayed, those tiles flash on and off until the delay is over. While flashing, the tiles
    ' still act as they did before the change. (Appearing tiles act as if they've not appeared 
    ' yet and vice versa)

    'Public Property m_intSeqNum As Integer
    Public Property m_objStages As List(Of SequenceStage)

    ' This sequence number must have run before this one. Since we'll usually be changing the
    ' map tiles, it must be in a known state first. If this gets set, the map appearance will
    ' be set to how it would be after this sequence which is depended on has run, and any
    ' previous sequences that were depended on earlier in a sequence chain.

    ' e.g. This is sequence number 3. It depends on sequence number 2.
    ' Sequence number 2 depends on sequence number 1.
    ' As soon as you set m_intDependsOnStage to 2 and are in sequence edit mode, the program
    ' will look back through the dependancy chain and completely apply the sequences for the
    ' earlier dependancies. The map will then be in the correct state for setting up the 
    ' sequence.
    Public Property m_intDependsOnSequence As Integer
    Public Property m_blnLoop As Boolean
    Public Property m_blnAlwaysOn As Boolean

    Public Sub New()
        m_objStages = New List(Of SequenceStage)
        m_intDependsOnSequence = -1
        m_blnLoop = False
        m_blnAlwaysOn = False
    End Sub

End Class

Public Class SequenceStage
    Enum StageType
        ChangeTiles
        ToggleSequence ' Either start or stop a separate sequence. Optionally allow the switch to
        ' be re-used. (Level 5 on original game)
    End Enum
    Structure TileChange ' Stores a change on a single location/layer
        Public xPos As Integer
        Public yPos As Integer
        Public layer As Integer
        Public mapObj As MapObject
    End Structure

    Structure TileChangeCombined ' Stores up to 3 layers of changes for a map location
        Public xPos As Integer
        Public yPos As Integer
        Public mapObj() As MapObject
    End Structure

    ' Structure that will be used within the ApplySequenceDependancies procedure simply to
    ' help with sorting. The x,y,layer values are combined into one number.
    Structure tileChg
        Public intLocation As Integer
        Public intSeq As Integer
        Public intStage As Integer
        Public mapObj As MapObject
    End Structure

    'Public m_intStageNum As Integer ' Position in the sequence
    Public m_intChangeType As Integer ' Type of change (See the Enum above)
    Public m_objTileChanges As List(Of TileChange) ' List of tile changes
    Public m_intDelayFrames As Integer ' Delay time for change, if any
    Public m_blnDelayFlash As Boolean ' Whether the tiles will flash during the delay
    Public m_intToggleSequence As Integer ' Which other sequence to activate or toggle

    Public Sub New()
        ' Set property defaults
        m_intChangeType = SequenceStage.StageType.ChangeTiles
        m_objTileChanges = New List(Of TileChange)
        m_intDelayFrames = 60 ' 1 second delay by default
        m_blnDelayFlash = True ' True by default since it's the most common.
        m_intToggleSequence = -1 ' Level 5 property, not used yet.

    End Sub

    Public Sub AddTileChange(x As Integer, y As Integer, layer As Integer, tile As Integer, Optional arrProps As List(Of Integer) = Nothing)
        Dim objTmpMapChange As New TileChange
        Dim n As Integer
        Dim blnReplaced As Boolean = False
        objTmpMapChange.mapObj = New MapObject(tile)
        objTmpMapChange.xPos = x
        objTmpMapChange.yPos = y
        objTmpMapChange.layer = layer
        'objTmpMapChange.mapObj.m_arrintPropertyValues = arrProps
        'If a change at this location/layer already exists then replace it, 
        If m_objTileChanges Is Nothing = False Then
            If m_objTileChanges.Count > 0 Then
                For n = 0 To m_objTileChanges.Count - 1
                    If m_objTileChanges(n).xPos = x And m_objTileChanges(n).yPos = y And _
                     m_objTileChanges(n).layer = layer Then
                        m_objTileChanges(n) = objTmpMapChange
                        blnReplaced = True
                    End If
                Next n
            End If
        End If
        ' If the change wasn't a replacement then add one
        If blnReplaced = False Then
            m_objTileChanges.Add(objTmpMapChange)
        End If
    End Sub

    Public Function RemoveTileChange(x As Integer, y As Integer, layer As Integer) As Boolean
        ' This procedure will remove a tile change from the stage, if one is found at the
        ' given location.
        ' We need to make extra consideration here for if we are wanting to set an original map tile
        ' in the fixture or sprite layer to empty. (e.g. remove a coin from the map) 
        ' As there is no selectable blank tile for these layers, I would have to make the right mouse
        ' button set the tile to zero. However, what if I'm wanting to remove a changed tile from
        ' the stage. I would also use the right button for that.
        ' Therefore: If we're on the fixture or sprite layer, if there is a non-zero tile there
        ' on the original map and no change already there, make a tile change to tile zero.
        ' If there is already a change on that tile for the current stage, remove that change.
        Dim n As Integer
        Dim intChangeNum As Integer
        Dim objTmpMapChange As New TileChange

        ' Find out if there's a tile change here already
        intChangeNum = -1
        If m_objTileChanges Is Nothing = False Then
            If m_objTileChanges.Count > 0 Then
                For n = 0 To m_objTileChanges.Count - 1
                    If m_objTileChanges(n).xPos = x And m_objTileChanges(n).yPos = y And _
                     m_objTileChanges(n).layer = layer Then
                        intChangeNum = n
                        Exit For
                    End If
                Next n
            End If
        End If

        If layer = 0 Then
            If intChangeNum >= 0 Then
                ' Remove the change from the list
                m_objTileChanges.RemoveAt(intChangeNum)
                Return True
            Else
                ' Else we don't need to remove anything
                Return False
            End If
        Else
            ' We're in the fixture/sprite layer
            If intChangeNum >= 0 Then
                ' Remove the change from the list
                m_objTileChanges.RemoveAt(intChangeNum)
                Return True
            Else
                ' "Add" a blank tile to the changes list
                objTmpMapChange.mapObj = New MapObject(0)
                objTmpMapChange.xPos = x
                objTmpMapChange.yPos = y
                objTmpMapChange.layer = layer
                m_objTileChanges.Add(objTmpMapChange)
                Return True
            End If
        End If

    End Function

    Public Function LookupTileChange(x As Integer, y As Integer, layer As Integer) As MapObject
        ' Returns map object data for a tile change at the given location within this sequence
        ' stage. If none is found then return nothing.
        Dim n As Integer

        If m_objTileChanges.Count > 0 Then
            For n = 0 To m_objTileChanges.Count - 1
                If m_objTileChanges(n).xPos = x And m_objTileChanges(n).yPos = y _
                 And m_objTileChanges(n).layer = layer Then
                    Return m_objTileChanges(n).mapObj
                End If
            Next n
            ' If we got here we didn't find a match
            Return Nothing
        Else
            Return Nothing
        End If

    End Function
End Class

