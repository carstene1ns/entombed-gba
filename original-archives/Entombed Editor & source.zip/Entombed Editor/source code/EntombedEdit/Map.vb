﻿Imports System.Drawing.Imaging
Imports System.IO

Public Class Map

    ' Bitmap that stores the whole map
    Private m_bmpBackground As Bitmap

    ' Map view gfx
    Public m_bmpMapView As Bitmap
    Public m_gfxMapView As Graphics

    ' Tile selection gfx
    Public m_bmpSelectedTile As Bitmap
    Public m_gfxSelectedTile As Graphics

    ' Last used map file name for save/save as buttons
    Public m_strFileName As String

    ' The tile data in array form (48 rows of 80 tiles, 4 layers per tile (walls, fixtures, shadows, sprites)
    Public m_arrMapTiles(0 To 47, 0 To 79, 0 To 3) As MapObject
    ' A copy of the tile data array to store the original data when we want to apply changes during
    ' sequence editing. We'll revert back to this after turning off sequence editing mode.
    Public m_arrMapTilesOrig(0 To 47, 0 To 79, 0 To 3) As MapObject

    'Arrays for tiles that have changed and therefore
    'need to be redrawn
    Public m_arrChangedTiles(0 To 47, 0 To 79) As Boolean

    ' Variable that stores the wall type for the map, can be from 0 to 4 since there
    ' are 5 levels, each with their own wall tile set.
    Public m_intWallType As Integer

    ' Player start location property
    Public m_pntPlayerStartLocation As Point

    ' Map description
    Public m_strMapDescription As String

    'Public m_selectedTile As Integer 'Stores the tile that is selected when drawing the map
    Public m_intHoveredTileX, m_intHoveredTileY As Integer 'The x and y tile coords that the mouse is over

    ' Variables for the map graphics
    Public m_intScrollPosX As Integer
    Public m_intScrollPosY As Integer
    Public m_intMapScale As Integer

    ' Variables for the mouse cursor and tile border
    Public m_pntHoveredTileCoords As Point
    Public m_pntLastHoveredTileCoords As Point
    Public m_intTileBorderHeight As Integer

    ' Variables for drawing/selecting tiles
    Public m_blnDrawMode As Boolean
    Private m_blnCurrentlyDrawing As Boolean
    Public m_intSelectLayer As Integer
    Public m_pntSelectedTilePos As Point

    ' _Map change sequence variables_
    ' Sequence list
    Public m_arrobjSequenceList As List(Of Sequence)

    ' Tile differences between the original map and the sequence/stage before the current one
    Public m_arrpntSeqTileChanges As List(Of Point)

    ' Map object and container differences between the original map and the 
    ' current sequence/stage
    'Public m_arrobjSeqMapObjectChanges As List(Of MapObject)

    Public m_blnSequenceEditing As Boolean ' Whether we're in sequence edit mode
    Public m_intLastSequence As Integer ' The last sequence number we were working on
    Public m_intLastStage As Integer ' The last stage number we were working on
    Public m_pntTriggeringSwitchLocation As Point ' The triggering switch location for the selected sequence

    ' Set in GetTileData procedure if the tile data was got from a sequence map change.
    ' Used in UpdateMapTiles procedure
    Public m_blnTileChangeFound As Boolean

    Structure CheckPoint ' Stores all data related to a checkpoint
        Public xPos As Integer
        Public yPos As Integer
        Public playerXPos As Integer ' I found out that the player can start at a different position
        Public playerYPos As Integer
        Public bows As Integer
        Public arrows As Integer
        Public keys As Integer
        Public seconds As Integer
        Public sequences As List(Of Integer) 'List of activated sequences
    End Structure
    Public m_checkPoints As List(Of CheckPoint)


    Public Sub New()
        Dim n, m, x As Integer

        m_bmpBackground = New Bitmap(MAP_WIDTH, MAP_HEIGHT)
        m_intScrollPosX = 0
        m_intScrollPosY = 0
        m_intMapScale = 1

        ' Map property initialization
        m_intWallType = 0
        m_pntPlayerStartLocation.X = 2
        m_pntPlayerStartLocation.Y = 2
        m_strMapDescription = "Map"

        m_pntLastHoveredTileCoords.X = -1
        m_pntLastHoveredTileCoords.Y = -1

        ' Initialize the map location arrays
        For n = 0 To 47
            For m = 0 To 79
                For x = 0 To 3
                    m_arrMapTiles(n, m, x) = New MapObject(0)
                    m_arrChangedTiles(n, m) = False
                Next x
            Next m
        Next n

        ' Initialize variables for drawing/selecting tiles
        m_blnDrawMode = True
        m_blnCurrentlyDrawing = False
        m_intSelectLayer = 0

        ' Initialize the sequence list
        m_arrobjSequenceList = New List(Of Sequence)

        ' Initialize the list of tile changes in relation to the original map, excluding the
        ' current stage.
        m_arrpntSeqTileChanges = New List(Of Point)

        m_intLastSequence = -1
        m_intLastStage = -1

    End Sub

    Public Sub ProcessMouseMove(picbox As PictureBox, x As Integer, y As Integer)
        ' Check the mouse position and update the tile coordinates if necessary
        If x + CMap.m_intScrollPosX <= 2560 And y + CMap.m_intScrollPosY <= 768 Then
            m_pntHoveredTileCoords = GetTileCoords(x, y)
            If m_pntHoveredTileCoords.X <> m_pntLastHoveredTileCoords.X Or _
                m_pntHoveredTileCoords.Y <> m_pntLastHoveredTileCoords.Y Then

                ' Check if we're currently drawing
                If m_blnCurrentlyDrawing = True Then

                    ' Call a procedure to place the tile
                    PlaceTile(picbox)

                End If

                ' Redraw the map to the picturebox since the hovered tile border has
                ' changed and a tile may have been placed.
                DrawMapToPicBox(picbox)

                ' Set the old coords to the current ones
                m_pntLastHoveredTileCoords = m_pntHoveredTileCoords

            End If
        Else
            m_pntHoveredTileCoords.X = -1
            m_pntHoveredTileCoords.Y = -1
            m_pntLastHoveredTileCoords = m_pntHoveredTileCoords
            m_blnCurrentlyDrawing = False
        End If
    End Sub

    Public Sub ProcessMouseClick(mappicbox As PictureBox, selectionpicbox As PictureBox, x As Integer, y As Integer, button As MouseButtons, down As Boolean)
        ' Make sure we're within the map bounds
        If x + CMap.m_intScrollPosX <= 2560 And y + CMap.m_intScrollPosY <= 768 Then
            If m_blnDrawMode = True Then

                If button = MouseButtons.Left Then
                    ' Check if the left button was pressed or released
                    If down = True Then
                        m_blnCurrentlyDrawing = True

                        ' Call a procedure to place the tile
                        PlaceTile(mappicbox)

                    Else
                        m_blnCurrentlyDrawing = False
                    End If

                ElseIf button = MouseButtons.Right Then
                    ' Check if the mouse was pressed down
                    If down = True Then
                        ' Call a procedure to remove a tile. 
                        RemoveTile(mappicbox)
                    End If
                End If

                ' Update the selection picturebox if this was the same location as the currently
                ' selected tile
                If m_pntSelectedTilePos = m_pntHoveredTileCoords Then
                    g_blnSelectedTileChanged = True
                    UpdateSelection(selectionpicbox)
                End If
            Else
                ' We're in select mode so call the SelectTile procedure
                SelectTile(selectionpicbox, m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, _
                           m_intSelectLayer)
            End If
        End If
    End Sub

    Private Sub PlaceTile(picbox As PictureBox)

        ' Prevent an 'out of map bounds' bug
        If m_pntHoveredTileCoords.X >= 0 And m_pntHoveredTileCoords.Y >= 0 And _
            m_pntHoveredTileCoords.X < 80 And m_pntHoveredTileCoords.Y < 48 Then

            ' Don't allow double height tiles to be drawn on the bottom row
            If CTileMap.m_TileHeights(CTileMap.m_SelectedTile) = 32 And _
                m_pntHoveredTileCoords.Y = 47 Then
                Exit Sub
            End If

            ' If we're not in sequence editing mode then place the tile in the
            ' m_arrMapTiles array
            If m_blnSequenceEditing = False Then
                ' If this is a different object type then replace the object
                If m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                 CTileMap.m_TileLayers(CTileMap.m_SelectedTile)).m_intType <> _
                                  CTileMap.m_SelectedTile Then
                    m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                  CTileMap.m_TileLayers(CTileMap.m_SelectedTile)) = _
                                 Nothing
                    m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                  CTileMap.m_TileLayers(CTileMap.m_SelectedTile)) = _
                                   New MapObject(CTileMap.m_SelectedTile)

                    ' Mark the tile as changed
                    m_arrChangedTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X _
                                      ) = True

                    ' If this was a double-height tile, change the tile below and
                    ' add mark that one as changed as well.
                    If CTileMap.m_TileHeights(CTileMap.m_SelectedTile) = 32 Then
                        m_arrMapTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X, _
                                  CTileMap.m_TileLayers(CTileMap.m_SelectedTile)) = _
                                 Nothing
                        m_arrMapTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X, _
                                  CTileMap.m_TileLayers(CTileMap.m_SelectedTile)) = _
                                   New MapObject(99)
                        m_arrChangedTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X _
                                      ) = True
                    End If

                    ' Update the map tiles
                    UpdateMapTiles(CTileMap)

                    ' Redraw the map
                    g_blnMapViewChanged = True
                    DrawMapToPicBox(picbox)

                End If
            Else
                ' Else we're in sequence editing mode so call the AddTileChange method
                ' of the sequence stage class.
                ' The tile change will be drawn on the map from within the UpdateMapTiles procedure.
                ' i.e. UpdateMapTiles(CTileMap, m_intLastSequence, m_intLastStage)
                If m_intLastSequence >= 0 And m_intLastStage >= 0 Then
                    ' Call the AddTileChange method on the sequence stage.
                    m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                        .AddTileChange(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, _
                                        m_intSelectLayer, CTileMap.m_SelectedTile)

                    ' Mark the tile as changed
                    m_arrChangedTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X _
                                      ) = True

                    ' If this was a double-height tile, change the tile below and
                    ' add mark that one as changed as well.
                    If CTileMap.m_TileHeights(CTileMap.m_SelectedTile) = 32 Then
                        m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                        .AddTileChange(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y + 1, _
                                        m_intSelectLayer, 99)
                        m_arrChangedTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X _
                                      ) = True
                    End If

                    ' Update the map tiles
                    UpdateMapTiles(CTileMap)

                    ' Redraw the map
                    g_blnMapViewChanged = True
                    DrawMapToPicBox(picbox)

                End If

            End If
        End If

    End Sub

    Private Sub RemoveTile(picbox As PictureBox)
        ' Two booleans that let the program know to remove the tile above or
        ' below when part of a double-height tile was removed.
        Dim blnRemoveAbove, blnRemoveBelow As Boolean
        Dim tmpMapObj As MapObject

        ' Prevent an 'out of map bounds' bug
        If m_pntHoveredTileCoords.X >= 0 And m_pntHoveredTileCoords.Y >= 0 And _
            m_pntHoveredTileCoords.X < 80 And m_pntHoveredTileCoords.Y < 48 Then

            ' If we're in the fixture or sprite layer, check whether we need to also
            ' remove part of a double-height tile. Use the GetTileData function.
            If m_intSelectLayer > 0 Then
                ' Type 99 is the lower half of a double-height layer, we'll need to
                ' remove the tile above.
                If GetTileData(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, _
                                 m_intSelectLayer).m_intType = 99 Then
                    blnRemoveAbove = True
                Else
                    blnRemoveAbove = False
                    ' If the object type not 99 and is a double-height tile then we'll
                    ' need to remove the tile below.
                    If CTileMap.m_TileHeights(GetTileData(m_pntHoveredTileCoords.X, _
                        m_pntHoveredTileCoords.Y, m_intSelectLayer).m_intType) = 32 Then
                        blnRemoveBelow = True
                    Else
                        blnRemoveBelow = False
                    End If
                End If
            End If

            ' If we're not in sequence editing mode then place tile 0 in the
            ' m_arrMapTiles array
            If m_blnSequenceEditing = False Then

                ' If the object is not already type zero then set it to zero
                If m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                 m_intSelectLayer).m_intType <> _
                                  0 Then
                    m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                  m_intSelectLayer) = _
                                 Nothing
                    m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, _
                                  m_intSelectLayer) = _
                              New MapObject(0)

                    ' Mark the tile as changed
                    m_arrChangedTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X _
                                      ) = True

                    ' Remove the tile above or below if necessary
                    If blnRemoveAbove = True Then
                        m_arrMapTiles(m_pntHoveredTileCoords.Y - 1, m_pntHoveredTileCoords.X, _
                                  m_intSelectLayer) = _
                                 Nothing
                        m_arrMapTiles(m_pntHoveredTileCoords.Y - 1, m_pntHoveredTileCoords.X, _
                                      m_intSelectLayer) = _
                                  New MapObject(0)
                        m_arrChangedTiles(m_pntHoveredTileCoords.Y - 1, m_pntHoveredTileCoords.X _
                                      ) = True
                    End If
                    If blnRemoveBelow = True Then
                        m_arrMapTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X, _
                                  m_intSelectLayer) = _
                                 Nothing
                        m_arrMapTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X, _
                                      m_intSelectLayer) = _
                                  New MapObject(0)
                        m_arrChangedTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X _
                                      ) = True
                    End If

                    ' Update the map and redraw
                    UpdateMapTiles(CTileMap)
                    g_blnMapViewChanged = True
                    DrawMapToPicBox(picbox)

                End If
            Else
                ' Else we're in sequence editing mode so remove the tile from
                ' m_arrobjSequenceList([current stage]).m_objStages if it's in there
                ' It will be removed from the map from within the UpdateMapTiles procedure.
                ' i.e. UpdateMapTiles(CTileMap, m_intLastSequence, m_intLastStage)
                If m_intLastSequence >= 0 And m_intLastStage >= 0 Then

                    ' Call the RemoveTileChange method on the sequence stage.
                    ' If it returns true then a change was made, so update the map.
                    If m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                        .RemoveTileChange(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, _
                                        m_intSelectLayer) = True Then

                        ' Mark the tile as changed
                        m_arrChangedTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X _
                                          ) = True

                        ' Remove the tile above or below if necessary
                        If blnRemoveAbove = True Then
                            If m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                        .RemoveTileChange(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y - 1, _
                                        m_intSelectLayer) = True Then
                                m_arrChangedTiles(m_pntHoveredTileCoords.Y - 1, m_pntHoveredTileCoords.X _
                                                  ) = True
                            End If
                        End If
                        If blnRemoveBelow = True Then
                            If m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                        .RemoveTileChange(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y + 1, _
                                        m_intSelectLayer) = True Then
                                m_arrChangedTiles(m_pntHoveredTileCoords.Y + 1, m_pntHoveredTileCoords.X _
                                                  ) = True
                            End If
                        End If

                        ' See if this change affected this sequence's triggering switch location
                        If m_pntTriggeringSwitchLocation.X = m_pntHoveredTileCoords.X And _
                            m_pntTriggeringSwitchLocation.Y = m_pntHoveredTileCoords.Y Then
                            tmpMapObj = GetTileData(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, 1)
                            If tmpMapObj.m_intType = 30 And tmpMapObj.m_arrintPropertyValues(0) <> _
                                m_intLastSequence Then
                                ' The triggering switch for the current sequence was deleted, so reset the
                                ' triggering location coordinates
                                m_pntTriggeringSwitchLocation.X = -1
                                m_pntTriggeringSwitchLocation.Y = -1
                                frmMain.lblTriggeringSwitch.Text = "Triggering Switch: None"
                            End If
                        End If

                        ' Update the map and redraw
                        UpdateMapTiles(CTileMap)
                        g_blnMapViewChanged = True
                        DrawMapToPicBox(picbox)
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub SelectTile(picbox As PictureBox, x As Integer, y As Integer, layer As Integer)

        ' If we're on the fixture or sprite layer, make sure the tile under the
        ' cursor is above 0, otherwise it's an empty space so don't select anything
        ' For the wall layer, tile 0 is a blank wall and can be selected.
        'If layer > 0 Then
        '    If m_arrMapTiles(y, x, layer).m_intType > 0 Then
        '        m_pntSelectedTilePos.X = x
        '        m_pntSelectedTilePos.Y = y
        '        g_blnSelectedTileChanged = True
        '        UpdateSelection(picbox)
        '    End If
        'Else
        m_pntSelectedTilePos.X = x
        m_pntSelectedTilePos.Y = y
        g_blnSelectedTileChanged = True
        UpdateSelection(picbox)
        'End If

    End Sub

    Public Sub DrawSelectionPicBox(picbox As PictureBox, g As Graphics)
        ' Get the tile graphics from the tilemap, which is a grid 
        ' of 32x32 pixel tiles in rows of 8.
        ' Use GetTileData to get the correct tile, which may be the original map data or sequence change data.
        Dim intSelectedTile = GetTileData(m_pntSelectedTilePos.X, m_pntSelectedTilePos.Y, m_intSelectLayer).m_intType
        Dim rctSrc As New Rectangle((intSelectedTile Mod 8) * 32, (intSelectedTile \ 8) * 32, _
                                    32, _
                                    32)
        Dim rctDest As New Rectangle(0, 0, picbox.Width, picbox.Height)
        g.DrawImage(CTileMap.m_bmpTiles, rctDest, rctSrc, GraphicsUnit.Pixel)
        picbox.Image = m_bmpSelectedTile

    End Sub
    Public Function GetTileCoords(ByVal x As Integer, ByVal y As Integer) As Point
        ' Returns the tile coordinates (0-47,0-49) as related to the pixel coordinates (0-1535,0-1279)
        ' At the moment this is only used with picMap on Form1, so ee'll need to use the map
        ' scroll position and the map scale to work out the actual x and y coordinates of the map
        ' the mouse is over.

        ' Translate x and y to the map scroll position and the map scale
        x = Int((x + (m_intScrollPosX * m_intMapScale)) / m_intMapScale)
        y = Int((y + (m_intScrollPosY * m_intMapScale)) / m_intMapScale)

        GetTileCoords.X = Int(x / 32)
        GetTileCoords.Y = Int(y / 16)

    End Function

    Public Sub DrawMapToPicBox(picBox As PictureBox)
        ' Copy the visible section of the map to the picMap picturebox and then
        ' draw the hovered tile border on top of it, if it is visible.

        ' If m_bmpMapView is not the same size as the picturebox then make it so.
        If m_bmpMapView.Height <> picBox.Height Or m_bmpMapView.Width <> picBox.Width Then
            m_bmpMapView.Dispose()
            m_gfxMapView = Nothing
            m_bmpMapView = New Bitmap(picBox.Width, picBox.Height)
            m_gfxMapView = Graphics.FromImage(m_bmpMapView)
        End If

        ' ****Update the picturebox****
        ' Clear the picturebox
        m_gfxMapView.Clear(Color.White)

        ' Draw the map background
        DrawBackground(picBox, m_gfxMapView)

        ' Draw the hovered tile border.
        DrawHoveredTileBorder(m_gfxMapView)

        picBox.Image = m_bmpMapView
        g_blnMapViewChanged = False

    End Sub

    Private Sub DrawBackground(picBox As PictureBox, g As Graphics)
        ' Copy a section of the background image from CMap to the picturebox scaled

        Dim rctSrc As New Rectangle(m_intScrollPosX, m_intScrollPosY, _
                                    picBox.Width / m_intMapScale, _
                                    picBox.Height / m_intMapScale)
        Dim rctDest As New Rectangle(0, 0, picBox.Width, picBox.Height)
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor
        g.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality
        g.DrawImage(m_bmpBackground, rctDest, rctSrc, GraphicsUnit.Pixel)

    End Sub

    Private Sub DrawHoveredTileBorder(g As Graphics)
        ' Draw the hovered tile border onto the map view bitmap on top of the map tiles.
        Dim myPen As Pen
        Dim intTile As Integer
        If m_pntHoveredTileCoords.X > -1 And m_pntHoveredTileCoords.Y > -1 And _
            m_pntHoveredTileCoords.X < 80 And m_pntHoveredTileCoords.Y < 48 Then
            ' Rectangle is 32 x 16 pixels * mapscale, offset by mapscrollpos variables
            ' TODO: In the future you'll be able to edit either the map layer or the sprite layer
            ' and be in select mode or draw mode. The tile border height will change in height
            ' depending on what tile/sprite is underneath the cursor or what is to be drawn.
            ' The intTileBorderHeight variable will be used for this.
            Dim myRect As New Rectangle(((m_pntHoveredTileCoords.X * 32) * m_intMapScale) - (m_intScrollPosX * m_intMapScale), _
                            ((m_pntHoveredTileCoords.Y * 16) * m_intMapScale) - (m_intScrollPosY * m_intMapScale), _
                            32 * m_intMapScale, 16 * m_intMapScale)

            ' Draw the hovered tile border rectangle
            ' If we're in select layer 1 or 3 and we're over an object in that layer then set the
            ' border to red, otherwise set it to white. This helps to see objects in the current
            ' layer more easily.
            ' If we're in sequence edit mode then Use GetTileData because the tile may be on
            ' the original map or a sequence change. Otherwise just get from the original map.
            If m_blnSequenceEditing = True Then
                intTile = GetTileData(m_pntHoveredTileCoords.X, m_pntHoveredTileCoords.Y, m_intSelectLayer).m_intType
            Else
                intTile = m_arrMapTiles(m_pntHoveredTileCoords.Y, m_pntHoveredTileCoords.X, m_intSelectLayer).m_intType
            End If
            If m_intSelectLayer > 0 And intTile > 0 Then
                myPen = New Pen(Color.Red)
            Else
                myPen = New Pen(Color.White)
            End If
            g.DrawRectangle(myPen, myRect)

            'Dim myFont As New Font("Arial", 6 * m_intMapScale)
            'g.DrawString("S", myFont, Brushes.Tomato, myRect.X, myRect.Y)
        End If

    End Sub

    Public Sub UpdateMapTiles(tiles As TileMap)
        ' Redraws any map tiles that have been marked as changed in m_arrChangedTiles
        ' Gets the tile data from the original map data in m_arrMapTiles when seq and
        ' stage are both -1. Otherwise gets the map data from 
        ' m_arrobjSequenceList(seq).m_objStages(stage)
        '
        Dim y, x As Integer
        Dim objMapTileData As MapObject
        Dim blnSequenceChangeTile As Boolean

        ' Loop through all map tile locations and check the m_arrChangedTiles array
        ' for changes.
        For y = 0 To 47
            For x = 0 To 79
                If m_arrChangedTiles(y, x) = True Then

                    ' This variable will be set to true true if any tile change at this location
                    ' came from a sequence
                    blnSequenceChangeTile = False

                    ' Always draw the wall layer, draw the fixture and sprite layer
                    ' if the tile type is > 0 and < 99 (99 is the lower half of a
                    ' double layer tile)
                    objMapTileData = GetTileData(x, y, 0)
                    If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                    DrawTile(x, y, 0, objMapTileData.m_intType, False)

                    objMapTileData = GetTileData(x, y, 1)
                    If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                    If objMapTileData.m_intType > 0 And objMapTileData.m_intType < 99 Then
                        DrawTile(x, y, 1, objMapTileData.m_intType, True)
                    End If

                    objMapTileData = GetTileData(x, y, 3)
                    If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                    If objMapTileData.m_intType > 0 And objMapTileData.m_intType < 99 Then
                        DrawTile(x, y, 3, objMapTileData.m_intType, True)
                    End If

                    ' If any tile changes at this location came from a sequence then
                    ' draw the tile highlight
                    If blnSequenceChangeTile = True Then
                        DrawChangeHighlight(x, y, 0)
                    End If

                    ' If this location has the lower tile of a double-height tile then
                    ' redraw the double-height tile at the tile above.
                    If y > 0 Then
                        blnSequenceChangeTile = False
                        ' Check fixture layer
                        If GetTileData(x, y, 1).m_intType = 99 Then
                            ' Draw wall 
                            objMapTileData = GetTileData(x, y - 1, 0)
                            If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                            DrawTile(x, y - 1, 0, objMapTileData.m_intType, False)
                            ' Draw fixture
                            objMapTileData = GetTileData(x, y - 1, 1)
                            If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                            DrawTile(x, y - 1, 1, objMapTileData.m_intType, True)

                            ' If the tile data was from a sequence tile change then draw
                            ' the tile highlight
                            If m_blnTileChangeFound = True Then
                                DrawChangeHighlight(x, y - 1, 0)
                            End If

                        End If
                        ' Check Sprite layer
                        blnSequenceChangeTile = False
                        If GetTileData(x, y, 3).m_intType = 99 Then
                            ' Draw wall, and sprite.
                            objMapTileData = GetTileData(x, y - 1, 0)
                            If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                            DrawTile(x, y - 1, 0, objMapTileData.m_intType, False)
                            ' Deraw fixture if tile is >0 
                            objMapTileData = GetTileData(x, y - 1, 1)
                            If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                            If objMapTileData.m_intType > 0 Then
                                DrawTile(x, y - 1, 1, objMapTileData.m_intType, True)
                            End If
                            ' Draw sprite
                            objMapTileData = GetTileData(x, y - 1, 3)
                            If m_blnTileChangeFound = True Then blnSequenceChangeTile = True
                            DrawTile(x, y - 1, 3, objMapTileData.m_intType, True)

                            ' If the tile data was from a sequence tile change then draw
                            ' the tile highlight
                            If m_blnTileChangeFound = True Then
                                DrawChangeHighlight(x, y - 1, 0)
                            End If

                        End If
                    End If

                End If

                ' Reset changed tile status for this location
                m_arrChangedTiles(y, x) = False
            Next x
        Next y

    End Sub

    Public Sub UpdateSelection(picbox As PictureBox)
        ' Updates the selection picturebox and the properties combobox.

        Dim n As Integer
        Dim strTemp As String
        Dim objMapObject As MapObject

        ' If selected tile coords are <0 or there's now an invalid selection due to the selection
        ' layer changing then clear the picturebox and the property box
        If m_pntSelectedTilePos.X < 0 Or m_pntSelectedTilePos.Y < 0 Then
            ' Clear the selection (Set it to nothing)
            frmMain.cmbPropertyValues.Items.Clear()
            frmMain.cmbPropertyValues.ResetText()
            frmMain.txtPropertyValue.Text = ""
            picbox.Image = Nothing
            Exit Sub
        End If

        ' Get the correct map tile data for this location
        objMapObject = GetTileData(m_pntSelectedTilePos.X, m_pntSelectedTilePos.Y, m_intSelectLayer)

        If m_intSelectLayer > 0 And objMapObject.m_intType = 0 Then
            ' Clear the selection (Set it to nothing)
            frmMain.cmbPropertyValues.Items.Clear()
            frmMain.cmbPropertyValues.ResetText()
            frmMain.txtPropertyValue.Text = ""
            m_pntSelectedTilePos.X = -1
            m_pntSelectedTilePos.Y = -1
            picbox.Image = Nothing
            Exit Sub
        End If
        ' Load any properties into the combobox
        frmMain.cmbPropertyValues.Items.Clear()
        frmMain.cmbPropertyValues.ResetText()
        frmMain.txtPropertyValue.Text = ""

        If objMapObject.m_arrintPropertyValues Is Nothing = False Then
            If objMapObject.m_arrintPropertyValues.Count > 0 Then
                For n = 0 To objMapObject.m_arrintPropertyValues.Count - 1
                    strTemp = "X: " & m_pntSelectedTilePos.X & " Y: " & m_pntSelectedTilePos.Y & _
                        " L: " & m_intSelectLayer & " - " & _
                         CTileMap.m_PropertyNames(objMapObject.m_intType)(n)
                    frmMain.cmbPropertyValues.Items.Add(strTemp)
                Next n
                frmMain.cmbPropertyValues.SelectedIndex = 0
                frmMain.txtPropertyValue.Text = objMapObject.m_arrintPropertyValues(0)
            End If
        End If

        DrawSelectionPicBox(picbox, m_gfxSelectedTile)

    End Sub

    Private Sub DrawTile(x As Integer, y As Integer, layer As Integer, tile As Integer, masked As Boolean)
        ' Draws a tile to the map bitmap at the given location, with or without a transparency mask
        ' Get the sprite source and destinations (Get tile data from the TilePicker class instance)
        Dim rctSrc, rctDest As Rectangle
        Dim g As Graphics
        g = Graphics.FromImage(m_bmpBackground)

        ' Set the transparent colour to top left pixel of tiles
        Dim attr As New ImageAttributes
        attr.SetColorKey(CTileMap.m_bmpTiles.GetPixel(0, 0), CTileMap.m_bmpTiles.GetPixel(0, 0))

        ' Calculate the source and destination rectangles for the tile
        rctSrc.X = (tile Mod 8) * 32
        rctSrc.Y = Int((tile \ 8) * 32) + (32 - CTileMap.m_TileHeights(tile))
        rctSrc.Width = 32
        rctSrc.Height = CTileMap.m_TileHeights(tile)

        rctDest.X = x * 32
        rctDest.Y = y * 16
        rctDest.Width = 32
        rctDest.Height = CTileMap.m_TileHeights(tile)

        If masked = False Then
            ' Draw the tile without transparency (Normally for wall tiles (Layer 0))
            g.DrawImage(CTileMap.m_bmpTiles, rctDest, rctSrc, GraphicsUnit.Pixel)
        Else
            ' Draw the tile with transparency (Normally for map layer 1 or 3)
            g.DrawImage(CTileMap.m_bmpTiles, rctDest, rctSrc.X, rctSrc.Y, rctSrc.Width, _
                        rctSrc.Height, GraphicsUnit.Pixel, attr)
        End If
    End Sub


    Public Sub GetSequenceChanges(seq As Integer, stage As Integer)
        ' Gets a list of tile changes up to given sequence and stage number and back through
        ' any sequences that the sequence is set as dependant on. 
        ' We'll normally pass the currently selected sequence and the currently selected
        ' stage - 1 as parameters

        Dim n, m, x As Integer
        Dim intLastStage As Integer ' The last stage to loop through to within the sequence.
        Dim arrintSeqChain As New List(Of Integer)
        Dim arrobjTileChanges As New List(Of SequenceStage.tileChg)
        Dim objTmpTileChg As SequenceStage.tileChg

        ' Add the current sequence if stage is >=0
        If stage >= 0 Then
            arrintSeqChain.Add(seq)
        End If

        ' Add any further sequences that are dependant on this one.
        n = seq
        While CMap.m_arrobjSequenceList(n).m_intDependsOnSequence > -1
            n = CMap.m_arrobjSequenceList(n).m_intDependsOnSequence
            arrintSeqChain.Add(n)
        End While

        ' Reverse the sequence list so we have a list of dependant 
        'sequences in chronological order up to the current sequence.
        arrintSeqChain.Reverse()

        ' Loop through the sequences and stages in the change to get tile changes
        ' If this is the last sequence in the chain, loop through to the stage given in
        ' the procedure parameter.
        For n = 0 To arrintSeqChain.Count - 1
            intLastStage = If(n = CMap.m_arrobjSequenceList(arrintSeqChain(n)).m_objStages.Count - 1, CMap.m_arrobjSequenceList(arrintSeqChain(n)).m_objStages.Count - 1, stage)
            For m = 0 To intLastStage
                Select Case CMap.m_arrobjSequenceList(arrintSeqChain(n)).m_objStages(m).m_intChangeType
                    Case SequenceStage.StageType.ChangeTiles
                        ' Add the list of tile changes at this stage to the big list.
                        For x = 0 To CMap.m_arrobjSequenceList(arrintSeqChain(n)).m_objStages(m).m_objTileChanges.Count - 1
                            With CMap.m_arrobjSequenceList(arrintSeqChain(n)).m_objStages(m).m_objTileChanges(x)
                                ' In the line below I'm storing the location as a single nuimber. I also need
                                ' to store the map layer as well. The maximum location value is 3839, which fits into
                                ' 12 bits. I can use the next 2 bits to store the layer. (00 = layer 0, 01 = layer 2, 10 = layer 3)
                                ' Get the layer that the new tiile change is in. - DONE
                                'objTmpTileChg.intLocation = ((.yPos * 48) + .xPos) + (CTileMap.m_TileLayers(.mapObj.m_intType) << 12)
                                objTmpTileChg.intLocation = ((.yPos * 48) + .xPos) + (.layer << 12)
                                objTmpTileChg.intStage = m
                                objTmpTileChg.intSeq = n
                                objTmpTileChg.mapObj = New MapObject(.mapObj.m_intType)
                                objTmpTileChg.mapObj.m_arrintPropertyValues = .mapObj.m_arrintPropertyValues
                                arrobjTileChanges.Add(objTmpTileChg)

                                ' Mark the tile as changed
                                m_arrChangedTiles(.yPos, .xPos) = True
                            End With
                        Next x
                End Select
                ' A set of tile changes in one stage, if any, was added
            Next m
            ' All tile changes in the sequence, if any, were added
        Next n
        ' All tile changes in the dependant sequence chain, if any, were added

        ' If there was more than one individual tile change found then loop through the
        ' list and cull the all but the newest change for each tile in each location and layer.
        If arrobjTileChanges.Count > 1 Then

            ' Sort the tile change list by location
            arrobjTileChanges.Sort(Function(a, b) a.intLocation.CompareTo(b.intLocation))

            ' Get the first tile location
            m = arrobjTileChanges(0).intLocation

            n = 1 ' Counter for the arrobjTileChanges list
            Do
                ' See if this is the same tile location and layer as the previous one
                'If arrobjTileChanges(n).intLocation = m Then
                '    ' Cull the oldest
                '    If arrobjTileChanges(m).intSeq = arrobjTileChanges(n).intSeq Then
                '        If arrobjTileChanges(m).intStage < arrobjTileChanges(n).intStage Then
                '            arrobjTileChanges.RemoveAt(m)
                '            n = n - 1
                '        Else
                '            arrobjTileChanges.RemoveAt(n)
                '            n = n - 1
                '        End If
                '    ElseIf arrobjTileChanges(m).intSeq < arrobjTileChanges(n).intSeq Then
                '        arrobjTileChanges.RemoveAt(m)
                '        n = n - 1
                '    Else
                '        arrobjTileChanges.RemoveAt(n)
                '        n = n - 1
                '    End If
                'End If
                If arrobjTileChanges(n).intLocation = m Then
                    ' Cull the oldest
                    If arrobjTileChanges(n).intSeq = arrobjTileChanges(n - 1).intSeq Then
                        If arrobjTileChanges(n - 1).intStage < arrobjTileChanges(n).intStage Then
                            arrobjTileChanges.RemoveAt(n - 1)
                            n = n - 1
                        Else
                            arrobjTileChanges.RemoveAt(n)
                            n = n - 1
                        End If
                    ElseIf arrobjTileChanges(n - 1).intSeq < arrobjTileChanges(n).intSeq Then
                        arrobjTileChanges.RemoveAt(n - 1)
                        n = n - 1
                    Else
                        arrobjTileChanges.RemoveAt(n)
                        n = n - 1
                    End If
                End If
                n = n + 1
            Loop Until n >= arrobjTileChanges.Count
        End If

        ' arrobjTileChanges now contains only the latest change for each tile/layer
        ' Note that for changes to tile properties only, the tile number must also be set within the tile change.
        ' Transfer the arrobjTileChanges list data to m_arrMapTiles and store a record of the change
        ' in the m_arrSeqTileChanges list, which will be used for reverting back to the original map.
        m_arrpntSeqTileChanges.Clear()
        Dim objTempTileChange As SequenceStage.TileChange

        Dim blnInserted As Boolean = False
        ' Loop through the changes in arrobjTileChanges, if any
        If arrobjTileChanges.Count > 0 Then
            For n = 0 To arrobjTileChanges.Count - 1

                ' Setup the Tile Change object
                ' Get the layer
                objTempTileChange.layer = arrobjTileChanges(n).intLocation >> 12
                ' Get the x and y location. 
                ' Mask out the layer value (bits 12 and 13)
                m = Int(arrobjTileChanges(n).intLocation And &HFFF)
                objTempTileChange.yPos = Int(m \ 48)
                objTempTileChange.xPos = m Mod 48
                objTempTileChange.mapObj = New MapObject(arrobjTileChanges(n).mapObj.m_intType)
                objTempTileChange.mapObj.m_arrintPropertyValues = arrobjTileChanges(n).mapObj.m_arrintPropertyValues
                objTempTileChange.mapObj.m_contents = arrobjTileChanges(n).mapObj.m_contents

                ' Add the change to m_arrpntSeqTileChanges
                m_arrpntSeqTileChanges.Add(New Point(objTempTileChange.xPos, objTempTileChange.yPos))

                ' Apply the change to m_arrMapTiles (NB: A copy of the the original m_arrMapTiles
                ' was saved earlier so we can revert back after we're done sequence editing.)
                With Me.m_arrMapTiles(objTempTileChange.yPos, objTempTileChange.xPos, objTempTileChange.layer)
                    .m_intType = objTempTileChange.mapObj.m_intType
                    .m_arrintPropertyValues = objTempTileChange.mapObj.m_arrintPropertyValues
                    .m_contents = objTempTileChange.mapObj.m_contents
                End With
            Next n
        End If

    End Sub

    Public Sub UpdateStageChangeHighlighting(seq As Integer, stage As Integer)
        ' Mark only the given sequence/stage tiles as changed.
        ' Call UpdateMapTiles with the given sequence and stage as parameters.
        ' UpdateMapTiles will deal with applying the highlighting.
        Dim n As Integer
        With m_arrobjSequenceList(seq).m_objStages(stage)
            If .m_objTileChanges.Count > 0 Then
                For n = 0 To .m_objTileChanges.Count - 1
                    m_arrChangedTiles(.m_objTileChanges(n).yPos, .m_objTileChanges(n).xPos _
                                      ) = True
                Next n
            End If
        End With

        UpdateMapTiles(CTileMap)

    End Sub

    Private Sub DrawChangeHighlight(x As Integer, y As Integer, type As Integer)
        Dim myPen As Pen
        Dim myColor, myColorB As Color
        myColor = Color.FromArgb(50, 200, 0, 0)
        myColorB = Color.FromArgb(200, 0, 0, 0)
        Dim myBrush As New System.Drawing.Drawing2D.HatchBrush(Drawing2D.HatchStyle.Wave, myColor, myColorB)
        Dim myBrushB As New SolidBrush(myColor)
        Dim g As Graphics

        g = Graphics.FromImage(m_bmpBackground)

        Dim myRect As New Rectangle(x * 32, y * 16, 32, 16)

        If type = 0 Then
            myPen = New Pen(Color.Red)
        Else
            myPen = New Pen(Color.Red)
        End If

        'g.DrawRectangle(myPen, myRect)
        g.FillRectangle(myBrushB, myRect)

    End Sub

    Public Sub RevertMapChanges(seq As Integer, stage As Integer)
        ' Returns the map to its original state before the given sequence and stage

        If m_intLastSequence >= 0 And m_intLastStage >= 0 Then

            ' Restore the original map data using the DeepClone helper function
            m_arrMapTiles = DeepClone(m_arrMapTilesOrig)

            ' Mark sequence dependancy changes, if any
            If m_arrpntSeqTileChanges.Count > 0 Then
                Dim n As Integer
                For n = 0 To m_arrpntSeqTileChanges.Count - 1
                    ' Set the location as changed 
                    m_arrChangedTiles(m_arrpntSeqTileChanges(n).Y, _
                     m_arrpntSeqTileChanges(n).X) = True
                Next n
            End If
            ' Mark current stage changes, if any
            With m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage)
                If .m_objTileChanges.Count > 0 Then
                    For n = 0 To .m_objTileChanges.Count - 1
                        ' Set the location as changed 
                        m_arrChangedTiles(.m_objTileChanges(n).yPos, _
                                          .m_objTileChanges(n).xPos) = True
                    Next n
                End If
            End With

        End If
    End Sub

    Public Function GetTileData(x As Integer, y As Integer, layer As Integer) As MapObject
        ' Helper function that takes a map location and returns the correct tile data
        ' whether we're in sequence editing mode or not and whether there's a tile change
        ' at the location or not.
        Dim objMapObject As MapObject

        objMapObject = Nothing

        ' Lookup a tile change if we're in sequence editing mode and a sequence is selected
        If m_blnSequenceEditing = True And m_intLastSequence >= 0 Then
            objMapObject = m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                .LookupTileChange(x, y, layer)
        End If

        ' Get from the original map data if there was no tile change.
        If objMapObject Is Nothing Then
            objMapObject = New MapObject(m_arrMapTiles(y, x, layer).m_intType)
            objMapObject.m_arrintPropertyValues = m_arrMapTiles(y, x, layer).m_arrintPropertyValues
            objMapObject.m_contents = m_arrMapTiles(y, x, layer).m_contents
            m_blnTileChangeFound = False
        Else
            ' Let the program know we got the data from a tile change 
            m_blnTileChangeFound = True
        End If

        Return objMapObject
    End Function

    Public Sub SetContentsData(x As Integer, y As Integer, layer As Integer, contents As MapObject)
        ' Helper function for setting a map location's contents data
        Dim objMapObject As MapObject

        objMapObject = Nothing

        ' Lookup a tile change if we're in sequence editing mode and a sequence is selected
        If m_blnSequenceEditing = True And m_intLastSequence >= 0 Then
            objMapObject = m_arrobjSequenceList(m_intLastSequence).m_objStages(m_intLastStage) _
                .LookupTileChange(x, y, layer)
        End If

        ' If objMapObject is nothing then set the original map tile contents
        If objMapObject Is Nothing Then
            m_arrMapTiles(y, x, layer).m_contents = contents
        Else
            ' Set the objMapObject contents
            objMapObject.m_contents = contents
        End If

    End Sub

    Public Sub ChangeWallTiles()
        Dim rctSrc As Rectangle
        Dim g As Graphics
        Dim n, m As Integer

        ' Setup the source rectangle
        rctSrc = New Rectangle(0, m_intWallType * 16, 256, 16)

        ' Copy the tiles
        g = Graphics.FromImage(CTileMap.m_bmpTiles)
        g.DrawImage(My.Resources.EntombedWalls, 0, 16, rctSrc, GraphicsUnit.Pixel)
        g.Dispose()

        ' Mark all tiles as changed
        For n = 0 To 47
            For m = 0 To 79
                CMap.m_arrChangedTiles(n, m) = True
            Next m
        Next n

        ' Update the tiles and redraw the map
        CMap.UpdateMapTiles(CTileMap)
        g_blnMapViewChanged = True

    End Sub

    Public Sub FindTriggeringSwitch(seq As Integer)
        ' Looks for the location of the triggering switch for the given sequence number
        ' We will be in sequence editing mode. The switch will be in m_arrMapTiles and not in a current tile change.
        Dim n, m As Integer
        m_pntTriggeringSwitchLocation.X = -1
        m_pntTriggeringSwitchLocation.Y = -1
        For n = 0 To 47
            For m = 0 To 79
                If m_arrMapTiles(n, m, 1).m_intType = 30 Then
                    If m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                        If m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) = seq Then
                            m_pntTriggeringSwitchLocation.X = m
                            m_pntTriggeringSwitchLocation.Y = m
                            Exit Sub
                        End If
                    End If
                End If
            Next m
        Next n
    End Sub
End Class
