﻿<Serializable()>
Public Class MapObject
    ' This class stores all data related to tiles/objects on a map

    ' Each tile and layer on the map will be an instance of the MapObject class
    Public Property m_intType As Integer ' Corresponds to the tile number in the tile map
    Public Property m_arrintPropertyValues As List(Of Integer)
    Public Property m_contents As MapObject ' Only applies to containers

    Public Sub New(type As Integer)
        m_intType = type
        m_arrintPropertyValues = Nothing
        m_contents = Nothing
        InitProperties(type)
    End Sub

    Private Sub InitProperties(type As Integer)
        ' Called when a new Map object class instance is created
        ' Sets the property values based on the object type and 
        ' set default value where applicable

        Select Case type
            Case 19 ' Coin
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(250) ' Points
            Case 20 ' Hourglass
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(1) ' Seconds
            Case 22 ' Quiver
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(1) ' Arrows
            Case 23 ' Chest
                m_arrintPropertyValues = New List(Of Integer)
                m_contents = New MapObject(17) ' Ankh is default contents
            Case 25 ' Vase
                m_arrintPropertyValues = New List(Of Integer)
                m_contents = New MapObject(17) ' Ankh is default contents
                Me.m_arrintPropertyValues.Add(1) 'Hitpoints
            Case 26, 27 ' Snake and mummy
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(1) ' HitPoints
                Me.m_arrintPropertyValues.Add(1) ' xMin
                Me.m_arrintPropertyValues.Add(1) ' xMax
                Me.m_arrintPropertyValues.Add(1) ' StartingDir, 0=left 1=right
                Me.m_arrintPropertyValues.Add(1) ' FireRate(Snakes only)
            Case 28, 29 ' Left Gun and Right Gun
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(-1) ' Bullets (-1 = unlimited)
                Me.m_arrintPropertyValues.Add(60) ' interval (Frames between each shot)
            Case 30 ' Switch
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(0) ' Sequence number (0 by default)
            Case 33 ' Moving platform
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(1) ' IsMoving
                Me.m_arrintPropertyValues.Add(1) ' xMin
                Me.m_arrintPropertyValues.Add(1) ' xMax
                Me.m_arrintPropertyValues.Add(1) ' StartingDir, 0=left 1=right
                Me.m_arrintPropertyValues.Add(1) ' Speed
            Case 38 ' Teleporter
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(1) ' xPos
                Me.m_arrintPropertyValues.Add(1) ' yPos
                Me.m_arrintPropertyValues.Add(1) ' Remove after touching (0=no, 1=yes)
                '({"Bullets", "interval", "lifespan"}),
                '({"Bullets", "interval", "lifespan"}),
                '({"type", "startDir"})}
            Case 39, 40 ' Left Ball Gun and Right Ball Gun
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(-1) ' Bullets
                Me.m_arrintPropertyValues.Add(120) ' Interval
                Me.m_arrintPropertyValues.Add(180) ' Lifespan
                Me.m_arrintPropertyValues.Add(1) ' Weight (Affects bounce and speed)
            Case 41 ' Moving Block
                m_arrintPropertyValues = New List(Of Integer)
                Me.m_arrintPropertyValues.Add(0) ' Type, 0=Rock, 1=Fire, 2=Ice
                Me.m_arrintPropertyValues.Add(1) ' StartingDir,  0=left 1=right 2=none
                Me.m_arrintPropertyValues.Add(-1) ' Lifespan after moving. In frames. -1 = unlimited.
        End Select
    End Sub
End Class


