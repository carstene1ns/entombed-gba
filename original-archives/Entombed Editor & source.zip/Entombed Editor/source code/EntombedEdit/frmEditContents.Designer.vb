﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditContents
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbType = New System.Windows.Forms.ComboBox()
        Me.lblType = New System.Windows.Forms.Label()
        Me.lblProperties = New System.Windows.Forms.Label()
        Me.cmbProperties = New System.Windows.Forms.ComboBox()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.txtProperty = New System.Windows.Forms.TextBox()
        Me.cmdSetProperty = New System.Windows.Forms.Button()
        Me.cmdSetType = New System.Windows.Forms.Button()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmbType
        '
        Me.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbType.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbType.FormattingEnabled = True
        Me.cmbType.Location = New System.Drawing.Point(79, 56)
        Me.cmbType.Name = "cmbType"
        Me.cmbType.Size = New System.Drawing.Size(147, 22)
        Me.cmbType.TabIndex = 0
        '
        'lblType
        '
        Me.lblType.AutoSize = True
        Me.lblType.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblType.Location = New System.Drawing.Point(12, 56)
        Me.lblType.Name = "lblType"
        Me.lblType.Size = New System.Drawing.Size(59, 14)
        Me.lblType.TabIndex = 1
        Me.lblType.Text = "Item type"
        '
        'lblProperties
        '
        Me.lblProperties.AutoSize = True
        Me.lblProperties.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProperties.Location = New System.Drawing.Point(12, 102)
        Me.lblProperties.Name = "lblProperties"
        Me.lblProperties.Size = New System.Drawing.Size(66, 14)
        Me.lblProperties.TabIndex = 3
        Me.lblProperties.Text = "Properties"
        '
        'cmbProperties
        '
        Me.cmbProperties.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbProperties.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbProperties.FormattingEnabled = True
        Me.cmbProperties.Location = New System.Drawing.Point(79, 102)
        Me.cmbProperties.Name = "cmbProperties"
        Me.cmbProperties.Size = New System.Drawing.Size(99, 22)
        Me.cmbProperties.TabIndex = 2
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(102, 143)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(88, 31)
        Me.cmdOK.TabIndex = 4
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'txtProperty
        '
        Me.txtProperty.Location = New System.Drawing.Point(184, 104)
        Me.txtProperty.Name = "txtProperty"
        Me.txtProperty.Size = New System.Drawing.Size(42, 20)
        Me.txtProperty.TabIndex = 5
        '
        'cmdSetProperty
        '
        Me.cmdSetProperty.Location = New System.Drawing.Point(232, 104)
        Me.cmdSetProperty.Name = "cmdSetProperty"
        Me.cmdSetProperty.Size = New System.Drawing.Size(42, 20)
        Me.cmdSetProperty.TabIndex = 6
        Me.cmdSetProperty.Text = "Set"
        Me.cmdSetProperty.UseVisualStyleBackColor = True
        '
        'cmdSetType
        '
        Me.cmdSetType.Location = New System.Drawing.Point(232, 56)
        Me.cmdSetType.Name = "cmdSetType"
        Me.cmdSetType.Size = New System.Drawing.Size(42, 20)
        Me.cmdSetType.TabIndex = 7
        Me.cmdSetType.Text = "Set"
        Me.cmdSetType.UseVisualStyleBackColor = True
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(15, 15)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(55, 16)
        Me.lblDescription.TabIndex = 8
        Me.lblDescription.Text = "Label1"
        '
        'frmEditContents
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(304, 186)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.cmdSetType)
        Me.Controls.Add(Me.cmdSetProperty)
        Me.Controls.Add(Me.txtProperty)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.lblProperties)
        Me.Controls.Add(Me.cmbProperties)
        Me.Controls.Add(Me.lblType)
        Me.Controls.Add(Me.cmbType)
        Me.Name = "frmEditContents"
        Me.Text = "Contents editor"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbType As System.Windows.Forms.ComboBox
    Friend WithEvents lblType As System.Windows.Forms.Label
    Friend WithEvents lblProperties As System.Windows.Forms.Label
    Friend WithEvents cmbProperties As System.Windows.Forms.ComboBox
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents txtProperty As System.Windows.Forms.TextBox
    Friend WithEvents cmdSetProperty As System.Windows.Forms.Button
    Friend WithEvents cmdSetType As System.Windows.Forms.Button
    Friend WithEvents lblDescription As System.Windows.Forms.Label
End Class
