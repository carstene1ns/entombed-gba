﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMapProperties
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblWallType = New System.Windows.Forms.Label()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.cmbWallType = New System.Windows.Forms.ComboBox()
        Me.lblProperties = New System.Windows.Forms.Label()
        Me.txtXLoc = New System.Windows.Forms.TextBox()
        Me.cmdSetPlayerStartLocation = New System.Windows.Forms.Button()
        Me.txtYLoc = New System.Windows.Forms.TextBox()
        Me.lblX = New System.Windows.Forms.Label()
        Me.lblY = New System.Windows.Forms.Label()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.lblMapDescription = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblWallType
        '
        Me.lblWallType.AutoSize = True
        Me.lblWallType.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWallType.Location = New System.Drawing.Point(12, 24)
        Me.lblWallType.Name = "lblWallType"
        Me.lblWallType.Size = New System.Drawing.Size(56, 14)
        Me.lblWallType.TabIndex = 1
        Me.lblWallType.Text = "Wall type"
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(72, 203)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(88, 31)
        Me.cmdOK.TabIndex = 4
        Me.cmdOK.Text = "OK"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'cmbWallType
        '
        Me.cmbWallType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbWallType.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbWallType.FormattingEnabled = True
        Me.cmbWallType.Location = New System.Drawing.Point(77, 21)
        Me.cmbWallType.Name = "cmbWallType"
        Me.cmbWallType.Size = New System.Drawing.Size(83, 22)
        Me.cmbWallType.TabIndex = 2
        '
        'lblProperties
        '
        Me.lblProperties.AutoSize = True
        Me.lblProperties.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProperties.Location = New System.Drawing.Point(12, 90)
        Me.lblProperties.Name = "lblProperties"
        Me.lblProperties.Size = New System.Drawing.Size(120, 14)
        Me.lblProperties.TabIndex = 3
        Me.lblProperties.Text = "Player Start Location"
        '
        'txtXLoc
        '
        Me.txtXLoc.Location = New System.Drawing.Point(138, 69)
        Me.txtXLoc.Name = "txtXLoc"
        Me.txtXLoc.Size = New System.Drawing.Size(42, 20)
        Me.txtXLoc.TabIndex = 5
        '
        'cmdSetPlayerStartLocation
        '
        Me.cmdSetPlayerStartLocation.Location = New System.Drawing.Point(186, 88)
        Me.cmdSetPlayerStartLocation.Name = "cmdSetPlayerStartLocation"
        Me.cmdSetPlayerStartLocation.Size = New System.Drawing.Size(42, 20)
        Me.cmdSetPlayerStartLocation.TabIndex = 6
        Me.cmdSetPlayerStartLocation.Text = "Set"
        Me.cmdSetPlayerStartLocation.UseVisualStyleBackColor = True
        '
        'txtYLoc
        '
        Me.txtYLoc.Location = New System.Drawing.Point(138, 109)
        Me.txtYLoc.Name = "txtYLoc"
        Me.txtYLoc.Size = New System.Drawing.Size(42, 20)
        Me.txtYLoc.TabIndex = 8
        '
        'lblX
        '
        Me.lblX.AutoSize = True
        Me.lblX.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblX.Location = New System.Drawing.Point(152, 53)
        Me.lblX.Name = "lblX"
        Me.lblX.Size = New System.Drawing.Size(14, 14)
        Me.lblX.TabIndex = 9
        Me.lblX.Text = "X"
        '
        'lblY
        '
        Me.lblY.AutoSize = True
        Me.lblY.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblY.Location = New System.Drawing.Point(152, 94)
        Me.lblY.Name = "lblY"
        Me.lblY.Size = New System.Drawing.Size(14, 14)
        Me.lblY.TabIndex = 10
        Me.lblY.Text = "Y"
        '
        'lblInfo
        '
        Me.lblInfo.AutoSize = True
        Me.lblInfo.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.Location = New System.Drawing.Point(12, 109)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(109, 14)
        Me.lblInfo.TabIndex = 11
        Me.lblInfo.Text = "X=1 to 77, Y=1 to 45"
        '
        'txtDescription
        '
        Me.txtDescription.Location = New System.Drawing.Point(15, 169)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(213, 20)
        Me.txtDescription.TabIndex = 12
        '
        'lblMapDescription
        '
        Me.lblMapDescription.AutoSize = True
        Me.lblMapDescription.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMapDescription.Location = New System.Drawing.Point(70, 152)
        Me.lblMapDescription.Name = "lblMapDescription"
        Me.lblMapDescription.Size = New System.Drawing.Size(96, 14)
        Me.lblMapDescription.TabIndex = 13
        Me.lblMapDescription.Text = "Map Description"
        '
        'frmMapProperties
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(250, 253)
        Me.Controls.Add(Me.lblMapDescription)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.lblY)
        Me.Controls.Add(Me.lblX)
        Me.Controls.Add(Me.txtYLoc)
        Me.Controls.Add(Me.cmdSetPlayerStartLocation)
        Me.Controls.Add(Me.txtXLoc)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.lblProperties)
        Me.Controls.Add(Me.cmbWallType)
        Me.Controls.Add(Me.lblWallType)
        Me.Name = "frmMapProperties"
        Me.Text = "Map Properties"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblWallType As System.Windows.Forms.Label
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents cmbWallType As System.Windows.Forms.ComboBox
    Friend WithEvents lblProperties As System.Windows.Forms.Label
    Friend WithEvents txtXLoc As System.Windows.Forms.TextBox
    Friend WithEvents cmdSetPlayerStartLocation As System.Windows.Forms.Button
    Friend WithEvents txtYLoc As System.Windows.Forms.TextBox
    Friend WithEvents lblX As System.Windows.Forms.Label
    Friend WithEvents lblY As System.Windows.Forms.Label
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents lblMapDescription As System.Windows.Forms.Label
End Class
