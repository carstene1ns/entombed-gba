﻿Imports System.IO

Partial Public Class Map
    Private Const END_MARKER_OBJECT = -2
    Private Const END_MARKER_STAGE = -4
    Private Const END_MARKER_SEQUENCE = -5
    Private Const END_MARKER_SECTION = -10

    ' In the object property lookup table, bit 5 is set when the object is a container
    Private Const CONTAINER_BIT = 5


    Public Function LoadMap(fileName As String)
        ' Load map data from a given file
        Dim result As Integer
        Dim counter As Integer
        Dim n, m, i, x As Integer
        Dim l, s As Integer ' Stores lines read and section reached, used for debugging
        Dim intSeq, intStage As Integer ' Counters for sequence and stage
        Dim objTileChange As SequenceStage.TileChange
        Dim tmpCheckpoint As CheckPoint
        Dim lstSeq As List(Of Integer) ' For checkpoint activated sequence list
        Dim reader As StreamReader = _
            New StreamReader(fileName)

        ' Clear any existing map info
        'Me.m_arrobjSequenceList = Nothing
        'Me.m_checkPoints = Nothing


        Try
            l = 0 : s = 0 ' Reset lines read counter and section counter
            ' Load wall layer tiles
            For n = 0 To 47
                For m = 0 To 79
                    Me.m_arrChangedTiles(n, m) = True
                    Me.m_arrMapTiles(n, m, 0).m_intType = reader.ReadLine : l = l + 1
                Next m
            Next n
            ' Load fixture layer tiles
            s = 1 ' Section marker
            For n = 0 To 47
                For m = 0 To 79
                    Me.m_arrChangedTiles(n, m) = True
                    Me.m_arrMapTiles(n, m, 1).m_intType = reader.ReadLine : l = l + 1
                Next m
            Next n

            ' Load any sprite objects
            While Not reader.EndOfStream And i > -10
                s = 2 ' Section marker
                i = reader.ReadLine : l = l + 1 'Tile
                If i > -10 Then
                    m = reader.ReadLine : l = l + 1 'X coord
                    n = reader.ReadLine : l = l + 1 'Y coord
                    Me.m_arrMapTiles(n, m, 3).m_intType = i
                    Me.m_arrChangedTiles(n, m) = True
                End If
            End While

            ' Load map object properties
            ' Layer 1
            ' Read the first coordinate value, if any
            m = reader.ReadLine : l = l + 1 ' X coord
            While Not reader.EndOfStream And m > -10
                s = 3 ' Section marker
                If m > -10 Then
                    n = reader.ReadLine : l = l + 1 'Y coord
                    Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues = New List(Of Integer)
                    ' Read the property values
                    i = reader.ReadLine : l = l + 1 ' First property value
                    While i > END_MARKER_OBJECT
                        Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Add(i)
                        i = reader.ReadLine : l = l + 1
                    End While
                End If
                ' Read the next value
                m = reader.ReadLine : l = l + 1
            End While

            ' Layer 3
            ' Read the first coordinate value, if any
            m = reader.ReadLine : l = l + 1 ' X coord
            While Not reader.EndOfStream And m > -10
                s = 4 ' Section marker
                If m > -10 Then
                    n = reader.ReadLine : l = l + 1 'Y coord
                    Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues = New List(Of Integer)
                    ' Read the property values
                    i = reader.ReadLine : l = l + 1 ' First property value
                    While i > -2
                        Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues.Add(i)
                        i = reader.ReadLine : l = l + 1
                    End While
                End If
                ' Read the next value
                m = reader.ReadLine : l = l + 1
            End While

            ' Load container data (Layer 1 only)
            m = reader.ReadLine : l = l + 1 ' X coordinate if not -10
            While Not reader.EndOfStream And m > -10
                s = 5 ' Section marker
                While m > END_MARKER_OBJECT
                    ' Read the Y coordinate
                    n = reader.ReadLine : l = l + 1
                    ' Add the contents tile type
                    Me.m_arrMapTiles(n, m, 1).m_contents = New MapObject(reader.ReadLine) : l = l + 1
                    ' Look for any properties of the contents object
                    i = 0 ' Property counter
                    x = reader.ReadLine : l = l + 1
                    While x > END_MARKER_OBJECT
                        ' Add a property
                        Me.m_arrMapTiles(n, m, 1).m_contents.m_arrintPropertyValues(i) = x
                        i = i + 1 ' Increment the property counter
                        x = reader.ReadLine : l = l + 1
                    End While
                    ' Attempt to read the next x coordinate, or -10 if end of contents section.
                    m = reader.ReadLine : l = l + 1
                End While
            End While

            ' ***Read any sequence and stage data***
            ' Initialize the sequences. Begin at sequence 0, stage 0
            intSeq = 0
            intStage = 0
            counter = 0
            m_arrobjSequenceList.Clear()

            ' Read the next value, and if it's not -10 then sequence data exists.
            m = reader.ReadLine : l = l + 1
            counter = counter + 1
            While Not reader.EndOfStream And m > -10
                s = 6 ' Section marker
                ' Add a new sequence to the list and Read the sequence properties
                m_arrobjSequenceList.Add(New Sequence)
                m_arrobjSequenceList(intSeq).m_intDependsOnSequence = m
                m_arrobjSequenceList(intSeq).m_blnLoop = reader.ReadLine : l = l + 1
                m_arrobjSequenceList(intSeq).m_blnAlwaysOn = reader.ReadLine : l = l + 1
                m = reader.ReadLine : l = l + 1 ' Get next value
                counter = counter + 3
                ' While loop for reading each sequence
                While m > END_MARKER_SEQUENCE
                    ' Add a new stage and read the stage properties
                    m_arrobjSequenceList(intSeq).m_objStages.Add(New SequenceStage)
                    m_arrobjSequenceList(intSeq).m_objStages(intStage).m_intChangeType = m
                    m_arrobjSequenceList(intSeq).m_objStages(intStage).m_intDelayFrames = reader.ReadLine : l = l + 1
                    m_arrobjSequenceList(intSeq).m_objStages(intStage).m_blnDelayFlash = reader.ReadLine : l = l + 1
                    m_arrobjSequenceList(intSeq).m_objStages(intStage).m_intToggleSequence = reader.ReadLine : l = l + 1
                    m = reader.ReadLine : l = l + 1 ' Get next value
                    counter = counter + 4
                    ' While loop for reading each stage's data
                    While m > END_MARKER_STAGE
                        ' Read tile type, x,y,layer
                        objTileChange.mapObj = New MapObject(m)
                        objTileChange.xPos = reader.ReadLine : l = l + 1
                        objTileChange.yPos = reader.ReadLine : l = l + 1
                        objTileChange.layer = reader.ReadLine : l = l + 1
                        ' Try to read this object's properties until a END_MARKER_OBJECT is reached.
                        ' There may not be any properties but there will always be a END_MARKER_OBJECT.
                        m = reader.ReadLine : l = l + 1
                        counter = counter + 4
                        i = 0 ' Property counter
                        While m > END_MARKER_OBJECT
                            ' Set the property value
                            objTileChange.mapObj.m_arrintPropertyValues(i) = m
                            i = i + 1 ' Increment the property counter
                            m = reader.ReadLine : l = l + 1
                            counter = counter + 1
                        End While

                        ' Try to read a contents entry until a END_MARKER_OBJECT is reached.
                        ' There may not be a contents entry but there will always be a END_MARKER_OBJECT.
                        ' If there was a contents entry, read the tile type then try to read
                        ' any properties until a END_MARKER_OBJECT is reached. 
                        m = reader.ReadLine : l = l + 1
                        counter = counter + 1
                        While m > END_MARKER_OBJECT
                            ' Add the contents tile type
                            objTileChange.mapObj.m_contents = New MapObject(m)
                            m = reader.ReadLine : l = l + 1
                            counter = counter + 1
                            ' Look for any properties of the contents object
                            i = 0 ' Property counter
                            While m > END_MARKER_OBJECT
                                ' Add a property
                                objTileChange.mapObj.m_contents.m_arrintPropertyValues(i) = m
                                i = i + 1 ' Increment the property counter
                                m = reader.ReadLine : l = l + 1
                                counter = counter + 1
                            End While
                        End While
                        'Write the object into the current sequence/stage tile changes list
                        m_arrobjSequenceList(intSeq).m_objStages(intStage).m_objTileChanges.Add(objTileChange)
                        ' Clear the tile change object
                        objTileChange = Nothing
                        ' Read the next number
                        m = reader.ReadLine : l = l + 1
                        counter = counter + 1
                    End While

                    ' Increment the stage
                    intStage = intStage + 1
                    ' Read the next number to skip past the end stage marker
                    m = reader.ReadLine : l = l + 1
                    counter = counter + 1

                End While

                ' Increment the sequence and reset the stage
                intSeq = intSeq + 1
                intStage = 0
                ' Read the next number to skip past the end sequence marker
                m = reader.ReadLine : l = l + 1
                counter = counter + 1

            End While
            ' A -10 was reached, so we're at the end of the sequences section.

            ' Read the next line
            m = reader.ReadLine : l = l + 1

            ' Load the checkpoint data 
            n = 0 ' CheckPoint counter
            CMap.m_checkPoints = New List(Of CheckPoint)
            While Not reader.EndOfStream And m > -10
                s = 7 ' Section marker
                ' Add a new checkpoint object
                lstSeq = New List(Of Integer)
                tmpCheckpoint.xPos = m
                tmpCheckpoint.yPos = reader.ReadLine : l = l + 1
                tmpCheckpoint.playerXPos = reader.ReadLine : l = l + 1
                tmpCheckpoint.playerYPos = reader.ReadLine : l = l + 1
                tmpCheckpoint.bows = reader.ReadLine : l = l + 1
                tmpCheckpoint.arrows = reader.ReadLine : l = l + 1
                tmpCheckpoint.keys = reader.ReadLine : l = l + 1
                tmpCheckpoint.seconds = reader.ReadLine : l = l + 1
                m = reader.ReadLine : l = l + 1
                While m > -2
                    ' Read any activated sequences
                    lstSeq.Add(m)
                    m = reader.ReadLine : l = l + 1
                End While
                tmpCheckpoint.sequences = lstSeq
                CMap.m_checkPoints.Add(tmpCheckpoint)
                'CMap.m_checkPoints(n).SetVals(chkX, chkY, chkBows, chkArrows, chkKeys, chkSeconds, lstSeq)
                n = n + 1
                m = reader.ReadLine : l = l + 1
            End While

            ' Load the map properties
            m = reader.ReadLine : l = l + 1
            While Not reader.EndOfStream And m > -10
                s = 8 ' Section marker
                CMap.m_intWallType = m
                CMap.m_pntPlayerStartLocation.X = reader.ReadLine : l = l + 1
                CMap.m_pntPlayerStartLocation.Y = reader.ReadLine : l = l + 1
                CMap.m_strMapDescription = reader.ReadLine : l = l + 1
                m = reader.ReadLine : l = l + 1
            End While
            result = 0
            Me.ChangeWallTiles()
            Me.UpdateMapTiles(CTileMap)
            g_blnMapViewChanged = True
        Catch
            result = 1
            MsgBox("Map Load Error: " & Err.Description & vbNewLine & _
                   "Line: " & CStr(l) & " Section: " & CStr(s), vbOKOnly, "Error")
        Finally
            LoadMap = result
            reader.Close()
        End Try
    End Function

    Public Function SaveMap(fileName As String)
        ' Save map data from a given file
        Dim result As Integer
        Dim n, m, i, x As Integer
        Dim writer As StreamWriter = _
            New StreamWriter(fileName)
        Try
            ' Save wall layer tiles
            For n = 0 To 47
                For m = 0 To 79
                    writer.WriteLine(Me.m_arrMapTiles(n, m, 0).m_intType)
                Next m
            Next n
            ' Save fixture layer tiles
            For n = 0 To 47
                For m = 0 To 79
                    writer.WriteLine(Me.m_arrMapTiles(n, m, 1).m_intType)
                Next m
            Next n
            ' Save any sprite objects
            For n = 0 To 47
                For m = 0 To 79
                    If Me.m_arrMapTiles(n, m, 3).m_intType > 0 Then
                        writer.WriteLine(Me.m_arrMapTiles(n, m, 3).m_intType)
                        writer.WriteLine(m) ' X
                        writer.WriteLine(n) ' Y
                    End If
                Next m
            Next n

            ' Write section end marker
            writer.WriteLine(-10)

            ' Save map object properties. 
            ' NB: Add an object if it has properties AND/OR contents. 
            ' Layer 1
            For n = 0 To 47
                For m = 0 To 79
                    If Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                        If Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count > 0 Then
                            writer.WriteLine(m) ' X
                            writer.WriteLine(n) ' Y
                            For i = 0 To Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count - 1
                                writer.WriteLine(Me.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(i))
                            Next i
                            ' Write properties end marker
                            writer.WriteLine(END_MARKER_OBJECT)
                        End If
                    Else
                        ' Else if the object has no properties, but does have contents, add the x and y coordinates.
                        ' This allows for chests to  be processed properly, which have no properties but to have contents.
                        If Me.m_arrMapTiles(n, m, 1).m_contents Is Nothing = False Then
                            writer.WriteLine(m) ' X
                            writer.WriteLine(n) ' Y
                            ' Write properties end marker
                            writer.WriteLine(END_MARKER_OBJECT)
                        End If
                    End If
                Next m
            Next n
            ' Write section end marker
            writer.WriteLine(-10)

            ' Layer 3
            For n = 0 To 47
                For m = 0 To 79
                    If Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues Is Nothing = False Then
                        If Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues.Count > 0 Then
                            writer.WriteLine(m) ' X
                            writer.WriteLine(n) ' Y
                            For i = 0 To Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues.Count - 1
                                writer.WriteLine(Me.m_arrMapTiles(n, m, 3).m_arrintPropertyValues(i))
                            Next i
                            ' Write properties end marker
                            writer.WriteLine(END_MARKER_OBJECT)
                        End If
                    End If
                Next m
            Next n
            ' Write section end marker
            writer.WriteLine(-10)

            ' Save any container contents data.
            ' Fixture layer only
            ' Location, tile type, properties
            ' Property/Contents end marker = END_MARKER_OBJECT
            ' Section end marker = -10
            For n = 0 To 47
                For m = 0 To 79
                    If Me.m_arrMapTiles(n, m, 1).m_contents Is Nothing = False Then
                        ' Write the location
                        writer.WriteLine(m) ' X
                        writer.WriteLine(n) ' Y
                        ' Write the tile type 
                        writer.WriteLine(Me.m_arrMapTiles(n, m, 1).m_contents.m_intType)
                        ' Write any properties for the contents
                        If Me.m_arrMapTiles(n, m, 1).m_contents.m_arrintPropertyValues Is Nothing = False Then
                            If Me.m_arrMapTiles(n, m, 1).m_contents.m_arrintPropertyValues.Count > 0 Then
                                For i = 0 To Me.m_arrMapTiles(n, m, 1).m_contents.m_arrintPropertyValues.Count - 1
                                    writer.WriteLine(Me.m_arrMapTiles(n, m, 1).m_contents.m_arrintPropertyValues(i))
                                Next i
                            End If
                        End If
                        ' Write object end marker (Same marker number as properties end marker since there
                        ' will never be anything after the contents properties values)
                        writer.WriteLine(END_MARKER_OBJECT)
                    End If

                Next m
            Next n
            ' Write section end marker
            writer.WriteLine(-10)


            ' Save sequence data
            If m_arrobjSequenceList Is Nothing = False Then
                ' Loop through sequences
                If m_arrobjSequenceList.Count > 0 Then
                    For n = 0 To m_arrobjSequenceList.Count - 1
                        ' NEW: Write the sequence properties (depends on seq, loop, always on)
                        writer.WriteLine(m_arrobjSequenceList(n).m_intDependsOnSequence)
                        writer.WriteLine(m_arrobjSequenceList(n).m_blnLoop)
                        writer.WriteLine(m_arrobjSequenceList(n).m_blnAlwaysOn)
                        ' Loop through stages
                        If m_arrobjSequenceList(n).m_objStages.Count > 0 Then
                            For m = 0 To m_arrobjSequenceList(n).m_objStages.Count - 1
                                ' NEW: Write the stage properties (change type, delay frames, delay flash, toggle seq)
                                writer.WriteLine(m_arrobjSequenceList(n).m_objStages(m).m_intChangeType)
                                writer.WriteLine(m_arrobjSequenceList(n).m_objStages(m).m_intDelayFrames)
                                writer.WriteLine(m_arrobjSequenceList(n).m_objStages(m).m_blnDelayFlash)
                                writer.WriteLine(m_arrobjSequenceList(n).m_objStages(m).m_intToggleSequence) ' Level 5 property
                                If m_arrobjSequenceList(n).m_objStages(m).m_objTileChanges.Count > 0 Then
                                    For i = 0 To m_arrobjSequenceList(n).m_objStages(m) _
                                        .m_objTileChanges.Count - 1
                                        With m_arrobjSequenceList(n).m_objStages(m).m_objTileChanges(i)
                                            ' Store the tile, x,y coordinates and layer
                                            writer.WriteLine(.mapObj.m_intType)
                                            writer.WriteLine(.xPos) ' X
                                            writer.WriteLine(.yPos) ' Y
                                            writer.WriteLine(.layer) ' Layer
                                            ' Get any properties
                                            If .mapObj.m_arrintPropertyValues Is Nothing = False Then
                                                If .mapObj.m_arrintPropertyValues.Count > 0 Then
                                                    For x = 0 To .mapObj.m_arrintPropertyValues.Count - 1
                                                        writer.WriteLine(.mapObj.m_arrintPropertyValues(x))
                                                    Next x
                                                End If
                                            End If
                                            ' Write properties end marker, whether there were properties
                                            ' or not.
                                            writer.WriteLine(END_MARKER_OBJECT)

                                            ' Get any container contents.
                                            If .mapObj.m_contents Is Nothing = False Then
                                                writer.WriteLine(.mapObj.m_contents.m_intType)
                                                ' Get any container contents properties
                                                If .mapObj.m_contents.m_arrintPropertyValues Is Nothing = False Then
                                                    If .mapObj.m_contents.m_arrintPropertyValues.Count > 0 Then
                                                        For x = 0 To .mapObj.m_contents.m_arrintPropertyValues.Count - 1
                                                            writer.WriteLine(.mapObj.m_contents.m_arrintPropertyValues(x))
                                                        Next x
                                                    End If
                                                End If
                                            End If
                                            ' Write contents entry end marker, whether there was a 
                                            ' contents entry or not. Use same number as properties
                                            ' end marker.
                                            writer.WriteLine(END_MARKER_OBJECT)
                                        End With
                                    Next i
                                End If
                                ' Write end stage marker
                                writer.WriteLine(END_MARKER_STAGE)
                            Next m
                            ' Write end sequence marker
                            writer.WriteLine(END_MARKER_SEQUENCE)
                        End If
                    Next n
                End If
            End If

            ' Write end section marker
            writer.WriteLine(-10)


            ' Save the checkpoint data 
            If CMap.m_checkPoints Is Nothing = False Then
                If CMap.m_checkPoints.Count > 0 Then
                    For n = 0 To CMap.m_checkPoints.Count - 1
                        writer.WriteLine(CMap.m_checkPoints(n).xPos)
                        writer.WriteLine(CMap.m_checkPoints(n).yPos)
                        writer.WriteLine(CMap.m_checkPoints(n).playerXPos)
                        writer.WriteLine(CMap.m_checkPoints(n).playerYPos)
                        writer.WriteLine(CMap.m_checkPoints(n).bows)
                        writer.WriteLine(CMap.m_checkPoints(n).arrows)
                        writer.WriteLine(CMap.m_checkPoints(n).keys)
                        writer.WriteLine(CMap.m_checkPoints(n).seconds)
                        If CMap.m_checkPoints(n).sequences Is Nothing = False Then
                            If CMap.m_checkPoints(n).sequences.Count > 0 Then
                                For m = 0 To CMap.m_checkPoints(n).sequences.Count - 1
                                    writer.WriteLine(CMap.m_checkPoints(n).sequences(m))
                                Next m
                            End If
                        End If
                        ' Use the object end marker to mark the end of a checkpoint (-2)
                        writer.WriteLine(END_MARKER_OBJECT)
                    Next n
                End If
            End If

            ' Write end section marker
            writer.WriteLine(-10)

            ' Save the map properties
            ' Wall type
            writer.WriteLine(CMap.m_intWallType)
            ' Player starting location
            writer.WriteLine(CMap.m_pntPlayerStartLocation.X)
            writer.WriteLine(CMap.m_pntPlayerStartLocation.Y)
            ' Map description
            writer.WriteLine(CMap.m_strMapDescription)
            ' Write end section marker
            writer.WriteLine(-10)

            ' Store the map name so the program can overwrite it when the save
            ' button is clicked.
            Me.m_strFileName = fileName

            result = 0
        Catch
            result = 1
            MsgBox("Map Save Error: " & Err.Description, vbOKOnly, "Error")
        Finally
            SaveMap = result
            writer.Close()
        End Try

    End Function

    Public Function SaveMapAsC(arrFileNames() As String) As Integer
        Dim result As Integer = 0 ' Result of the function
        Dim n, m, i As Integer
        Dim mapCount As Integer
        Dim tempStr, tempStrB As String
        Dim intCount As Integer
        Dim fileNum As Integer
        Dim layer As Integer
        Dim seqLen, stageLen, checkpointLen As Integer
        Dim reader() As StreamReader
        Dim writerC As StreamWriter = _
            New StreamWriter(Application.StartupPath & "\level_data.c")
        Dim writerH As StreamWriter = _
            New StreamWriter(Application.StartupPath & "\level_data.h")

        ' Data offset value array. (Only matters if there's more than one map)
        Dim arrDataOffsets(,) As Integer
        Dim arrArrayLengths(6) As Integer

        Try

            ' Setup some initial variables based on the number of files to be processed
            mapCount = UBound(arrFileNames)
            ReDim reader(mapCount)
            For n = 0 To mapCount
                reader(n) = New StreamReader(arrFileNames(n))
            Next n
            ReDim arrDataOffsets(mapCount, 5) ' Offsets to variable length data for each level.

            ' Step 1 - Calculate the lengths of all of the arrays that will be in the level data file.
            ' I'm doing it this way because I can only seek forward through a streamreader and it's
            ' not possible to go back to a certain position. I'm fully reading through each file twice.

            ' ***Layer 0 and 1 tile data***
            arrArrayLengths(0) = 3840 * (mapCount + 1)
            ' Seek to next section for each map file
            For fileNum = 0 To mapCount
                For n = 0 To 7679 ' 2 layers worth of data
                    m = reader(fileNum).ReadLine()
                Next n
            Next fileNum

            ' ***Sprite layer tiles***
            arrArrayLengths(1) = 0
            For fileNum = 0 To mapCount
                ' Section end marker is -10
                ' Read the first value 
                m = reader(fileNum).ReadLine
                While m > -10
                    ' Ignore tiles that are of type 99. These let the level editor know that they're the bottom tile
                    ' of a double-height tile. They're irrelevant to the game itself.
                    If m = 99 Then
                        ' Skip past this object
                        reader(fileNum).ReadLine()
                        reader(fileNum).ReadLine()
                    Else
                        arrArrayLengths(1) = arrArrayLengths(1) + 1
                    End If
                    m = reader(fileNum).ReadLine
                End While
            Next fileNum

            '***Initial map layer 1 properties***
            arrArrayLengths(2) = 0
            For fileNum = 0 To mapCount
                ' Read the first value
                m = reader(fileNum).ReadLine
                ' Section end marker is -10
                While m > -10
                    ' Skip end object markers
                    If m > -2 Then
                        arrArrayLengths(2) = arrArrayLengths(2) + 1
                    End If
                    m = reader(fileNum).ReadLine
                End While
            Next fileNum

            '***Initial map sprite layer properties***
            arrArrayLengths(3) = 0
            For fileNum = 0 To mapCount
                ' Read the first value
                m = reader(fileNum).ReadLine
                ' Section end marker is -10
                While m > -10
                    ' Skip end object markers
                    If m > -2 Then
                        arrArrayLengths(3) = arrArrayLengths(3) + 1
                    End If
                    m = reader(fileNum).ReadLine
                End While
            Next fileNum

            '***Initial map container contents***
            arrArrayLengths(4) = 0
            For fileNum = 0 To mapCount
                ' Read the first value
                m = reader(fileNum).ReadLine
                ' Section end marker is -10
                While m > -10
                    ' Skip end object markers
                    If m > -2 Then
                        arrArrayLengths(4) = arrArrayLengths(4) + 1
                    End If
                    m = reader(fileNum).ReadLine
                End While
            Next fileNum

            '***Sequence Data***
            ' (Sequence entry length), (depends on seq), (loop), (always on)
            ' (Stage entry length), (change type) (delay frames), (delay flash), (sequence toggle-lev5 property),
            ' (list of all tile changes in stage :x,y,type,x,y,type...)(List of object property data + contents data)
            arrArrayLengths(5) = 0
            For fileNum = 0 To mapCount
                ' Read the first value (Use tempStr since there will be mixture of numbers and strings ("true","false")
                tempStr = reader(fileNum).ReadLine
                ' Section end marker is -10
                While tempStr <> "-10"
                    Select Case tempStr
                        Case "-2" ' End properties/contents marker (ignore)
                        Case "99" ' Object to be ignored completely, just subtract this object's
                            ' remaining values from the total (x,y,layer)
                            arrArrayLengths(5) = arrArrayLengths(5) - 3
                        Case Else
                            ' Add 1 to the counter. This also applies to end stage and end sequence
                            ' markers, since we add one sequence length value or stage length value.
                            arrArrayLengths(5) = arrArrayLengths(5) + 1
                    End Select
                    ' Read the next value
                    tempStr = reader(fileNum).ReadLine
                End While
            Next fileNum

            ' Count the checkpoint data
            arrArrayLengths(6) = 0
            For fileNum = 0 To mapCount
                ' Read the first value
                m = reader(fileNum).ReadLine
                ' Section end marker is -10
                While m > -10
                    ' Even when we have an end marker we'll still add one to account for the
                    ' contents entry length
                    arrArrayLengths(6) = arrArrayLengths(6) + 1
                    m = reader(fileNum).ReadLine
                End While
            Next fileNum


            ' Reset all streamreaders to the beginning
            For fileNum = 0 To mapCount
                reader(fileNum).DiscardBufferedData()
                reader(fileNum).BaseStream.Seek(0, SeekOrigin.Begin)
            Next fileNum

            ' -------------- Part 2 - Write the data -------------

            ' Write the header file
            writerH.WriteLine("#ifndef __LEVEL_DATA__")
            writerH.WriteLine("#define __LEVEL_DATA__")
            writerH.WriteLine()
            writerH.WriteLine("extern const unsigned char map_layer0[" & CStr(arrArrayLengths(0)) & "];")
            writerH.WriteLine("extern const unsigned char map_layer1[" & CStr(arrArrayLengths(0)) & "];")
            writerH.WriteLine("extern const unsigned char map_layer3[" + CStr(arrArrayLengths(1)) + "];")
            writerH.WriteLine("extern const signed short map_layer1_properties[" + CStr(arrArrayLengths(2)) + "];")
            writerH.WriteLine("extern const signed short map_layer3_properties[" + CStr(arrArrayLengths(3)) + "];")
            writerH.WriteLine("extern const signed short map_containers[" + CStr(arrArrayLengths(4)) + "];")
            writerH.WriteLine("extern const signed short map_sequences[" + CStr(arrArrayLengths(5)) + "];")
            writerH.WriteLine("extern const signed short map_checkpoints[" + CStr(arrArrayLengths(6)) + "];")
            writerH.WriteLine("extern const unsigned short map_mapProperties[3];")
            writerH.WriteLine("extern const char* map_description[1];")
            ' NB: dataOffsets below includes a space for checkpoint data, which is not yet implemented.
            writerH.WriteLine("extern const unsigned int map_dataOffsets[" + CStr((mapCount + 1) * 6) + "];")
            writerH.WriteLine()
            writerH.WriteLine("#endif")
            writerH.WriteLine()

            'Write the initial map tile data for the wall and fixture layers
            For layer = 0 To 1

                'Print the variable name
                writerC.WriteLine("const unsigned char map_layer" + CStr(layer) + "[" & CStr(arrArrayLengths(0)) & "] = {")

                ' Loop through each file
                For fileNum = 0 To mapCount

                    ' Write the tile values for the layer
                    For n = 0 To 47
                        tempStr = ""
                        For m = 0 To 79
                            If layer = 0 Then
                                tempStr = tempStr + reader(fileNum).ReadLine + ","
                            Else
                                i = CInt(reader(fileNum).ReadLine)
                                ' If the tile is 99, change to 0 since it's the bottom of a double-height tile
                                ' and the GBA doesn't need to know about it.
                                If i = 99 Then i = 0
                                ' If the tile is > 0, subtract 7 so tile 0 is the first one after the walls
                                If i > 0 Then i = i - 7
                                tempStr = tempStr + CStr(i) + ","
                            End If
                        Next m
                        ' Print the data for the row
                        writerC.WriteLine(tempStr)
                        tempStr = ""
                    Next n
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                'Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()

            Next layer


            ' Write sprite layer objects for all levels, tile, x, y, if any
            If arrArrayLengths(1) > 0 Then
                writerC.WriteLine("const unsigned char map_layer3[" + CStr(arrArrayLengths(1)) + "] = {")
                intCount = 0 ' Re-use intCount to work out data offsets when there are multiple files.

                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 0) = intCount
                    End If

                    ' Read the first layer 3 tile type
                    n = CInt(reader(fileNum).ReadLine)
                    While n > -10
                        ' Ignore if tile is 99. This is used by the level editor only to designate the
                        ' lower tile of a double-height tile.
                        If n = 99 Then
                            ' Skip past the x and y coordinates
                            reader(fileNum).ReadLine()
                            reader(fileNum).ReadLine()
                        Else
                            ' Write the tile type (subtract 7 since we're starting from after the wall tiles), x and y coords
                            tempStr = CStr(n - 7) + "," + reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + ","
                            writerC.WriteLine(tempStr)
                            intCount = intCount + 3
                        End If
                        ' Read the next value
                        n = CInt(reader(fileNum).ReadLine)
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()
            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If

            ' Write initial map object properties for fixture layer, if any
            If arrArrayLengths(2) > 0 Then
                writerC.WriteLine("const signed short map_layer1_properties[" + CStr(arrArrayLengths(2)) + "] = {")
                intCount = 0
                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 1) = intCount
                    End If

                    ' Read the first layer 1 object X coord
                    n = CInt(reader(fileNum).ReadLine)
                    While n > -10
                        ' Add x and y coordinates to the string
                        tempStr = CStr(n) + "," + reader(fileNum).ReadLine + ","
                        intCount = intCount + 2
                        ' Read the first object property, if any
                        n = CInt(reader(fileNum).ReadLine)
                        While n > -2
                            tempStr = tempStr + CStr(n) + ","
                            intCount = intCount + 1
                            n = CInt(reader(fileNum).ReadLine)
                        End While
                        ' Write the line
                        writerC.WriteLine(tempStr)
                        ' Read the next value
                        n = CInt(reader(fileNum).ReadLine)
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()
            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If

            ' Write initial map object properties for sprite layer, if any
            If arrArrayLengths(3) > 0 Then
                writerC.WriteLine("const signed short map_layer3_properties[" + CStr(arrArrayLengths(3)) + "] = {")
                intCount = 0
                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 2) = intCount
                    End If

                    ' Read the first layer 1 object X coord
                    n = CInt(reader(fileNum).ReadLine)
                    While n > -10
                        ' Add x and y coordinates to the string
                        tempStr = CStr(n) + "," + reader(fileNum).ReadLine + ","
                        intCount = intCount + 2
                        ' Read the first object property, if any
                        n = CInt(reader(fileNum).ReadLine)
                        While n > -2
                            tempStr = tempStr + CStr(n) + ","
                            intCount = intCount + 1
                            n = CInt(reader(fileNum).ReadLine)
                        End While
                        ' Write the line
                        writerC.WriteLine(tempStr)
                        ' Read the next value
                        n = CInt(reader(fileNum).ReadLine)
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()

            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If


            ' Save the initial map Container Contents Data: x,y, tile, properties
            If arrArrayLengths(4) > 0 Then
                writerC.WriteLine("const signed short map_containers[" + CStr(arrArrayLengths(4)) + "] = {")
                intCount = 0
                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 3) = intCount
                    End If

                    ' Read the first container object X coord
                    n = CInt(reader(fileNum).ReadLine)
                    While n > -10
                        ' Add x, y to the string
                        tempStr = CStr(n) + "," + reader(fileNum).ReadLine + ","
                        ' Read the tile type. If it's above 7 then subtract 7 since these are fixture tiles, otherwise
                        ' they're wall tiles.
                        n = CInt(reader(fileNum).ReadLine)
                        If n > 7 Then n = n - 7
                        tempStr = tempStr + CStr(n) + ","
                        intCount = intCount + 3
                        ' Read the first object property, if any
                        n = CInt(reader(fileNum).ReadLine)
                        While n > -2
                            tempStr = tempStr + CStr(n) + ","
                            intCount = intCount + 1
                            n = CInt(reader(fileNum).ReadLine)
                        End While
                        ' Write the line
                        writerC.WriteLine(tempStr)
                        ' Read the next value
                        n = CInt(reader(fileNum).ReadLine)
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()
            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If


            ' Save sequence tile change Data
            ' (Sequence entry length), (depends on seq), (loop), (always on)
            ' (Stage entry length), (change type) (delay frames), (delay flash), (sequence toggle-lev5 property),
            ' (list of all tile changes in stage :x,y,type,x,y,type...)(List of object property entries + contents offsets)

            ' In this section I need to write a whole sequence to tempStr because I need to prepend
            ' the sequence length. I also need to prepend the stage length to each stage.
            ' I'll use 2 temporary strings. The first will eventually hold the whole seqence, the
            ' second will hold a stage at a time. The second will be added to the first as we go, each
            ' prepended by the stage length. At the end of a sequence, the sequence length will be prepended.

            If arrArrayLengths(5) > 0 Then
                writerC.WriteLine("const signed short map_sequences[" + CStr(arrArrayLengths(5)) + "] = {")
                intCount = 0
                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 4) = intCount
                    End If

                    ' Read the first value (depends on seq for first sequence (should be -1))
                    n = reader(fileNum).ReadLine()
                    While n > -10
                        ' Add the sequence properties values to the string: (depends on seq), (loop), (always on)
                        ' Convert true/false to -1, 0
                        tempStr = CStr(n) + ","
                        tempStr = tempStr + IIf(reader(fileNum).ReadLine = "True", "-1", "0") + ","
                        tempStr = tempStr + IIf(reader(fileNum).ReadLine = "True", "-1", "0") + ","
                        seqLen = 4 ' 3 sequence properties + sequence length value 
                        ' Read the next value
                        n = reader(fileNum).ReadLine
                        While n > -5
                            ' Add the stage properties to the second string
                            ' (change type) (delay frames), (delay flash), (sequence toggle-lev5 property)
                            tempStrB = CStr(n) + ","
                            tempStrB = tempStrB + reader(fileNum).ReadLine() + ","
                            tempStrB = tempStrB + IIf(reader(fileNum).ReadLine = "True", "-1", "0") + ","
                            tempStrB = tempStrB + reader(fileNum).ReadLine() + ","
                            stageLen = 5 ' 4 sequence properties + stage length value
                            ' Read the next value
                            n = reader(fileNum).ReadLine
                            While n > -4
                                ' Skip any end markers (-2)
                                If n > -2 Then
                                    ' Also skip objects of type 99, since they don't apply in the game itself
                                    If n = 99 Then
                                        ' Skip past this object (x,y,layer)
                                        reader(fileNum).ReadLine()
                                        reader(fileNum).ReadLine()
                                        reader(fileNum).ReadLine()
                                    Else
                                        tempStrB = tempStrB + CStr(n) + ","
                                        stageLen = stageLen + 1
                                    End If
                                End If

                                n = reader(fileNum).ReadLine ' TODO: Error here?
                            End While
                            ' Prepend the stage length to tempStrB, add stageLen to seqLen and reset stageLen
                            tempStrB = CStr(stageLen) + "," + tempStrB
                            ' Add tempStrB to tempStr
                            tempStr = tempStr + tempStrB
                            seqLen = seqLen + stageLen
                            stageLen = 0
                            ' Read the next value
                            n = reader(fileNum).ReadLine
                        End While
                        ' Prepend the sequence length to tempStr, write
                        ' tempStr to the file and reset seqLen
                        tempStr = CStr(seqLen) + "," + tempStr ' + tempStrB
                        writerC.WriteLine(tempStr)
                        ' Also add seqLen to intCount for the data offset when adding multiple level files
                        intCount = intCount + seqLen
                        seqLen = 0
                        ' Read the next value
                        n = reader(fileNum).ReadLine
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()
            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If

            ' Save the checkpoint Data: x,y,bows,arrows,keys,seconds,activated sequences
            If arrArrayLengths(6) > 0 Then
                writerC.WriteLine("const signed short map_checkpoints[" + CStr(arrArrayLengths(6)) + "] = {")
                intCount = 0
                For fileNum = 0 To mapCount

                    ' If this is not the first file, write the data offset value
                    If fileNum > 0 Then
                        arrDataOffsets(fileNum - 1, 5) = intCount
                    End If

                    ' Read the first checkpoint X coord
                    n = CInt(reader(fileNum).ReadLine)

                    While n > -10
                        checkpointLen = 0
                        ' Add x, y,playerXPos, playerYPos,bows,arrows,keys,seconds to the string
                        tempStr = CStr(n) + "," + reader(fileNum).ReadLine + "," + _
                        reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + "," + _
                        reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + "," + _
                        reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + ","
                        intCount = intCount + 9
                        checkpointLen = 9 '8 values plus checkpoint length value
                        ' Read the first activated sequence, if any
                        n = CInt(reader(fileNum).ReadLine)
                        While n > -2
                            tempStr = tempStr + CStr(n) + ","
                            intCount = intCount + 1
                            n = CInt(reader(fileNum).ReadLine)
                            checkpointLen = checkpointLen + 1
                        End While
                        ' Prepend the checkpoint length to tempStr
                        tempStr = CStr(checkpointLen) + "," + tempStr

                        ' Write the line
                        writerC.WriteLine(tempStr)
                        ' Read the next value
                        n = CInt(reader(fileNum).ReadLine)
                    End While
                    ' If there's more than one map, write a comment line marking the end of this map's data
                    If mapCount > 0 And fileNum < mapCount Then writerC.WriteLine("//End map " & CStr(fileNum))
                Next fileNum

                ' Print the closing bracket
                writerC.WriteLine("};")
                writerC.WriteLine()
            Else
                ' Skip past the end section marker, since there were no values
                For fileNum = 0 To mapCount
                    reader(fileNum).ReadLine()
                Next fileNum
            End If

            ' Write the map properties: Wall type, player start location, closing bracket
            writerC.WriteLine("const unsigned short map_mapProperties[" + CStr(3 * (mapCount + 1)) + "] = {")
            intCount = 0
            For fileNum = 0 To mapCount
                tempStr = reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + "," + reader(fileNum).ReadLine + ","
                writerC.WriteLine(tempStr)
            Next fileNum
            ' Print the closing bracket
            writerC.WriteLine("};")
            writerC.WriteLine()

            ' Write the map description 
            writerC.WriteLine("const char* map_description[" + CStr(mapCount + 1) + "] = {")
            For fileNum = 0 To mapCount
                writerC.WriteLine("""" + reader(fileNum).ReadLine + """,")
            Next fileNum
            ' Print the closing bracket
            writerC.WriteLine("};")
            writerC.WriteLine()

            ' Map data offsets: (layer 3 tile offset), (Initial map object properties layer 1 offset), 
            ' (Initial map object properties layer 3 offset), (Initial map container contents offset),
            ' (Sequence header offset), (Checkpoint data offset)
            ' The first set of offsets is always 0,0,0,0,0,0
            writerC.WriteLine("const unsigned int map_dataOffsets[" + CStr((mapCount + 1) * 6) + "] = {")
            writerC.WriteLine("0,0,0,0,0,0,")
            If mapCount > 0 Then
                For fileNum = 0 To mapCount - 1
                    writerC.WriteLine(CStr(arrDataOffsets(fileNum, 0)) + "," + CStr(arrDataOffsets(fileNum, 1)) + "," + _
                                      CStr(arrDataOffsets(fileNum, 2)) + "," + CStr(arrDataOffsets(fileNum, 3)) + "," + _
                                      CStr(arrDataOffsets(fileNum, 4)) + "," + CStr(arrDataOffsets(fileNum, 5)) + ",")
                Next fileNum
            End If

            ' Print the closing bracket
            writerC.WriteLine("};")
            writerC.WriteLine()

        Catch
            SaveMapAsC = 1 ' Error code
            MsgBox("Map Save Error: " & Err.Description, vbOKOnly, "Error")
        Finally
            ' Close the stream writer for the H file
            writerH.Close()

            ' Close the stream writer for the C file
            writerC.Close()

            ' Return the function result
            SaveMapAsC = result

        End Try

    End Function
End Class
