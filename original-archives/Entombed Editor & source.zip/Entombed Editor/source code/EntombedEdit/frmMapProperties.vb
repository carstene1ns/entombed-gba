﻿Public Class frmMapProperties

    Private Sub frmMapProperties_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        ' Initialize the wall type combo box
        cmbWallType.Items.Clear()
        cmbWallType.Items.Add("1")
        cmbWallType.Items.Add("2")
        cmbWallType.Items.Add("3")
        cmbWallType.Items.Add("4")
        cmbWallType.Items.Add("5")
        cmbWallType.SelectedIndex = CMap.m_intWallType

        ' Initialize the player start location text boxes
        txtXLoc.Text = CStr(CMap.m_pntPlayerStartLocation.X)
        txtYLoc.Text = CStr(CMap.m_pntPlayerStartLocation.Y)

        ' Initialize the map description text box
        txtDescription.Text = CMap.m_strMapDescription
    End Sub

    Private Sub cmdOK_Click(sender As System.Object, e As System.EventArgs) Handles cmdOK.Click

        ' Update the wall tiles if necessary
        If CMap.m_intWallType <> cmbWallType.SelectedIndex Then
            CMap.m_intWallType = cmbWallType.SelectedIndex

            ' Call the procedure to update the wall tiles
            CMap.ChangeWallTiles()

            ' Refresh the map bitmap
            frmMain.picMap.Refresh()

            ' Refresh the tile selector
            g_blnTilePickerChanged = True
            frmMain.picTiles.Refresh()
        End If

        ' Update map description
        CMap.m_strMapDescription = txtDescription.Text

        Me.Hide()

    End Sub

    Private Sub cmdSetPlayerStartLocation_Click(sender As System.Object, e As System.EventArgs) Handles cmdSetPlayerStartLocation.Click
        ' Validate the location text boxes - X=32 to 2528, Y=16 to 720 (In map pixel coords, used to be tile coords)
        If IsNumeric(txtXLoc.Text) = False Or IsNumeric(txtYLoc.Text) = False Then
            MsgBox("Both text boxes nust have a number entered", vbOKOnly, "Invalid location values")
            Exit Sub
        End If
        If CInt(txtXLoc.Text) < 32 Or CInt(txtXLoc.Text) > 2528 Or CInt(txtYLoc.Text) < 16 Or CInt(txtYLoc.Text) > 720 Then
            MsgBox("A location value is out of range. Location was NOT set.", vbOKOnly, "Value out of range")
            Exit Sub
        End If
        ' If we got here then the numbers were valid
        CMap.m_pntPlayerStartLocation.X = CInt(txtXLoc.Text)
        CMap.m_pntPlayerStartLocation.Y = CInt(txtYLoc.Text)
        MsgBox("Player start location was set to: X:" & CInt(txtXLoc.Text) & " Y:" & _
               CInt(txtYLoc.Text), vbOKOnly, "Start Location Set")
    End Sub
End Class