﻿Public Class frmMain

    Private Sub Form1_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Initialize()
    End Sub

    Private Sub Initialize()

        ' Initialize classes
        CTileMap = New TileMap
        CMap = New Map

        ' Initialize the picturebox graphics objects
        CMap.m_bmpMapView = New Bitmap(picMap.Width, picMap.Height)
        CMap.m_gfxMapView = Graphics.FromImage(CMap.m_bmpMapView)
        CMap.m_bmpSelectedTile = New Bitmap(picSelection.Width, picSelection.Height)
        CMap.m_gfxSelectedTile = Graphics.FromImage(CMap.m_bmpSelectedTile)
        CTileMap.m_bmpTilePicker = New Bitmap(picTiles.Width, picTiles.Height)
        CTileMap.m_gfxTilePicker = Graphics.FromImage(CTileMap.m_bmpTilePicker)

        ' Initialize the tile picker
        CTileMap.InitComboBox(cmbTileTypes) ' Load the tile type names into the combobox
        g_blnTilePickerChanged = True
        CTileMap.DrawTilesToPicBox(picTiles)

        ' Setup some initial variables
        g_blnMapViewChanged = False
        g_blnSelectedTileChanged = False

        ' Set map scale
        CMap.m_intMapScale = 1

        ' Initialize the scroll bars
        VScrollBar1.Value = 0
        HScrollBar1.Value = 0
        VScrollBar1.Maximum = (MAP_HEIGHT / 16) - (picMap.Height / 16) + 4
        HScrollBar1.Maximum = (MAP_WIDTH / 32) - (picMap.Width / 32) + 4
        VScrollBar1.SmallChange = 1
        HScrollBar1.SmallChange = 1
        VScrollBar1.LargeChange = 5
        HScrollBar1.LargeChange = 5

        ' Disable menu items to start with
        SaveMapToolStripMenuItem.Enabled = False


    End Sub

    Private Sub picMap_MouseLeave(sender As Object, e As System.EventArgs) Handles picMap.MouseLeave

        ' Inform the CMap class that the cursor is now outside of the picturebox
        CMap.ProcessMouseMove(picMap, -1, -1)

        ' Clear the map tile coordinates label
        lblCoords.Text = ""

    End Sub

    Private Sub picMap_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles picMap.MouseMove
        ' Process mouse movement over map
        CMap.ProcessMouseMove(picMap, e.X, e.Y)
        If CMap.m_pntHoveredTileCoords.X >= 0 And CMap.m_pntHoveredTileCoords.Y >= 0 Then
            lblCoords.Text = "X-Tile: " & CStr(CMap.m_pntHoveredTileCoords.X) & " Y-Tile: " & _
                CStr(CMap.m_pntHoveredTileCoords.Y) & Environment.NewLine & "(" & CStr(CMap.m_pntHoveredTileCoords.X * 32) _
                 & " , " & CStr(CMap.m_pntHoveredTileCoords.Y * 16) & ")"
        Else
            lblCoords.Text = ""
        End If
    End Sub

    Private Sub picMap_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles picMap.MouseDown
        ' Process mouse click over map
        CMap.ProcessMouseClick(picMap, picSelection, e.X, e.Y, e.Button, True)
    End Sub

    Private Sub picMap_MouseUp(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles picMap.MouseUp
        ' Process mouse button release over map
        CMap.ProcessMouseClick(picMap, picSelection, e.X, e.Y, e.Button, False)

        ' If we're in sequence editing mode then update the tile change combo box
        If CMap.m_blnSequenceEditing = True Then
            UpdateMapChangesComboBox(CMap.m_intLastSequence, CMap.m_intLastStage)
        End If

        ' If the selected tile was changed then update its picturebox
        If g_blnSelectedTileChanged = True Then
            picSelection.Refresh()
        End If

    End Sub

    Private Sub picMap_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles picMap.Paint
        ' Redraw the visible portion of the map if it has changed in any way.
        If g_blnMapViewChanged Then
            CMap.DrawMapToPicBox(picMap)
        End If
    End Sub

    Private Sub picTiles_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles picTiles.MouseDown
        ' Process mouse click over tile picker
        CTileMap.ProcessMouseClick(picTiles, e.X, e.Y, e.Button, True)
    End Sub

    Private Sub picTiles_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles picTiles.Paint
        ' Redraw the tile picker if it has changed in any way.
        If g_blnTilePickerChanged = True Then
            CTileMap.DrawTilesToPicBox(picTiles)
        End If
    End Sub

    Private Sub picSelection_Paint(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles picSelection.Paint
        ' Redraw the selected tile coordinates of the picturebox changed in.
        If g_blnSelectedTileChanged = True Then
            If CMap.m_pntSelectedTilePos.X < 0 Or CMap.m_pntSelectedTilePos.Y < 0 Then
                lblSelection.Text = ""
                cmdEditContents.Visible = False
            Else
                lblSelection.Text = "X: " & CStr(CMap.m_pntSelectedTilePos.X) & vbNewLine & "Y: " _
                    & CStr(CMap.m_pntSelectedTilePos.Y)

                ' If a container is selected then set the contents editor button to visible, otherwise
                ' set it to invisible
                If CMap.m_intSelectLayer = 1 And CMap.GetTileData(CMap.m_pntSelectedTilePos.X, _
                    CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer).m_contents Is Nothing _
                     = False Then
                    cmdEditContents.Visible = True
                Else
                    cmdEditContents.Visible = False
                End If

                g_blnSelectedTileChanged = False
            End If
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles cmbTileTypes.SelectedIndexChanged
        ' Update the tile picker when the combobox is changed
        If CTileMap Is Nothing = False Then
            CTileMap.m_SelectedType = cmbTileTypes.SelectedIndex
            CTileMap.m_SelectedTile = CTileMap.m_TilesInTypes(CTileMap.m_SelectedType)(0)
        End If
        g_blnTilePickerChanged = True
        CTileMap.DrawTilesToPicBox(picTiles)
    End Sub

    Private Sub HScrollBar1_Scroll(sender As System.Object, e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar1.Scroll
        ' Update the horizontal scroll position of the map
        CMap.m_intScrollPosX = HScrollBar1.Value * 32
        g_blnMapViewChanged = True
        picMap.Refresh()
    End Sub

    Private Sub VScrollBar1_Scroll(sender As Object, e As System.Windows.Forms.ScrollEventArgs) Handles VScrollBar1.Scroll
        ' Update the vertical scroll position of the map
        CMap.m_intScrollPosY = VScrollBar1.Value * 16
        g_blnMapViewChanged = True
        picMap.Refresh()
    End Sub

    Private Sub radModeDraw_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radModeDraw.CheckedChanged
        If CMap Is Nothing = False Then
            If radModeDraw.Checked Then
                CMap.m_blnDrawMode = True
                lblPropertyValues.Visible = False
                cmbPropertyValues.Visible = False
                txtPropertyValue.Visible = False
                cmdSetProperty.Visible = False
            End If
        End If
    End Sub

    Private Sub radModeSelect_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radModeSelect.CheckedChanged
        If CMap Is Nothing = False Then
            If radModeSelect.Checked Then
                CMap.m_blnDrawMode = False
                lblPropertyValues.Visible = True
                cmbPropertyValues.Visible = True
                txtPropertyValue.Visible = True
                cmdSetProperty.Visible = True
            End If
        End If
    End Sub

    Private Sub chkSequenceEditor_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkSequenceEditor.CheckedChanged
        If CMap Is Nothing = False Then
            If chkSequenceEditor.Checked = True Then
                CMap.m_blnSequenceEditing = True
                ' Make all sequence editing controls visible
                lblSequence.Visible = True
                lblStage.Visible = True
                lblMapChanges.Visible = True
                cmdAddSeq.Visible = True
                cmdDelSeq.Visible = True
                cmdAddStage.Visible = True
                cmdDelStage.Visible = True
                cmbSequence.Visible = True
                cmbStage.Visible = True
                cmbMapChanges.Visible = True
                grpSequenceProperties.Visible = True
                grpStageProperties.Visible = True
                lblDependsOnSequence.Visible = True
                lblTriggeringSwitch.Visible = True
                cmbDependsOnSequence.Visible = True
                chkAlwaysOn.Visible = True
                chkLoop.Visible = True
                lblDelayFrames.Visible = True
                txtDelayFrames.Visible = True
                chkDelayFlash.Visible = True
                ' Change the map tiles to reflect the last sequence we were working on, if any
                If CMap.m_arrobjSequenceList.Count > 0 Then
                    If CMap.m_intLastSequence < 0 Or CMap.m_intLastStage < 0 Then
                        CMap.m_intLastSequence = 0
                        CMap.m_intLastStage = 0
                    End If

                    ' Store a copy of the original map data so we can revert back later when
                    ' we turn off sequence editing mode. (length = 48*80*4=15360)
                    ' Use our deep clone helper method to copy all data rather than
                    ' making a shallow copy.
                    CMap.m_arrMapTilesOrig = DeepClone(CMap.m_arrMapTiles)

                    ' Update the sequence, stage and property combo boxes
                    UpdateSequenceControls(CMap.m_intLastSequence, CMap.m_intLastStage)

                    ' Work out the map sequence changes up to the current sequence and the
                    ' stage before the current one.
                    ' The tile changes in the selected stage will be set in the
                    ' CMap.m_arrChangedTiles array.
                    CMap.GetSequenceChanges(CMap.m_intLastSequence, CMap.m_intLastStage - 1)

                    ' Apply the calculated map changes
                    CMap.UpdateMapTiles(CTileMap)

                    ' Set the current stage's change highlighting
                    CMap.UpdateStageChangeHighlighting(CMap.m_intLastSequence, CMap.m_intLastStage)

                    ' Look for the current sequence's triggering switch
                    CMap.FindTriggeringSwitch(CMap.m_intLastSequence)
                    If CMap.m_pntTriggeringSwitchLocation.X >= 1 And CMap.m_pntTriggeringSwitchLocation.Y >= 1 Then
                        lblTriggeringSwitch.Text = "Triggering Switch: X:" & CStr(CMap.m_pntTriggeringSwitchLocation.X) & _
                    " Y:" & CStr(CMap.m_pntTriggeringSwitchLocation.Y)
                    Else
                        lblTriggeringSwitch.Text = "Triggering Switch: None"
                    End If

                End If
            Else
                CMap.m_blnSequenceEditing = False
                ' Hide all sequence editing controls
                lblSequence.Visible = False
                lblStage.Visible = False
                lblMapChanges.Visible = False
                cmdAddSeq.Visible = False
                cmdDelSeq.Visible = False
                cmdAddStage.Visible = False
                cmdDelStage.Visible = False
                cmbSequence.Visible = False
                cmbStage.Visible = False
                cmbMapChanges.Visible = False
                grpSequenceProperties.Visible = False
                grpStageProperties.Visible = False
                lblDependsOnSequence.Visible = False
                lblTriggeringSwitch.Visible = False
                cmbDependsOnSequence.Visible = False
                chkAlwaysOn.Visible = False
                chkLoop.Visible = False
                lblDelayFrames.Visible = False
                txtDelayFrames.Visible = False
                chkDelayFlash.Visible = False
                ' Revert the map data to it's initial state
                CMap.RevertMapChanges(CMap.m_intLastSequence, 0)

                ' Update the map tiles
                CMap.UpdateMapTiles(CTileMap)

                ' Update the selected tile picbox
                g_blnSelectedTileChanged = True
                CMap.UpdateSelection(picSelection)
                picSelection.Refresh()

            End If
            ' Redraw the map to the screen
            g_blnMapViewChanged = True
            picMap.Refresh()
        End If
    End Sub

    Private Sub UpdateSequenceControls(seq As Integer, stage As Integer)
        Dim n As Integer
        ' Add all sequence numbers to the sequence combo box
        ' Also add each sequence number excluding the given one to the "Depends on" combobox
        cmbSequence.Items.Clear()
        cmbDependsOnSequence.Items.Clear()
        If CMap.m_arrobjSequenceList.Count > 0 Then
            For n = 0 To CMap.m_arrobjSequenceList.Count - 1
                cmbSequence.Items.Add(n)
                If n <> seq Then
                    cmbDependsOnSequence.Items.Add(n)
                End If
            Next n
            ' Select the given sequence
            cmbSequence.SelectedIndex = seq
            CMap.m_intLastSequence = seq

            ' Update the sequence property controls
            cmbDependsOnSequence.SelectedIndex = CMap.m_arrobjSequenceList(seq).m_intDependsOnSequence
            chkLoop.Checked = CMap.m_arrobjSequenceList(seq).m_blnLoop
            chkAlwaysOn.Checked = CMap.m_arrobjSequenceList(seq).m_blnAlwaysOn

            ' Now update the stage combobox
            UpdateStageControls(seq, stage)
        End If
    End Sub
    Private Sub UpdateStageControls(seq As Integer, stage As Integer)
        Dim n As Integer
        ' Add all stage numbers for the current sequence to the stage combo box
        cmbStage.Items.Clear()
        If CMap.m_arrobjSequenceList(seq).m_objStages.Count > 0 Then
            For n = 0 To CMap.m_arrobjSequenceList(seq).m_objStages.Count - 1
                cmbStage.Items.Add(n)
            Next n
            ' Select the given stage
            cmbStage.SelectedIndex = stage
            CMap.m_intLastStage = stage

            ' Update the stage properties
            txtDelayFrames.Text = CStr(CMap.m_arrobjSequenceList(seq).m_objStages(stage).m_intDelayFrames)
            chkDelayFlash.Checked = CMap.m_arrobjSequenceList(seq).m_objStages(stage).m_blnDelayFlash

            ' Now update the map changes combobox
            UpdateMapChangesComboBox(seq, stage)
        End If
    End Sub
    Private Sub UpdateMapChangesComboBox(seq As Integer, stage As Integer)
        Dim n As Integer
        Dim strTemp As String
        ' Add all map changes for the current stage to the map changes combo box
        cmbMapChanges.Items.Clear()
        If CMap.m_arrobjSequenceList(seq).m_objStages(stage).m_objTileChanges.Count > 0 Then
            For n = 0 To CMap.m_arrobjSequenceList(seq).m_objStages(stage).m_objTileChanges.Count - 1
                With CMap.m_arrobjSequenceList(seq).m_objStages(stage).m_objTileChanges(n)
                    strTemp = CStr("X: " & .xPos & "  Y: " & .yPos & "  Tile: " & .mapObj.m_intType)
                    cmbMapChanges.Items.Add(strTemp)
                End With
            Next n
            ' Select the first tile change
            cmbMapChanges.SelectedIndex = 0
        End If
    End Sub

    Private Sub radLayerWalls_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radLayerWalls.CheckedChanged
        If radLayerWalls.Checked Then
            If CMap Is Nothing = False Then
                CMap.m_intSelectLayer = 0
                ' Update the selected item
                g_blnSelectedTileChanged = True
                CMap.UpdateSelection(picSelection)
                picSelection.Refresh()
            End If
        End If
    End Sub

    Private Sub radLayerFixtures_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radLayerFixtures.CheckedChanged
        If radLayerFixtures.Checked Then
            If CMap Is Nothing = False Then
                CMap.m_intSelectLayer = 1
                ' Update the selected item
                g_blnSelectedTileChanged = True
                CMap.UpdateSelection(picSelection)
                picSelection.Refresh()
            End If
        End If
    End Sub

    Private Sub radLayerSprites_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radLayerSprites.CheckedChanged
        If radLayerSprites.Checked Then
            If CMap Is Nothing = False Then
                CMap.m_intSelectLayer = 3
                ' Update the selected item
                g_blnSelectedTileChanged = True
                CMap.UpdateSelection(picSelection)
                picSelection.Refresh()
            End If
        End If
    End Sub

    Private Sub cmbPropertyValues_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbPropertyValues.SelectedIndexChanged
        ' Load the property value into the text box

        Dim objMapObject As MapObject

        If CMap Is Nothing = False Then
            If cmbPropertyValues.SelectedItem.ToString <> "" Then
                ' Get the correct property data
                objMapObject = CMap.GetTileData(CMap.m_pntSelectedTilePos.X, _
                 CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer)
                txtPropertyValue.Text = objMapObject.m_arrintPropertyValues( _
                  cmbPropertyValues.SelectedIndex)
            End If
        End If
    End Sub

    Private Sub cmdSetProperty_Click(sender As System.Object, e As System.EventArgs) Handles cmdSetProperty.Click
        ' Set the property value if it's valid.
        Dim objMapObject As MapObject
        Dim blnValidText As Boolean

        ' Validate the entered text in the first section of lines to lower the amount
        ' of if statements further down
        blnValidText = False
        If cmbPropertyValues.SelectedItem.ToString <> "" Then
            If IsNumeric(txtPropertyValue.Text) Then
                If CInt(txtPropertyValue.Text) >= -1 Then
                    blnValidText = True
                End If
            End If
        End If
        If blnValidText = False Then
            Exit Sub
        End If

        ' Get the correct property data object reference.
        objMapObject = CMap.GetTileData(CMap.m_pntSelectedTilePos.X, _
         CMap.m_pntSelectedTilePos.Y, CMap.m_intSelectLayer)
        ' Set the property value
        objMapObject.m_arrintPropertyValues( _
          cmbPropertyValues.SelectedIndex) = CInt(txtPropertyValue.Text)

        ' If we just changed a switch sequence property, and we're in sequence editing
        ' mode, see if if affects the triggering switch location for the current sequence
        If CMap.m_blnSequenceEditing = True Then
            ' See if we set a switch sequence property
            If objMapObject.m_intType = 30 Then
                ' See if we set this switch sequence propert to the current sequence 
                If objMapObject.m_arrintPropertyValues(0) = CMap.m_intLastSequence Then
                    ' If the trigger location was somewhere else then set the switch there to
                    ' -1
                    If CMap.m_pntTriggeringSwitchLocation.X <> CMap.m_pntSelectedTilePos.X And _
                     CMap.m_pntTriggeringSwitchLocation.Y <> CMap.m_pntSelectedTilePos.Y Then
                        objMapObject = CMap.GetTileData(CMap.m_pntTriggeringSwitchLocation.X, _
                         CMap.m_pntTriggeringSwitchLocation.Y, 1)
                        If objMapObject.m_intType = 30 Then objMapObject.m_arrintPropertyValues(0) = -1
                    End If
                    ' Set the triggering switch location to here and update the label
                    CMap.m_pntTriggeringSwitchLocation.X = CMap.m_pntSelectedTilePos.X
                    CMap.m_pntTriggeringSwitchLocation.Y = CMap.m_pntSelectedTilePos.Y
                    lblTriggeringSwitch.Text = "Triggering Switch: X:" & CStr(CMap.m_pntTriggeringSwitchLocation.X) & _
                    " Y:" & CStr(CMap.m_pntTriggeringSwitchLocation.Y)
                End If
            Else
                ' Else the switch sequence property is something else, so check if the triggering switch location
                ' WAS here. Reset it if it was.
                If CMap.m_pntTriggeringSwitchLocation.X <> CMap.m_pntSelectedTilePos.X And _
                     CMap.m_pntTriggeringSwitchLocation.Y <> CMap.m_pntSelectedTilePos.Y Then
                    ' Reset the triggering switch location to here and update the label
                    CMap.m_pntTriggeringSwitchLocation.X = -1
                    CMap.m_pntTriggeringSwitchLocation.Y = -1
                    lblTriggeringSwitch.Text = "Triggering Switch: None"
                End If
            End If
        End If
    End Sub

    Private Sub SaveMapOverwrite()
        ' Move the current file to the backups folder and push back
        ' and other backups already in there. Then save over the current file.

        ' If the Backups directory does not exist then create it
        If (Not System.IO.Directory.Exists(Application.StartupPath & "\Maps\Backups")) Then
            System.IO.Directory.CreateDirectory(Application.StartupPath & "\Maps\Backups")
        End If

        ' Copy the current map file to the Backups directory and add the date and time
        ' to its name.
        If System.IO.File.Exists(CMap.m_strFileName) Then
            System.IO.File.Copy(CMap.m_strFileName, Application.StartupPath & "\Maps\Backups\" _
                                & System.IO.Path.GetFileNameWithoutExtension(CMap.m_strFileName) _
                                & "-" & DateTime.Now.ToString("yyyyMMddHHmmss") & ".txt")
        End If

        ' Make sure we're not in sequence editing mode first then try to overwrite the saved map.
        chkSequenceEditor.Checked = False
        CMap.SaveMap(CMap.m_strFileName)
    End Sub

    Private Sub SaveMapAs()
        Dim fd As SaveFileDialog = New SaveFileDialog()

        ' If the Maps subdirectory does not exist then create it
        If (Not System.IO.Directory.Exists(Application.StartupPath & "\Maps")) Then
            System.IO.Directory.CreateDirectory(Application.StartupPath & "\Maps")
        End If

        fd.Title = "Save map as"
        fd.DefaultExt = "*.txt"
        fd.Filter = "Text Files|*.txt"
        fd.CreatePrompt = False
        fd.InitialDirectory = Application.StartupPath & "\Maps"
        If fd.ShowDialog = Windows.Forms.DialogResult.OK Then
            ' Only allow maps to be saved in the Maps sub-directory
            ' This makes it easier to keep track with backups etc..
            If System.IO.Path.GetDirectoryName(fd.FileName) = Application.StartupPath & "\Maps" Then
                ' Make sure we're not in sequence editing mode first, then call the SaveMap
                ' method from the Map class.
                chkSequenceEditor.Checked = False
                CMap.SaveMap(fd.FileName)
            Else
                MsgBox("Maps can only be saved in the Maps sub-directory where the program is located", _
                       vbCritical, "Invalid save directory.")
            End If
        End If
    End Sub

    Private Sub cmbSequence_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbSequence.SelectedIndexChanged
        ' If the selected sequence was changed then update the map 
        If CMap.m_intLastSequence <> cmbSequence.SelectedIndex Then

            ' Revert the map data to the original map data
            CMap.RevertMapChanges(CMap.m_intLastSequence, 0)

            ' Update the current sequence to the selected one and 
            ' select stage 0
            CMap.m_intLastSequence = cmbSequence.SelectedIndex
            CMap.m_intLastStage = 0

            ' Update the map changes combobox for this sequence/stage
            UpdateMapChangesComboBox(CMap.m_intLastSequence, CMap.m_intLastStage)

            ' TODO: Update the sequence property controls

            ' Look up the sequence dependancy changes for this sequence/stage.
            CMap.GetSequenceChanges(CMap.m_intLastSequence, CMap.m_intLastStage - 1)
            CMap.UpdateMapTiles(CTileMap)

            ' Update the stage combobox
            UpdateStageControls(CMap.m_intLastSequence, 0)

            ' Set the current stage's change highlighting
            CMap.UpdateStageChangeHighlighting(CMap.m_intLastSequence, CMap.m_intLastStage)

            ' Redraw the map
            g_blnMapViewChanged = True
            picMap.Refresh()

        End If
    End Sub

    Private Sub cmbStage_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles cmbStage.SelectedIndexChanged
        ' If the selected stage was changed then update the map 
        If CMap.m_intLastStage <> cmbStage.SelectedIndex Then

            ' Revert the map data to the original map data
            CMap.RevertMapChanges(CMap.m_intLastSequence, 0)

            ' Update the current stage to the selected one
            CMap.m_intLastStage = cmbStage.SelectedIndex

            ' Update the stage combobox
            UpdateStageControls(CMap.m_intLastSequence, cmbStage.SelectedIndex)

            ' Update the map changes combobox for this sequence/stage
            UpdateMapChangesComboBox(CMap.m_intLastSequence, CMap.m_intLastStage)

            ' Look up the sequence dependancy changes for this sequence/stage.
            CMap.GetSequenceChanges(CMap.m_intLastSequence, CMap.m_intLastStage - 1)
            CMap.UpdateMapTiles(CTileMap)

            ' Set the current stage's change highlighting
            CMap.UpdateStageChangeHighlighting(CMap.m_intLastSequence, CMap.m_intLastStage)

            ' Redraw the map
            g_blnMapViewChanged = True
            picMap.Refresh()

        End If
    End Sub

    Private Sub cmdAddSeq_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddSeq.Click
        ' If there were previously no sequences then make sure we copy the original tiles, since
        ' a copy won't have been made when we went into sequence editing mode
        If CMap.m_arrobjSequenceList.Count = 0 Then
            CMap.m_arrMapTilesOrig = DeepClone(CMap.m_arrMapTiles)
        End If
        ' Add a sequence to the end of the list using the next number
        CMap.m_arrobjSequenceList.Add(New Sequence)

        ' Also add a stage to the newly added sequence.
        CMap.m_arrobjSequenceList(CMap.m_arrobjSequenceList.Count - 1).m_objStages. _
            Add(New SequenceStage)

        ' Update the comboboxes, with the new sequence selected
        UpdateSequenceControls(CMap.m_arrobjSequenceList.Count - 1, 0)
    End Sub

    Private Sub cmdDelSeq_Click(sender As System.Object, e As System.EventArgs) Handles cmdDelSeq.Click
        ' Delete the sequence after a confirmation, then fix any switches or sequence dependancies
        ' that might have been affected.

        Dim n, m, i As Integer

        ' If there are no sequences then exit
        If CMap.m_arrobjSequenceList.Count = 0 Then
            Exit Sub
        End If

        ' Ask for confirmation before deleting
        If MsgBox("Are you sure you want to delete sequence " & cmbSequence.Text & "?", _
                  vbYesNo, "Confirm sequence deletion") = MsgBoxResult.Yes Then

            ' Remove from the list
            CMap.m_arrobjSequenceList.RemoveAt(cmbSequence.SelectedIndex)

            ' Loop through the any switches in the map to see if any of them
            ' had the sequence we just deleted as their sequence property
            For n = 0 To 47
                For m = 0 To 79
                    If CMap.m_arrMapTiles(n, m, 1).m_intType = 30 Then
                        If CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) = _
                         cmbSequence.SelectedIndex Then
                            ' Set it to a checkpoint if it was equal
                            CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) = -1
                        Else
                            If CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) > _
                             cmbSequence.SelectedIndex Then
                                ' Reduce it by 1 if it was higher
                                CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) = _
                                    CMap.m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) - 1
                            End If
                        End If
                    End If
                Next m
            Next n
            ' Look for switches in sequence changes
            For n = 0 To CMap.m_arrobjSequenceList.Count - 1
                For m = 0 To CMap.m_arrobjSequenceList(n).m_objStages.Count - 1
                    For i = 0 To CMap.m_arrobjSequenceList(n).m_objStages(n).m_objTileChanges.Count - 1
                        With CMap.m_arrobjSequenceList(n).m_objStages(n).m_objTileChanges(i)
                            If .mapObj.m_intType = 30 Then
                                If .mapObj.m_arrintPropertyValues(0) = _
                                 cmbSequence.SelectedIndex Then
                                    ' Set it to a checkpoint if it was equal
                                    .mapObj.m_arrintPropertyValues(0) = -1
                                Else
                                    If .mapObj.m_arrintPropertyValues(0) > _
                                 cmbSequence.SelectedIndex Then
                                        ' Reduce it by 1 if it was higher
                                        .mapObj.m_arrintPropertyValues(0) = .mapObj.m_arrintPropertyValues(0) - 1
                                    End If
                                End If
                            End If
                        End With
                    Next i
                Next m
            Next n

            ' Look for sequences that were dependant on the one we deleted
            For n = 0 To CMap.m_arrobjSequenceList.Count - 1
                ' Set to -1 if it was the deleted sequence
                If CMap.m_arrobjSequenceList(n).m_intDependsOnSequence = cmbSequence.SelectedIndex Then
                    CMap.m_arrobjSequenceList(n).m_intDependsOnSequence = -1
                    ' Reduce by one if it was a higher sequence    
                ElseIf CMap.m_arrobjSequenceList(n).m_intDependsOnSequence > _
                 cmbSequence.SelectedIndex Then
                    CMap.m_arrobjSequenceList(n).m_intDependsOnSequence = _
                        CMap.m_arrobjSequenceList(n).m_intDependsOnSequence - 1
                End If
            Next
        End If

    End Sub

    Private Sub cmdAddStage_Click(sender As System.Object, e As System.EventArgs) Handles cmdAddStage.Click
        ' Add a stage to the end of the list using the next number
        CMap.m_arrobjSequenceList(CMap.m_intLastSequence).m_objStages. _
            Add(New SequenceStage)

        ' Update the comboboxes, with the new sequence selected
        UpdateStageControls(CMap.m_intLastSequence, CMap.m_arrobjSequenceList(CMap.m_intLastSequence).m_objStages.Count - 1)
    End Sub

    Private Sub cmdDelStage_Click(sender As System.Object, e As System.EventArgs) Handles cmdDelStage.Click
        ' Delete the selected stage. This button will only be enabled when the last stage is selected

    End Sub

    Private Sub cmdEditContents_Click(sender As System.Object, e As System.EventArgs) Handles cmdEditContents.Click
        ' Open a new form for editing the contents of the selected container.
        ' Open the form as a modal dialog, so we can't change the selected tile until
        ' the contents editing form is closed.
        frmEditContents.ShowDialog()
    End Sub

    Private Sub chkLoop_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkLoop.CheckedChanged
        ' Toggle the current sequence loop property and enable/disable the Always On checkbox
        If chkLoop.Checked = True Then
            If cmbSequence.SelectedIndex >= 0 Then
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_blnLoop = True
                chkAlwaysOn.Enabled = True
            End If
        Else
            If cmbSequence.SelectedIndex >= 0 Then
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_blnLoop = False
                chkAlwaysOn.Checked = False
                chkAlwaysOn.Enabled = False
            End If
        End If
    End Sub

    Private Sub chkAlwaysOn_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAlwaysOn.CheckedChanged
        ' Toggle the current sequence AlwaysOn property
        If chkLoop.Checked = True Then
            If chkAlwaysOn.Checked = True Then
                If cmbSequence.SelectedIndex >= 0 Then
                    CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_blnAlwaysOn = True
                End If
            Else
                If cmbSequence.SelectedIndex >= 0 Then
                    CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_blnAlwaysOn = False
                End If
            End If
        Else
            If cmbSequence.SelectedIndex >= 0 Then
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_blnAlwaysOn = False
            End If
        End If

    End Sub

    Private Sub chkDelayFlash_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkDelayFlash.CheckedChanged
        ' Toggle the current sequence/stage Delay Flash property
        If chkDelayFlash.Checked = True Then
            If cmbSequence.SelectedIndex >= 0 And cmbStage.SelectedIndex >= 0 Then
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_objStages(cmbStage.SelectedIndex).m_blnDelayFlash = True
            End If
        Else
            If cmbSequence.SelectedIndex >= 0 And cmbStage.SelectedIndex >= 0 Then
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_objStages(cmbStage.SelectedIndex).m_blnDelayFlash = False
            End If
        End If
    End Sub

    Private Sub cmdSetDelayFrames_Click(sender As System.Object, e As System.EventArgs) Handles cmdSetDelayFrames.Click
        ' Set the Delay Frames property for the stage
        If IsNumeric(txtDelayFrames.Text) Then
            If CInt(txtDelayFrames.Text) > 0 Then
                If cmbSequence.SelectedIndex >= 0 And cmbStage.SelectedIndex >= 0 Then
                    CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_objStages(cmbStage.SelectedIndex).m_intDelayFrames = _
                     CInt(txtDelayFrames.Text)
                End If
            Else
                ' Negative value entered so set to 0
                If cmbSequence.SelectedIndex >= 0 And cmbStage.SelectedIndex >= 0 Then
                    txtDelayFrames.Text = "0"
                    CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_objStages(cmbStage.SelectedIndex).m_intDelayFrames = 0
                End If
            End If
        Else
            ' Non-numeric value entered so set to 0
            If cmbSequence.SelectedIndex >= 0 And cmbStage.SelectedIndex >= 0 Then
                txtDelayFrames.Text = "0"
                CMap.m_arrobjSequenceList(cmbSequence.SelectedIndex).m_objStages(cmbStage.SelectedIndex).m_intDelayFrames = 0
            End If
        End If
    End Sub

    ' -------------
    ' Menu handlers
    ' -------------
    Private Sub MapPropertiesToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles MapPropertiesToolStripMenuItem.Click
        frmMapProperties.ShowDialog()
    End Sub

    Private Sub CheckpointsToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CheckpointsToolStripMenuItem.Click
        frmCheckpoints.ShowDialog()
    End Sub

    Private Sub SanityCheckToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SanityCheckToolStripMenuItem.Click
        CMap.SanityCheck()
    End Sub

    Private Sub LoadMapToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles LoadMapToolStripMenuItem.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()
        Dim strFileName As String

        ' Open a file selector at the maps folder location, or the program's
        ' location if the Maps folder doesn't exist for some reason.
        ' The Maps folder will be created upon trying to save a map if it
        ' does not exist.
        fd.Title = "Load Map"
        If (Not System.IO.Directory.Exists(Application.StartupPath & "\Maps")) Then
            fd.InitialDirectory = Application.StartupPath
        Else
            fd.InitialDirectory = Application.StartupPath & "\Maps"
        End If
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
            If CMap.LoadMap(fd.FileName) = 0 Then
                g_blnTilePickerChanged = True
                CTileMap.DrawTilesToPicBox(picTiles)

                ' Set the filename variable
                CMap.m_strFileName = fd.FileName

                ' Update the map checkpoints
                frmCheckpoints.UpdateCheckpoints()

                ' Refresh the map picturebox
                picMap.Refresh()

                ' Enable the menu items
                LoadMapToolStripMenuItem.Enabled = True
                SaveMapToolStripMenuItem.Enabled = True
                SaveAsToolStripMenuItem.Enabled = True
                QuickSaveMapAsCToolStripMenuItem.Enabled = True
                MapPropertiesToolStripMenuItem.Enabled = True
                CheckpointsToolStripMenuItem.Enabled = True
                SanityCheckToolStripMenuItem.Enabled = True

            End If
        End If
    End Sub

    Private Sub SaveMapToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SaveMapToolStripMenuItem.Click
        ' If the map has already been saved at least once(It's filename is stored in the CMap class), call the
        ' save overwrite procedure, otherwise call the save as procedure.
        If CMap.m_strFileName <> Nothing Then
            Call SaveMapOverwrite()
        Else
            Call SaveMapAs()
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click
        Call SaveMapAs()
    End Sub

    Private Sub QuickSaveMapAsCToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles QuickSaveMapAsCToolStripMenuItem.Click
        ' If the map has already been saved and the filename is known:
        ' Lookup the EntombedGBA game path from the ini file
        ' If the EntombedGBA game path is valid:
        ' Call the SaveMapOverwrite procedure, which will create the .c and .h file at the program path.
        ' Copy/overwrite the .c and .h files to the src and include folders.
        Dim Sections As ArrayList
        Dim Keys As ArrayList
        Dim SectionEnumerator As System.Collections.IEnumerator
        Dim KeyEnumerator As System.Collections.IEnumerator
        Dim strPath As String = ""
        Dim arrFilenames(0) As String

        ' Make sure the map has already been saved and the filename is known
        If CMap.m_strFileName Is Nothing Then
            MsgBox("Map has not yet been saved. Save it to a file first.", MsgBoxStyle.Critical, "Map not yet saved")
            Exit Sub
        End If

        ' Make sure the setings.ini file exists
        If (Not System.IO.File.Exists(Application.StartupPath & "\settings.ini")) Then
            MsgBox("settings.ini file not found", MsgBoxStyle.Critical, "File not found")
            Exit Sub
        End If

        Dim myIniFile = New IniFile.IniFile(Application.StartupPath & "\settings.ini", False)
        arrFilenames(0) = CMap.m_strFileName

        ' Get the section list
        Sections = myIniFile.GetSections()
        SectionEnumerator = Sections.GetEnumerator()
        While SectionEnumerator.MoveNext()
            If SectionEnumerator.Current.iscommented = False And UCase(SectionEnumerator.Current.Name) = "GAMEDIR" Then
                ' Get the keys
                Keys = myIniFile.GetKeys(SectionEnumerator.Current.Name)
                KeyEnumerator = Keys.GetEnumerator()
                While KeyEnumerator.MoveNext()
                    ' Set the EntombedGBA path variable
                    strPath = KeyEnumerator.Current.Value
                End While
            End If
        End While

        ' Check that the path was set
        If System.IO.Directory.Exists(strPath) Then
            If System.IO.Directory.Exists(strPath & "\src") And _
               System.IO.Directory.Exists(strPath & "\include") Then
                ' Save the map
                Call SaveMapOverwrite()
                ' Save the .c and.h file
                CMap.SaveMapAsC(arrFilenames)
                ' Make sure both files got created
                If System.IO.File.Exists(Application.StartupPath & "\level_data.c") And
                   System.IO.File.Exists(Application.StartupPath & "\level_data.h") Then
                    ' Copy the files to the src and include directories
                    System.IO.File.Copy(Application.StartupPath & "\level_data.c", strPath & "\src\level_data.c", True)
                    System.IO.File.Copy(Application.StartupPath & "\level_data.h", strPath & "\include\level_data.h", True)
                Else
                    MsgBox("The level_data.c and/or the level_data.h files could not be created for some reason.", _
                           MsgBoxStyle.Critical, "Files not created")
                End If
            Else
                MsgBox("src or include folder not found in EntombedGBA directory. Both folders must exist.", _
                       MsgBoxStyle.Critical, "Sub-folder not found")
            End If
        Else
            MsgBox("EntombedGBA path not found, check that the settings.ini file is correct", MsgBoxStyle.Critical, _
                   "EntombedGBA path not found")
        End If
    End Sub

    Private Sub MultiSaveMapsAsCToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles MultiSaveMapsAsCToolStripMenuItem.Click

        ' Make sure we're not in sequence editing mode first.
        chkSequenceEditor.Checked = False

        ' Open a form which will allow you to add and remove map files to a list.
        ' Opens a file open dialog to add files. Verify that map files are ok before adding.
        ' There will be a button to save the file list to the .c/.h files.
        frmSaveAsC.Show()

    End Sub

    Private Sub NewMapToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles NewMapToolStripMenuItem.Click

        Dim n, m As Integer

        'Get a confirmation first
        If MsgBox("Create a new map?", MsgBoxStyle.OkCancel Or MsgBoxStyle.DefaultButton2, "Create New Map") _
            = MsgBoxResult.Ok Then
            ' Re-Initialize all map locations to alternating lines of wall tile 1 and 2
            ' Delete all sequences
            For n = 0 To 47
                For m = 0 To 79
                    CMap.m_arrMapTiles(n, m, 0) = New MapObject((n Mod 2) + 1)
                    CMap.m_arrMapTiles(n, m, 1) = New MapObject(0)
                    CMap.m_arrMapTiles(n, m, 3) = New MapObject(0)
                    CMap.m_arrChangedTiles(n, m) = True
                Next m
            Next n
            CMap.m_arrobjSequenceList = Nothing
            CMap.UpdateMapTiles(CTileMap)

            ' Reset the map filename variable
            CMap.m_strFileName = ""

            ' Enable the menu items
            LoadMapToolStripMenuItem.Enabled = True
            SaveMapToolStripMenuItem.Enabled = True
            SaveAsToolStripMenuItem.Enabled = True
            QuickSaveMapAsCToolStripMenuItem.Enabled = True
            MapPropertiesToolStripMenuItem.Enabled = True
            CheckpointsToolStripMenuItem.Enabled = True
            SanityCheckToolStripMenuItem.Enabled = True

        End If

    End Sub
End Class