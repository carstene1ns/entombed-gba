﻿Partial Public Class Map
    Structure SanityCheckLocation
        Public x As Integer
        Public y As Integer
        Public layer As Integer
        Public seq As Integer
        Public errnum As Integer
    End Structure

    ' Variable to store map location data for up to 3 layers
    Private m_objMapLoc(0 To 2) As MapObject

    ' Sanity check result variables
    Private m_objTmpLocation As SanityCheckLocation ' Use this to fill the lists below
    Public m_objIntersectingWalls As List(Of SanityCheckLocation)
    Public m_objSpritePathErrors As List(Of SanityCheckLocation)
    Public m_arrTriggeredSequences() As Boolean ' True when a trigger is found for a sequence
    Public m_arrobjPropertyValueErrors As List(Of SanityCheckLocation)

    ' 2-dimensional array of error messages relating to each sanity check type.
    ' The SanityCheckLocation structure has an errnum property which the error messages are indexed by.
    Private m_strErrorMsgs()() As String = {({"Wall intersects fixture.", "Wall intersects sprite."}), _
                                            ({"xMin is higher than xMax", "Wall blocks path.", _
                                            "Empty wall tile under enemy path."}), _
                                            ({"A property value is too low (<-1)", "A property value is too high"})}

    Public Sub SanityCheck()

        Dim n, m As Integer
        Dim blnIssuesFound As Boolean
        Dim blnSwitchIssueFound As Boolean
        Dim writer As IO.StreamWriter

        ' This procedure looks at the map data and checks that there are no errors or omissions that it would be
        ' difficult to check for elsewhere in the program.
        ' Ideas for sanity checks:
        ' Check that the player start location is in a 2 tile empty space with a wall below.
        ' Check certain properties for validity, e.g. xMin/xMax must be >0 and <79 xMin must be lower than or equal to xMax.
        ' Check that all triggered sequences do have a trigger assigned (AlwaysOn = false). Report any that don't.

        ' Initialise the lists
        m_objIntersectingWalls = New List(Of SanityCheckLocation)
        m_objSpritePathErrors = New List(Of SanityCheckLocation)

        ' Disable sequence editing and loop through the original map locations
        frmMain.chkSequenceEditor.Checked = False
        For n = 0 To 47
            For m = 0 To 79
                ' Intersecting walls check.
                ' Do some checks before calling the procedure. (Previously these checks were done from
                ' within the CheckIntersectingWalls, meaning the procedure had to be called every time.)
                If (m_arrMapTiles(n, m, 1).m_intType > 0 And m_arrMapTiles(n, m, 1).m_intType < 99) Or _
                   (m_arrMapTiles(n, m, 3).m_intType > 0 And m_arrMapTiles(n, m, 3).m_intType < 99) Then
                    CheckIntersectingWalls(m, n, -1)
                End If

                ' Sprite paths check. Do some checks before calling the procedure. (enemy or platform tiles)
                If m_arrMapTiles(n, m, 3).m_intType = 26 Or m_arrMapTiles(n, m, 3).m_intType = 27 Or _
                    m_arrMapTiles(n, m, 3).m_intType = 32 Then
                    CheckSpritePaths(m, n, -1)
                End If

            Next m
        Next n

        ' Enable sequence editing mode and loop through each sequence by changing the
        ' sequence combo box on frmMain.
        ' TODO: Commented out for now since it's more complicated than I thought.
        'If CMap.m_arrobjSequenceList Is Nothing = False Then
        '    If CMap.m_arrobjSequenceList.Count > 0 Then
        '        frmMain.chkSequenceEditor.Checked = True
        '        ' Loop through sequences
        '        For i = 0 To CMap.m_arrobjSequenceList.Count - 1
        '            frmMain.cmbSequence.SelectedIndex = i
        '            ' Loop through locations
        '            For n = 0 To 47
        '                For m = 0 To 79
        '                    ' Intersecting walls check.
        '                    CheckIntersectingWalls(m, n, i)
        '                    ' Sprite paths check
        '                    CheckSpritePaths(m, n, i)
        '                Next m
        '            Next n
        '        Next i
        '    End If
        'End If

        ' Check switches
        Call GetSwitchSequenceProperties()

        ' Check player start position.
        'm_pntPlayerStartLocation
        If m_arrMapTiles((m_pntPlayerStartLocation.Y / 16), (m_pntPlayerStartLocation.X / 32), 0).m_intType <> 0 Or _
            m_arrMapTiles((m_pntPlayerStartLocation.Y / 16) + 1, (m_pntPlayerStartLocation.X / 32), 0).m_intType <> 0 Then
        End If

        ' Check that all property values are within a valid range
        Call CheckPropertyValues()

        ' Create report if any issues were found
        blnIssuesFound = False
        If m_objIntersectingWalls.Count > 0 Then blnIssuesFound = True
        If m_objSpritePathErrors.Count > 0 Then blnIssuesFound = True
        For n = 0 To UBound(m_arrTriggeredSequences) - 1
            If blnIssuesFound = True Then Exit For
            If m_arrTriggeredSequences(n) = False Then
                blnIssuesFound = True
            End If
        Next n

        If blnIssuesFound = True Then
            Try
                ' Create the report file in the program directory
                writer = My.Computer.FileSystem.OpenTextFileWriter(Application.StartupPath + "\Map_Issues.txt", False)
                If m_objIntersectingWalls.Count > 0 Then
                    writer.WriteLine("Walls intersecting fixtures/sprites:")
                    For n = 0 To m_objIntersectingWalls.Count - 1
                        writer.WriteLine("X: " & CStr(m_objIntersectingWalls(n).x) & _
                                         " Y: " & CStr(m_objIntersectingWalls(n).y) & _
                                         " L: " & CStr(m_objIntersectingWalls(n).layer) & _
                                         If(m_objIntersectingWalls(n).seq > -1, " Seq: " & CStr(m_objIntersectingWalls(n).seq), "") & _
                                         " Err: " & m_strErrorMsgs(0)(m_objIntersectingWalls(n).errnum))
                    Next n
                End If
                If m_objSpritePathErrors.Count > 0 Then
                    writer.WriteLine("Sprite path errors:")
                    For n = 0 To m_objSpritePathErrors.Count - 1
                        writer.WriteLine("X: " & CStr(m_objSpritePathErrors(n).x) & _
                                         " Y: " & CStr(m_objSpritePathErrors(n).y) & _
                                         If(m_objSpritePathErrors(n).seq > -1, " Seq: " & CStr(m_objSpritePathErrors(n).seq), "") & _
                                         " Err: " & m_strErrorMsgs(1)(m_objSpritePathErrors(n).errnum))
                    Next n
                End If
                blnSwitchIssueFound = False
                For n = 0 To UBound(m_arrTriggeredSequences) - 1
                    If m_arrTriggeredSequences(n) = False Then
                        If blnSwitchIssueFound = False Then writer.WriteLine("Untriggered sequences:")
                        writer.WriteLine(CStr(n))
                        blnSwitchIssueFound = True
                    End If
                Next n
                If m_arrobjPropertyValueErrors Is Nothing = False Then
                    If m_arrobjPropertyValueErrors.Count > 0 Then
                        writer.WriteLine("Property range errors:")
                        For n = 0 To m_objSpritePathErrors.Count - 1
                            writer.WriteLine("X: " & CStr(m_arrobjPropertyValueErrors(n).x) & _
                                             " Y: " & CStr(m_arrobjPropertyValueErrors(n).y) & _
                                             If(m_arrobjPropertyValueErrors(n).seq > -1, " Seq: " & CStr(m_arrobjPropertyValueErrors(n).seq), "") & _
                                             " Err: " & m_strErrorMsgs(1)(m_arrobjPropertyValueErrors(n).errnum))
                        Next n
                    End If
                End If

                writer.Close()
                MsgBox("Some possible issues were found. See the Map_Issues.txt file in the program folder.", MsgBoxStyle.OkOnly, "Issues found")
            Catch
            End Try
        Else
            MsgBox("No issues were found.", MsgBoxStyle.OkOnly, "No issues")
        End If

    End Sub

    Private Sub CheckIntersectingWalls(x As Integer, y As Integer, seq As Integer)

        ' Check that any layer 1/3 objects are not in locations that have walls in them.
        ' If mapLoc is nothing then look at the original map locaiton, otherwise use the MapObject data.
        If seq = -1 Then
            ' Get all layers from regular map tiles
            m_objMapLoc(0) = m_arrMapTiles(y, x, 0)
            m_objMapLoc(1) = m_arrMapTiles(y, x, 1)
            m_objMapLoc(2) = m_arrMapTiles(y, x, 3)
        Else
            ' else get all layers using GetTileData
            m_objMapLoc(0) = GetTileData(x, y, 0)
            m_objMapLoc(1) = GetTileData(x, y, 1)
            m_objMapLoc(2) = GetTileData(x, y, 3)
        End If

        ' Check fixture layer
        If (m_objMapLoc(1).m_intType > 0 And m_objMapLoc(1).m_intType < 99) Then
            If m_arrMapTiles(y, x, 0).m_intType > 0 Then
                ' Wall is intersecting fixture at this location on the original map tiles.
                m_objTmpLocation.x = x
                m_objTmpLocation.y = y
                m_objTmpLocation.layer = 1
                m_objTmpLocation.seq = seq
                m_objTmpLocation.errnum = 0
                m_objIntersectingWalls.Add(m_objTmpLocation)
                m_objTmpLocation = Nothing
            End If
        End If
        ' Check sprite layer
        If (m_objMapLoc(1).m_intType > 0 And m_objMapLoc(1).m_intType < 99) Then
            If m_arrMapTiles(y, x, 0).m_intType > 0 Then
                ' Wall is intersecting sprite at this location on the original map tiles.
                m_objTmpLocation.x = x
                m_objTmpLocation.y = y
                m_objTmpLocation.layer = 3
                m_objTmpLocation.seq = seq
                m_objTmpLocation.errnum = 1
                m_objIntersectingWalls.Add(m_objTmpLocation)
                m_objTmpLocation = Nothing
            End If
        End If

    End Sub

    Private Sub CheckSpritePaths(x As Integer, y As Integer, seq As Integer)
        Dim n As Integer
        ' Check that moving platforms and enemies have valid paths
        ' We'll look at the tile type here because moving plaforms have a little more freedom of
        ' movement than enemies, i.e. they can float whereas enemies have to walk on solid ground.
        If seq = -1 Then
            ' Get sprite layer data from regular map tiles
            m_objMapLoc(0) = m_arrMapTiles(y, x, 3)
        Else
            ' Else get sprite layer data using GetTileData
            m_objMapLoc(0) = GetTileData(x, y, 3)
        End If

        ' Check for enemies
        If m_objMapLoc(0).m_intType = 26 Or m_objMapLoc(0).m_intType = 27 Then
            ' Check if xMin is higher than xMax
            If m_objMapLoc(0).m_arrintPropertyValues(1) > m_objMapLoc(0).m_arrintPropertyValues(2) Then
                m_objTmpLocation.x = x
                m_objTmpLocation.y = y
                m_objTmpLocation.layer = 3
                m_objTmpLocation.seq = seq
                m_objTmpLocation.errnum = 0
                m_objSpritePathErrors.Add(m_objTmpLocation)
                m_objTmpLocation = Nothing
                Exit Sub
            End If
            ' Check that the enemy's path is clear of walls.
            ' Loop through the path x locations.
            For n = m_objMapLoc(0).m_arrintPropertyValues(1) To m_objMapLoc(0).m_arrintPropertyValues(2)
                ' Get the upper and lower wall tile for current x location of the path
                If seq = -1 Then
                    m_objMapLoc(1) = m_arrMapTiles(y, Int(n / 32), 0)
                    m_objMapLoc(2) = m_arrMapTiles(y + 1, Int(n / 32), 0)
                Else
                    m_objMapLoc(1) = GetTileData(Int(n / 32), y, 0)
                    m_objMapLoc(2) = GetTileData(Int(n / 32), y + 1, 0)
                End If

                ' Check if there's any wall in the way
                If m_objMapLoc(1).m_intType > 0 Or m_objMapLoc(2).m_intType > 0 Then
                    m_objTmpLocation.x = x
                    m_objTmpLocation.y = y
                    m_objTmpLocation.layer = 3
                    m_objTmpLocation.seq = seq
                    m_objTmpLocation.errnum = 1
                    m_objSpritePathErrors.Add(m_objTmpLocation)
                    m_objTmpLocation = Nothing
                    Exit Sub
                End If
            Next n

            ' Check that the enemy's path has no empty walls underneath where they'll walk.
            For n = m_objMapLoc(0).m_arrintPropertyValues(1) To m_objMapLoc(0).m_arrintPropertyValues(2)
                ' Get the wall layer data underneath the enemy path at the current x location
                If seq = -1 Then
                    m_objMapLoc(1) = m_arrMapTiles(y + 2, Int(n / 32), 0)
                Else
                    m_objMapLoc(1) = GetTileData(Int(n / 32), y + 2, 0)
                End If
                ' Check for an empty wall
                If m_objMapLoc(1).m_intType = 0 Then
                    m_objTmpLocation.x = x
                    m_objTmpLocation.y = y
                    m_objTmpLocation.layer = 3
                    m_objTmpLocation.seq = seq
                    m_objTmpLocation.errnum = 2
                    m_objSpritePathErrors.Add(m_objTmpLocation)
                    m_objTmpLocation = Nothing
                    Exit Sub
                End If
            Next n
        End If

        ' Check for moving platforms
        If m_objMapLoc(0).m_intType = 32 Then

            ' Check if xMin is higher than xMax
            If m_objMapLoc(0).m_arrintPropertyValues(1) > m_objMapLoc(0).m_arrintPropertyValues(2) Then
                m_objTmpLocation.x = x
                m_objTmpLocation.y = y
                m_objTmpLocation.layer = 3
                m_objTmpLocation.seq = seq
                m_objTmpLocation.errnum = 0
                m_objSpritePathErrors.Add(m_objTmpLocation)
                m_objTmpLocation = Nothing
                Exit Sub
            End If

            ' Check that the moving platforms path is clear of walls.
            ' Loop through the path x locations.
            For n = m_objMapLoc(0).m_arrintPropertyValues(1) To m_objMapLoc(0).m_arrintPropertyValues(2)
                ' Get the upper and lower wall tile for current x location of the path
                If seq = -1 Then
                    m_objMapLoc(1) = m_arrMapTiles(y, n, 0)
                Else
                    m_objMapLoc(1) = GetTileData(n, y, 0)
                End If

                ' Check if there's any wall in the way
                If m_objMapLoc(1).m_intType > 0 Then
                    m_objTmpLocation.x = x
                    m_objTmpLocation.y = y
                    m_objTmpLocation.layer = 3
                    m_objTmpLocation.seq = seq
                    m_objTmpLocation.errnum = 1
                    m_objSpritePathErrors.Add(m_objTmpLocation)
                    m_objTmpLocation = Nothing
                    Exit Sub
                End If
            Next n
        End If
    End Sub

    Private Sub GetSwitchSequenceProperties()
        ' Make sure all sequences that are triggered by switches have a triggering switch.
        ' NB: Sequences can have more than one switch trigger
        Dim n, m, i As Integer
        Dim objTemp As MapObject

        If m_arrobjSequenceList Is Nothing = False Then
            If m_arrobjSequenceList.Count > 0 Then
                ' Setup the array
                ReDim m_arrTriggeredSequences(0 To m_arrobjSequenceList.Count - 1)
                For n = 0 To m_arrobjSequenceList.Count - 1
                    m_arrTriggeredSequences(n) = False
                Next n

                ' Loop through map locations and gather the sequence property of all switches found
                For n = 0 To 47
                    For m = 0 To 79
                        ' Look for a switch in the original map tiles, set m_arrTriggeredSequences for the sequence
                        ' property value to true if it's not -1.
                        If m_arrMapTiles(n, m, 1).m_intType = 30 Then
                            If m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                                'If m_arrTriggeredSequences(m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0)) <> -1 Then
                                If m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0) <> -1 Then
                                    m_arrTriggeredSequences(m_arrMapTiles(n, m, 1).m_arrintPropertyValues(0)) = True
                                End If
                            End If
                        End If
                    Next m
                Next n

                ' Loop through sequences, stages then loop through any tile changes
                For i = 0 To m_arrobjSequenceList.Count - 1
                    For n = 0 To m_arrobjSequenceList(i).m_objStages.Count - 1
                        ' Check that there are map changes
                        If m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges Is Nothing = False Then
                            For m = 0 To m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges.Count - 1
                                ' Check for a switch
                                objTemp = m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges(m).mapObj
                                If objTemp.m_intType = 30 Then
                                    If objTemp.m_arrintPropertyValues Is Nothing = False Then
                                        'If m_arrTriggeredSequences(objTemp.m_arrintPropertyValues(0)) <> -1 Then
                                        If objTemp.m_arrintPropertyValues(0) <> -1 Then
                                            m_arrTriggeredSequences(objTemp.m_arrintPropertyValues(0)) = True
                                        End If
                                    End If
                                End If
                            Next m
                        End If
                    Next n
                Next i

                ' Loop through sequences and check the "Always on" property
                For i = 0 To m_arrobjSequenceList.Count - 1
                    If m_arrobjSequenceList(n).m_blnAlwaysOn = True Then
                        m_arrTriggeredSequences(i) = True
                    End If
                Next i

                ' Loop through checkpoints and find activated sequences
                If m_checkPoints Is Nothing = False Then
                    If m_checkPoints.Count > 0 Then
                        For i = 0 To m_checkPoints.Count - 1
                            If m_checkPoints(i).sequences Is Nothing = False Then
                                If m_checkPoints(i).sequences.Count > 0 Then
                                    For m = 0 To m_checkPoints(i).sequences.Count - 1
                                        m_arrTriggeredSequences(m_checkPoints(i).sequences(m)) = True
                                    Next m
                                End If
                            End If
                        Next i
                    End If
                End If
            End If
        End If

    End Sub

    Private Sub CheckPropertyValues()

        'm_arrobjPropertyValueErrors
        Dim n, m, i, x As Integer
        Dim objTemp As MapObject

        ' Loop through all map locations
        For n = 0 To 47
            For m = 0 To 79

                ' Check fixture layer
                If m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                    For i = 0 To m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count - 1
                        If m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count < -1 Or _
                           m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count > 32767 Then
                            m_objTmpLocation.x = m
                            m_objTmpLocation.y = n
                            m_objTmpLocation.layer = 1
                            m_objTmpLocation.seq = -1
                            If m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count < -1 Then
                                m_objTmpLocation.errnum = 0
                            End If
                            If m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count > 32767 Then
                                m_objTmpLocation.errnum = 1
                            End If
                            m_arrobjPropertyValueErrors.Add(m_objTmpLocation)
                            m_objTmpLocation = Nothing
                        End If
                    Next i
                End If
                ' Check sprite layer
                If m_arrMapTiles(n, m, 1).m_arrintPropertyValues Is Nothing = False Then
                    For i = 0 To m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count - 1
                        If m_arrMapTiles(n, m, 1).m_arrintPropertyValues(i) < -1 Or _
                           m_arrMapTiles(n, m, 1).m_arrintPropertyValues(i) > 32767 Then
                            m_objTmpLocation.x = m
                            m_objTmpLocation.y = n
                            m_objTmpLocation.layer = 3
                            m_objTmpLocation.seq = -1
                            If m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count < -1 Then
                                m_objTmpLocation.errnum = 0
                            End If
                            If m_arrMapTiles(n, m, 1).m_arrintPropertyValues.Count > 32767 Then
                                m_objTmpLocation.errnum = 1
                            End If
                            m_arrobjPropertyValueErrors.Add(m_objTmpLocation)
                            m_objTmpLocation = Nothing
                        End If
                    Next i
                End If

            Next m
        Next n

        ' Check sequence property values
        ' Loop through sequences, stages then loop through any tile changes
        If m_arrobjSequenceList Is Nothing = False Then
            If m_arrobjSequenceList.Count > 0 Then
                For i = 0 To m_arrobjSequenceList.Count - 1
                    For n = 0 To m_arrobjSequenceList(i).m_objStages.Count - 1
                        ' Check that there are map changes
                        If m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges Is Nothing = False Then
                            For m = 0 To m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges.Count - 1
                                objTemp = m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges(m).mapObj
                                If objTemp.m_arrintPropertyValues Is Nothing = False Then
                                    ' Loop through the properties.
                                    For x = 0 To objTemp.m_arrintPropertyValues.Count - 1
                                        If objTemp.m_arrintPropertyValues(x) < -1 Or _
                                           objTemp.m_arrintPropertyValues(x) > 32767 Then
                                            m_objTmpLocation.x = m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges(m).xPos
                                            m_objTmpLocation.y = m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges(m).yPos
                                            m_objTmpLocation.layer = m_arrobjSequenceList(i).m_objStages(n).m_objTileChanges(m).layer
                                            m_objTmpLocation.seq = i
                                            If objTemp.m_arrintPropertyValues(x) < -1 Then
                                                m_objTmpLocation.errnum = 0
                                            End If
                                            If objTemp.m_arrintPropertyValues(x) > 32767 Then
                                                m_objTmpLocation.errnum = 1
                                            End If
                                            m_arrobjPropertyValueErrors.Add(m_objTmpLocation)
                                            m_objTmpLocation = Nothing
                                        End If
                                    Next x
                                End If
                            Next m
                        End If
                    Next n
                Next i
            End If
        End If
    End Sub
End Class
