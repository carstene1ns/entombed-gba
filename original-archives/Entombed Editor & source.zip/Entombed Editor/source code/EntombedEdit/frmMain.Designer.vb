﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewMapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.LoadMapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveMapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.QuickSaveMapAsCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MultiSaveMapsAsCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapPropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckpointsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SanityCheckToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.grpStageProperties = New System.Windows.Forms.GroupBox()
        Me.cmdSetDelayFrames = New System.Windows.Forms.Button()
        Me.txtDelayFrames = New System.Windows.Forms.TextBox()
        Me.chkDelayFlash = New System.Windows.Forms.CheckBox()
        Me.lblDelayFrames = New System.Windows.Forms.Label()
        Me.grpMode = New System.Windows.Forms.GroupBox()
        Me.chkSequenceEditor = New System.Windows.Forms.CheckBox()
        Me.radModeDraw = New System.Windows.Forms.RadioButton()
        Me.radModeSelect = New System.Windows.Forms.RadioButton()
        Me.grpSequenceProperties = New System.Windows.Forms.GroupBox()
        Me.lblTriggeringSwitch = New System.Windows.Forms.Label()
        Me.chkAlwaysOn = New System.Windows.Forms.CheckBox()
        Me.chkLoop = New System.Windows.Forms.CheckBox()
        Me.cmbDependsOnSequence = New System.Windows.Forms.ComboBox()
        Me.lblDependsOnSequence = New System.Windows.Forms.Label()
        Me.lblCoords = New System.Windows.Forms.Label()
        Me.cmdEditContents = New System.Windows.Forms.Button()
        Me.grpLayerSelection = New System.Windows.Forms.GroupBox()
        Me.radLayerSprites = New System.Windows.Forms.RadioButton()
        Me.radLayerWalls = New System.Windows.Forms.RadioButton()
        Me.radLayerFixtures = New System.Windows.Forms.RadioButton()
        Me.cmdSetProperty = New System.Windows.Forms.Button()
        Me.grpSelection = New System.Windows.Forms.GroupBox()
        Me.picSelection = New System.Windows.Forms.PictureBox()
        Me.lblSelection = New System.Windows.Forms.Label()
        Me.txtPropertyValue = New System.Windows.Forms.TextBox()
        Me.lblSequence = New System.Windows.Forms.Label()
        Me.cmdDelStage = New System.Windows.Forms.Button()
        Me.cmbSequence = New System.Windows.Forms.ComboBox()
        Me.cmdDelSeq = New System.Windows.Forms.Button()
        Me.lblStage = New System.Windows.Forms.Label()
        Me.cmdAddStage = New System.Windows.Forms.Button()
        Me.cmbStage = New System.Windows.Forms.ComboBox()
        Me.cmdAddSeq = New System.Windows.Forms.Button()
        Me.lblMapChanges = New System.Windows.Forms.Label()
        Me.cmbPropertyValues = New System.Windows.Forms.ComboBox()
        Me.cmbMapChanges = New System.Windows.Forms.ComboBox()
        Me.lblPropertyValues = New System.Windows.Forms.Label()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.cmbTileTypes = New System.Windows.Forms.ComboBox()
        Me.picTiles = New System.Windows.Forms.PictureBox()
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.picMap = New System.Windows.Forms.PictureBox()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.grpStageProperties.SuspendLayout()
        Me.grpMode.SuspendLayout()
        Me.grpSequenceProperties.SuspendLayout()
        Me.grpLayerSelection.SuspendLayout()
        Me.grpSelection.SuspendLayout()
        CType(Me.picSelection, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.picTiles, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMap, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer3)
        Me.SplitContainer1.Panel1MinSize = 60
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1022, 618)
        Me.SplitContainer1.SplitterDistance = 167
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.IsSplitterFixed = True
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        Me.SplitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.MenuStrip1)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpStageProperties)
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpMode)
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpSequenceProperties)
        Me.SplitContainer3.Panel2.Controls.Add(Me.lblCoords)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdEditContents)
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpLayerSelection)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdSetProperty)
        Me.SplitContainer3.Panel2.Controls.Add(Me.grpSelection)
        Me.SplitContainer3.Panel2.Controls.Add(Me.txtPropertyValue)
        Me.SplitContainer3.Panel2.Controls.Add(Me.lblSequence)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdDelStage)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmbSequence)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdDelSeq)
        Me.SplitContainer3.Panel2.Controls.Add(Me.lblStage)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdAddStage)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmbStage)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmdAddSeq)
        Me.SplitContainer3.Panel2.Controls.Add(Me.lblMapChanges)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmbPropertyValues)
        Me.SplitContainer3.Panel2.Controls.Add(Me.cmbMapChanges)
        Me.SplitContainer3.Panel2.Controls.Add(Me.lblPropertyValues)
        Me.SplitContainer3.Size = New System.Drawing.Size(1022, 167)
        Me.SplitContainer3.SplitterDistance = 25
        Me.SplitContainer3.TabIndex = 29
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.MapToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 2)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(88, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewMapToolStripMenuItem, Me.ToolStripSeparator2, Me.LoadMapToolStripMenuItem, Me.SaveMapToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.ToolStripSeparator1, Me.QuickSaveMapAsCToolStripMenuItem, Me.MultiSaveMapsAsCToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewMapToolStripMenuItem
        '
        Me.NewMapToolStripMenuItem.Name = "NewMapToolStripMenuItem"
        Me.NewMapToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.NewMapToolStripMenuItem.Text = "New Map"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(181, 6)
        '
        'LoadMapToolStripMenuItem
        '
        Me.LoadMapToolStripMenuItem.Name = "LoadMapToolStripMenuItem"
        Me.LoadMapToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.LoadMapToolStripMenuItem.Text = "Load Map"
        '
        'SaveMapToolStripMenuItem
        '
        Me.SaveMapToolStripMenuItem.Enabled = False
        Me.SaveMapToolStripMenuItem.Name = "SaveMapToolStripMenuItem"
        Me.SaveMapToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.SaveMapToolStripMenuItem.Text = "Save Map"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Enabled = False
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save As"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(181, 6)
        '
        'QuickSaveMapAsCToolStripMenuItem
        '
        Me.QuickSaveMapAsCToolStripMenuItem.Enabled = False
        Me.QuickSaveMapAsCToolStripMenuItem.Name = "QuickSaveMapAsCToolStripMenuItem"
        Me.QuickSaveMapAsCToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.QuickSaveMapAsCToolStripMenuItem.Text = "Quick Save Map as C"
        '
        'MultiSaveMapsAsCToolStripMenuItem
        '
        Me.MultiSaveMapsAsCToolStripMenuItem.Name = "MultiSaveMapsAsCToolStripMenuItem"
        Me.MultiSaveMapsAsCToolStripMenuItem.Size = New System.Drawing.Size(184, 22)
        Me.MultiSaveMapsAsCToolStripMenuItem.Text = "Multi Save as C"
        '
        'MapToolStripMenuItem
        '
        Me.MapToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MapPropertiesToolStripMenuItem, Me.CheckpointsToolStripMenuItem, Me.SanityCheckToolStripMenuItem})
        Me.MapToolStripMenuItem.Name = "MapToolStripMenuItem"
        Me.MapToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.MapToolStripMenuItem.Text = "Map"
        '
        'MapPropertiesToolStripMenuItem
        '
        Me.MapPropertiesToolStripMenuItem.Enabled = False
        Me.MapPropertiesToolStripMenuItem.Name = "MapPropertiesToolStripMenuItem"
        Me.MapPropertiesToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.MapPropertiesToolStripMenuItem.Text = "Map Properties"
        '
        'CheckpointsToolStripMenuItem
        '
        Me.CheckpointsToolStripMenuItem.Enabled = False
        Me.CheckpointsToolStripMenuItem.Name = "CheckpointsToolStripMenuItem"
        Me.CheckpointsToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.CheckpointsToolStripMenuItem.Text = "Checkpoints"
        '
        'SanityCheckToolStripMenuItem
        '
        Me.SanityCheckToolStripMenuItem.Enabled = False
        Me.SanityCheckToolStripMenuItem.Name = "SanityCheckToolStripMenuItem"
        Me.SanityCheckToolStripMenuItem.Size = New System.Drawing.Size(154, 22)
        Me.SanityCheckToolStripMenuItem.Text = "Sanity Check"
        '
        'grpStageProperties
        '
        Me.grpStageProperties.Controls.Add(Me.cmdSetDelayFrames)
        Me.grpStageProperties.Controls.Add(Me.txtDelayFrames)
        Me.grpStageProperties.Controls.Add(Me.chkDelayFlash)
        Me.grpStageProperties.Controls.Add(Me.lblDelayFrames)
        Me.grpStageProperties.Location = New System.Drawing.Point(413, 93)
        Me.grpStageProperties.Name = "grpStageProperties"
        Me.grpStageProperties.Size = New System.Drawing.Size(249, 37)
        Me.grpStageProperties.TabIndex = 28
        Me.grpStageProperties.TabStop = False
        Me.grpStageProperties.Text = "Stage Properties"
        Me.grpStageProperties.Visible = False
        '
        'cmdSetDelayFrames
        '
        Me.cmdSetDelayFrames.Location = New System.Drawing.Point(113, 13)
        Me.cmdSetDelayFrames.Name = "cmdSetDelayFrames"
        Me.cmdSetDelayFrames.Size = New System.Drawing.Size(40, 19)
        Me.cmdSetDelayFrames.TabIndex = 26
        Me.cmdSetDelayFrames.Text = "Set"
        Me.cmdSetDelayFrames.UseVisualStyleBackColor = True
        '
        'txtDelayFrames
        '
        Me.txtDelayFrames.Location = New System.Drawing.Point(78, 13)
        Me.txtDelayFrames.Name = "txtDelayFrames"
        Me.txtDelayFrames.Size = New System.Drawing.Size(33, 20)
        Me.txtDelayFrames.TabIndex = 25
        '
        'chkDelayFlash
        '
        Me.chkDelayFlash.AutoSize = True
        Me.chkDelayFlash.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkDelayFlash.Location = New System.Drawing.Point(157, 15)
        Me.chkDelayFlash.Name = "chkDelayFlash"
        Me.chkDelayFlash.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkDelayFlash.Size = New System.Drawing.Size(81, 17)
        Me.chkDelayFlash.TabIndex = 24
        Me.chkDelayFlash.Text = "Delay Flash"
        Me.chkDelayFlash.UseVisualStyleBackColor = True
        Me.chkDelayFlash.Visible = False
        '
        'lblDelayFrames
        '
        Me.lblDelayFrames.AutoSize = True
        Me.lblDelayFrames.Location = New System.Drawing.Point(6, 16)
        Me.lblDelayFrames.Name = "lblDelayFrames"
        Me.lblDelayFrames.Size = New System.Drawing.Size(71, 13)
        Me.lblDelayFrames.TabIndex = 14
        Me.lblDelayFrames.Text = "Delay Frames"
        Me.lblDelayFrames.Visible = False
        '
        'grpMode
        '
        Me.grpMode.Controls.Add(Me.chkSequenceEditor)
        Me.grpMode.Controls.Add(Me.radModeDraw)
        Me.grpMode.Controls.Add(Me.radModeSelect)
        Me.grpMode.Location = New System.Drawing.Point(12, 9)
        Me.grpMode.Name = "grpMode"
        Me.grpMode.Size = New System.Drawing.Size(138, 58)
        Me.grpMode.TabIndex = 3
        Me.grpMode.TabStop = False
        Me.grpMode.Text = "Mode"
        '
        'chkSequenceEditor
        '
        Me.chkSequenceEditor.AutoSize = True
        Me.chkSequenceEditor.Location = New System.Drawing.Point(6, 35)
        Me.chkSequenceEditor.Name = "chkSequenceEditor"
        Me.chkSequenceEditor.Size = New System.Drawing.Size(105, 17)
        Me.chkSequenceEditor.TabIndex = 22
        Me.chkSequenceEditor.Text = "Sequence Editor"
        Me.chkSequenceEditor.UseVisualStyleBackColor = True
        '
        'radModeDraw
        '
        Me.radModeDraw.AutoSize = True
        Me.radModeDraw.Checked = True
        Me.radModeDraw.Location = New System.Drawing.Point(6, 15)
        Me.radModeDraw.Name = "radModeDraw"
        Me.radModeDraw.Size = New System.Drawing.Size(50, 17)
        Me.radModeDraw.TabIndex = 5
        Me.radModeDraw.TabStop = True
        Me.radModeDraw.Text = "Draw"
        Me.radModeDraw.UseVisualStyleBackColor = True
        '
        'radModeSelect
        '
        Me.radModeSelect.AutoSize = True
        Me.radModeSelect.Location = New System.Drawing.Point(80, 15)
        Me.radModeSelect.Name = "radModeSelect"
        Me.radModeSelect.Size = New System.Drawing.Size(55, 17)
        Me.radModeSelect.TabIndex = 4
        Me.radModeSelect.Text = "Select"
        Me.radModeSelect.UseVisualStyleBackColor = True
        '
        'grpSequenceProperties
        '
        Me.grpSequenceProperties.Controls.Add(Me.lblTriggeringSwitch)
        Me.grpSequenceProperties.Controls.Add(Me.chkAlwaysOn)
        Me.grpSequenceProperties.Controls.Add(Me.chkLoop)
        Me.grpSequenceProperties.Controls.Add(Me.cmbDependsOnSequence)
        Me.grpSequenceProperties.Controls.Add(Me.lblDependsOnSequence)
        Me.grpSequenceProperties.Location = New System.Drawing.Point(413, 13)
        Me.grpSequenceProperties.Name = "grpSequenceProperties"
        Me.grpSequenceProperties.Size = New System.Drawing.Size(207, 70)
        Me.grpSequenceProperties.TabIndex = 27
        Me.grpSequenceProperties.TabStop = False
        Me.grpSequenceProperties.Text = "Sequence Properties"
        Me.grpSequenceProperties.Visible = False
        '
        'lblTriggeringSwitch
        '
        Me.lblTriggeringSwitch.AutoSize = True
        Me.lblTriggeringSwitch.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTriggeringSwitch.Location = New System.Drawing.Point(10, 53)
        Me.lblTriggeringSwitch.Name = "lblTriggeringSwitch"
        Me.lblTriggeringSwitch.Size = New System.Drawing.Size(144, 13)
        Me.lblTriggeringSwitch.TabIndex = 25
        Me.lblTriggeringSwitch.Text = "Triggering Switch: None"
        Me.lblTriggeringSwitch.Visible = False
        '
        'chkAlwaysOn
        '
        Me.chkAlwaysOn.AutoSize = True
        Me.chkAlwaysOn.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkAlwaysOn.Enabled = False
        Me.chkAlwaysOn.Location = New System.Drawing.Point(121, 35)
        Me.chkAlwaysOn.Name = "chkAlwaysOn"
        Me.chkAlwaysOn.Size = New System.Drawing.Size(76, 17)
        Me.chkAlwaysOn.TabIndex = 24
        Me.chkAlwaysOn.Text = "Always On"
        Me.chkAlwaysOn.UseVisualStyleBackColor = True
        Me.chkAlwaysOn.Visible = False
        '
        'chkLoop
        '
        Me.chkLoop.AutoSize = True
        Me.chkLoop.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkLoop.Location = New System.Drawing.Point(147, 13)
        Me.chkLoop.Name = "chkLoop"
        Me.chkLoop.Size = New System.Drawing.Size(50, 17)
        Me.chkLoop.TabIndex = 23
        Me.chkLoop.Text = "Loop"
        Me.chkLoop.UseVisualStyleBackColor = True
        Me.chkLoop.Visible = False
        '
        'cmbDependsOnSequence
        '
        Me.cmbDependsOnSequence.FormattingEnabled = True
        Me.cmbDependsOnSequence.Location = New System.Drawing.Point(43, 31)
        Me.cmbDependsOnSequence.Name = "cmbDependsOnSequence"
        Me.cmbDependsOnSequence.Size = New System.Drawing.Size(34, 21)
        Me.cmbDependsOnSequence.TabIndex = 14
        Me.cmbDependsOnSequence.Visible = False
        '
        'lblDependsOnSequence
        '
        Me.lblDependsOnSequence.AutoSize = True
        Me.lblDependsOnSequence.Location = New System.Drawing.Point(10, 16)
        Me.lblDependsOnSequence.Name = "lblDependsOnSequence"
        Me.lblDependsOnSequence.Size = New System.Drawing.Size(115, 13)
        Me.lblDependsOnSequence.TabIndex = 13
        Me.lblDependsOnSequence.Text = "Depends on sequence"
        Me.lblDependsOnSequence.Visible = False
        '
        'lblCoords
        '
        Me.lblCoords.AutoSize = True
        Me.lblCoords.Location = New System.Drawing.Point(287, 109)
        Me.lblCoords.Name = "lblCoords"
        Me.lblCoords.Size = New System.Drawing.Size(0, 13)
        Me.lblCoords.TabIndex = 2
        '
        'cmdEditContents
        '
        Me.cmdEditContents.Location = New System.Drawing.Point(798, 69)
        Me.cmdEditContents.Name = "cmdEditContents"
        Me.cmdEditContents.Size = New System.Drawing.Size(89, 19)
        Me.cmdEditContents.TabIndex = 26
        Me.cmdEditContents.Text = "Edit Contents"
        Me.cmdEditContents.UseVisualStyleBackColor = True
        Me.cmdEditContents.Visible = False
        '
        'grpLayerSelection
        '
        Me.grpLayerSelection.Controls.Add(Me.radLayerSprites)
        Me.grpLayerSelection.Controls.Add(Me.radLayerWalls)
        Me.grpLayerSelection.Controls.Add(Me.radLayerFixtures)
        Me.grpLayerSelection.Location = New System.Drawing.Point(164, 10)
        Me.grpLayerSelection.Name = "grpLayerSelection"
        Me.grpLayerSelection.Size = New System.Drawing.Size(126, 57)
        Me.grpLayerSelection.TabIndex = 4
        Me.grpLayerSelection.TabStop = False
        Me.grpLayerSelection.Text = "Layer Selection"
        '
        'radLayerSprites
        '
        Me.radLayerSprites.AutoSize = True
        Me.radLayerSprites.Location = New System.Drawing.Point(6, 34)
        Me.radLayerSprites.Name = "radLayerSprites"
        Me.radLayerSprites.Size = New System.Drawing.Size(57, 17)
        Me.radLayerSprites.TabIndex = 6
        Me.radLayerSprites.Text = "Sprites"
        Me.radLayerSprites.UseVisualStyleBackColor = True
        '
        'radLayerWalls
        '
        Me.radLayerWalls.AutoSize = True
        Me.radLayerWalls.Checked = True
        Me.radLayerWalls.Location = New System.Drawing.Point(6, 15)
        Me.radLayerWalls.Name = "radLayerWalls"
        Me.radLayerWalls.Size = New System.Drawing.Size(51, 17)
        Me.radLayerWalls.TabIndex = 5
        Me.radLayerWalls.TabStop = True
        Me.radLayerWalls.Text = "Walls"
        Me.radLayerWalls.UseVisualStyleBackColor = True
        '
        'radLayerFixtures
        '
        Me.radLayerFixtures.AutoSize = True
        Me.radLayerFixtures.Location = New System.Drawing.Point(62, 15)
        Me.radLayerFixtures.Name = "radLayerFixtures"
        Me.radLayerFixtures.Size = New System.Drawing.Size(61, 17)
        Me.radLayerFixtures.TabIndex = 4
        Me.radLayerFixtures.Text = "Fixtures"
        Me.radLayerFixtures.UseVisualStyleBackColor = True
        '
        'cmdSetProperty
        '
        Me.cmdSetProperty.Location = New System.Drawing.Point(917, 68)
        Me.cmdSetProperty.Name = "cmdSetProperty"
        Me.cmdSetProperty.Size = New System.Drawing.Size(46, 19)
        Me.cmdSetProperty.TabIndex = 23
        Me.cmdSetProperty.Text = "Set"
        Me.cmdSetProperty.UseVisualStyleBackColor = True
        Me.cmdSetProperty.Visible = False
        '
        'grpSelection
        '
        Me.grpSelection.Controls.Add(Me.picSelection)
        Me.grpSelection.Controls.Add(Me.lblSelection)
        Me.grpSelection.Location = New System.Drawing.Point(295, 15)
        Me.grpSelection.Name = "grpSelection"
        Me.grpSelection.Size = New System.Drawing.Size(112, 79)
        Me.grpSelection.TabIndex = 7
        Me.grpSelection.TabStop = False
        Me.grpSelection.Text = "Selected Tile"
        '
        'picSelection
        '
        Me.picSelection.BackColor = System.Drawing.Color.White
        Me.picSelection.Location = New System.Drawing.Point(6, 12)
        Me.picSelection.Name = "picSelection"
        Me.picSelection.Size = New System.Drawing.Size(64, 64)
        Me.picSelection.TabIndex = 5
        Me.picSelection.TabStop = False
        '
        'lblSelection
        '
        Me.lblSelection.AutoSize = True
        Me.lblSelection.Location = New System.Drawing.Point(76, 16)
        Me.lblSelection.Name = "lblSelection"
        Me.lblSelection.Size = New System.Drawing.Size(0, 13)
        Me.lblSelection.TabIndex = 6
        '
        'txtPropertyValue
        '
        Me.txtPropertyValue.Location = New System.Drawing.Point(914, 46)
        Me.txtPropertyValue.Name = "txtPropertyValue"
        Me.txtPropertyValue.Size = New System.Drawing.Size(52, 20)
        Me.txtPropertyValue.TabIndex = 22
        Me.txtPropertyValue.Visible = False
        '
        'lblSequence
        '
        Me.lblSequence.AutoSize = True
        Me.lblSequence.Location = New System.Drawing.Point(15, 70)
        Me.lblSequence.Name = "lblSequence"
        Me.lblSequence.Size = New System.Drawing.Size(63, 13)
        Me.lblSequence.TabIndex = 9
        Me.lblSequence.Text = "Sequence#"
        Me.lblSequence.Visible = False
        '
        'cmdDelStage
        '
        Me.cmdDelStage.Location = New System.Drawing.Point(209, 89)
        Me.cmdDelStage.Name = "cmdDelStage"
        Me.cmdDelStage.Size = New System.Drawing.Size(34, 19)
        Me.cmdDelStage.TabIndex = 21
        Me.cmdDelStage.Text = "Del"
        Me.cmdDelStage.UseVisualStyleBackColor = True
        Me.cmdDelStage.Visible = False
        '
        'cmbSequence
        '
        Me.cmbSequence.FormattingEnabled = True
        Me.cmbSequence.Location = New System.Drawing.Point(82, 68)
        Me.cmbSequence.Name = "cmbSequence"
        Me.cmbSequence.Size = New System.Drawing.Size(34, 21)
        Me.cmbSequence.TabIndex = 10
        Me.cmbSequence.Visible = False
        '
        'cmdDelSeq
        '
        Me.cmdDelSeq.Location = New System.Drawing.Point(82, 89)
        Me.cmdDelSeq.Name = "cmdDelSeq"
        Me.cmdDelSeq.Size = New System.Drawing.Size(34, 19)
        Me.cmdDelSeq.TabIndex = 20
        Me.cmdDelSeq.Text = "Del"
        Me.cmdDelSeq.UseVisualStyleBackColor = True
        Me.cmdDelSeq.Visible = False
        '
        'lblStage
        '
        Me.lblStage.AutoSize = True
        Me.lblStage.Location = New System.Drawing.Point(161, 71)
        Me.lblStage.Name = "lblStage"
        Me.lblStage.Size = New System.Drawing.Size(42, 13)
        Me.lblStage.TabIndex = 11
        Me.lblStage.Text = "Stage#"
        Me.lblStage.Visible = False
        '
        'cmdAddStage
        '
        Me.cmdAddStage.Location = New System.Drawing.Point(169, 89)
        Me.cmdAddStage.Name = "cmdAddStage"
        Me.cmdAddStage.Size = New System.Drawing.Size(34, 19)
        Me.cmdAddStage.TabIndex = 19
        Me.cmdAddStage.Text = "Add"
        Me.cmdAddStage.UseVisualStyleBackColor = True
        Me.cmdAddStage.Visible = False
        '
        'cmbStage
        '
        Me.cmbStage.FormattingEnabled = True
        Me.cmbStage.Location = New System.Drawing.Point(209, 68)
        Me.cmbStage.Name = "cmbStage"
        Me.cmbStage.Size = New System.Drawing.Size(34, 21)
        Me.cmbStage.TabIndex = 12
        Me.cmbStage.Visible = False
        '
        'cmdAddSeq
        '
        Me.cmdAddSeq.Location = New System.Drawing.Point(44, 89)
        Me.cmdAddSeq.Name = "cmdAddSeq"
        Me.cmdAddSeq.Size = New System.Drawing.Size(34, 19)
        Me.cmdAddSeq.TabIndex = 18
        Me.cmdAddSeq.Text = "Add"
        Me.cmdAddSeq.UseVisualStyleBackColor = True
        Me.cmdAddSeq.Visible = False
        '
        'lblMapChanges
        '
        Me.lblMapChanges.AutoSize = True
        Me.lblMapChanges.Location = New System.Drawing.Point(675, 15)
        Me.lblMapChanges.Name = "lblMapChanges"
        Me.lblMapChanges.Size = New System.Drawing.Size(73, 13)
        Me.lblMapChanges.TabIndex = 13
        Me.lblMapChanges.Text = "Map Changes"
        Me.lblMapChanges.Visible = False
        '
        'cmbPropertyValues
        '
        Me.cmbPropertyValues.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPropertyValues.FormattingEnabled = True
        Me.cmbPropertyValues.Location = New System.Drawing.Point(754, 45)
        Me.cmbPropertyValues.Name = "cmbPropertyValues"
        Me.cmbPropertyValues.Size = New System.Drawing.Size(153, 21)
        Me.cmbPropertyValues.TabIndex = 17
        Me.cmbPropertyValues.Visible = False
        '
        'cmbMapChanges
        '
        Me.cmbMapChanges.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMapChanges.FormattingEnabled = True
        Me.cmbMapChanges.Location = New System.Drawing.Point(754, 12)
        Me.cmbMapChanges.Name = "cmbMapChanges"
        Me.cmbMapChanges.Size = New System.Drawing.Size(218, 21)
        Me.cmbMapChanges.TabIndex = 14
        Me.cmbMapChanges.Visible = False
        '
        'lblPropertyValues
        '
        Me.lblPropertyValues.AutoSize = True
        Me.lblPropertyValues.Location = New System.Drawing.Point(675, 48)
        Me.lblPropertyValues.Name = "lblPropertyValues"
        Me.lblPropertyValues.Size = New System.Drawing.Size(81, 13)
        Me.lblPropertyValues.TabIndex = 16
        Me.lblPropertyValues.Text = "Property Values"
        Me.lblPropertyValues.Visible = False
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmbTileTypes)
        Me.SplitContainer2.Panel1.Controls.Add(Me.picTiles)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.HScrollBar1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.VScrollBar1)
        Me.SplitContainer2.Panel2.Controls.Add(Me.picMap)
        Me.SplitContainer2.Size = New System.Drawing.Size(1022, 447)
        Me.SplitContainer2.SplitterDistance = 348
        Me.SplitContainer2.TabIndex = 0
        '
        'cmbTileTypes
        '
        Me.cmbTileTypes.FormattingEnabled = True
        Me.cmbTileTypes.Location = New System.Drawing.Point(12, 29)
        Me.cmbTileTypes.Name = "cmbTileTypes"
        Me.cmbTileTypes.Size = New System.Drawing.Size(128, 21)
        Me.cmbTileTypes.TabIndex = 4
        '
        'picTiles
        '
        Me.picTiles.BackColor = System.Drawing.Color.White
        Me.picTiles.Location = New System.Drawing.Point(12, 56)
        Me.picTiles.Name = "picTiles"
        Me.picTiles.Size = New System.Drawing.Size(256, 399)
        Me.picTiles.TabIndex = 4
        Me.picTiles.TabStop = False
        '
        'HScrollBar1
        '
        Me.HScrollBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.HScrollBar1.Location = New System.Drawing.Point(0, 426)
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(654, 21)
        Me.HScrollBar1.TabIndex = 6
        '
        'VScrollBar1
        '
        Me.VScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VScrollBar1.Location = New System.Drawing.Point(654, 0)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(16, 447)
        Me.VScrollBar1.TabIndex = 5
        '
        'picMap
        '
        Me.picMap.BackColor = System.Drawing.Color.White
        Me.picMap.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picMap.Location = New System.Drawing.Point(0, 0)
        Me.picMap.Name = "picMap"
        Me.picMap.Size = New System.Drawing.Size(670, 447)
        Me.picMap.TabIndex = 0
        Me.picMap.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1022, 618)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "frmMain"
        Me.Text = "Entombed Map Editor"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel1.PerformLayout()
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.Panel2.PerformLayout()
        Me.SplitContainer3.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.grpStageProperties.ResumeLayout(False)
        Me.grpStageProperties.PerformLayout()
        Me.grpMode.ResumeLayout(False)
        Me.grpMode.PerformLayout()
        Me.grpSequenceProperties.ResumeLayout(False)
        Me.grpSequenceProperties.PerformLayout()
        Me.grpLayerSelection.ResumeLayout(False)
        Me.grpLayerSelection.PerformLayout()
        Me.grpSelection.ResumeLayout(False)
        Me.grpSelection.PerformLayout()
        CType(Me.picSelection, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.picTiles, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMap, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents picMap As System.Windows.Forms.PictureBox
    Friend WithEvents lblCoords As System.Windows.Forms.Label
    Friend WithEvents cmbTileTypes As System.Windows.Forms.ComboBox
    Friend WithEvents picTiles As System.Windows.Forms.PictureBox
    Friend WithEvents HScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents VScrollBar1 As System.Windows.Forms.VScrollBar
    Friend WithEvents grpMode As System.Windows.Forms.GroupBox
    Friend WithEvents radModeDraw As System.Windows.Forms.RadioButton
    Friend WithEvents radModeSelect As System.Windows.Forms.RadioButton
    Friend WithEvents grpLayerSelection As System.Windows.Forms.GroupBox
    Friend WithEvents radLayerSprites As System.Windows.Forms.RadioButton
    Friend WithEvents radLayerWalls As System.Windows.Forms.RadioButton
    Friend WithEvents radLayerFixtures As System.Windows.Forms.RadioButton
    Friend WithEvents grpSelection As System.Windows.Forms.GroupBox
    Friend WithEvents picSelection As System.Windows.Forms.PictureBox
    Friend WithEvents lblSelection As System.Windows.Forms.Label
    Friend WithEvents cmbPropertyValues As System.Windows.Forms.ComboBox
    Friend WithEvents lblPropertyValues As System.Windows.Forms.Label
    Friend WithEvents cmbMapChanges As System.Windows.Forms.ComboBox
    Friend WithEvents lblMapChanges As System.Windows.Forms.Label
    Friend WithEvents cmbStage As System.Windows.Forms.ComboBox
    Friend WithEvents lblStage As System.Windows.Forms.Label
    Friend WithEvents cmbSequence As System.Windows.Forms.ComboBox
    Friend WithEvents lblSequence As System.Windows.Forms.Label
    Friend WithEvents cmdDelStage As System.Windows.Forms.Button
    Friend WithEvents cmdDelSeq As System.Windows.Forms.Button
    Friend WithEvents cmdAddStage As System.Windows.Forms.Button
    Friend WithEvents cmdAddSeq As System.Windows.Forms.Button
    Friend WithEvents chkSequenceEditor As System.Windows.Forms.CheckBox
    Friend WithEvents txtPropertyValue As System.Windows.Forms.TextBox
    Friend WithEvents cmdSetProperty As System.Windows.Forms.Button
    Friend WithEvents cmdEditContents As System.Windows.Forms.Button
    Friend WithEvents grpStageProperties As System.Windows.Forms.GroupBox
    Friend WithEvents grpSequenceProperties As System.Windows.Forms.GroupBox
    Friend WithEvents cmbDependsOnSequence As System.Windows.Forms.ComboBox
    Friend WithEvents lblDependsOnSequence As System.Windows.Forms.Label
    Friend WithEvents chkLoop As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlwaysOn As System.Windows.Forms.CheckBox
    Friend WithEvents chkDelayFlash As System.Windows.Forms.CheckBox
    Friend WithEvents lblDelayFrames As System.Windows.Forms.Label
    Friend WithEvents txtDelayFrames As System.Windows.Forms.TextBox
    Friend WithEvents cmdSetDelayFrames As System.Windows.Forms.Button
    Friend WithEvents lblTriggeringSwitch As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadMapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveMapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents QuickSaveMapAsCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MultiSaveMapsAsCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MapPropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckpointsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SanityCheckToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewMapToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer

End Class
