﻿Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Module Helper

    ' This function is for creating a deep copy of an object or array of ojects.
    ' See http://stackoverflow.com/questions/15584053/deep-copy-of-an-object
    Function DeepClone(Of T)(ByRef orig As T) As T

        ' Don't serialize a null object, simply return the default for that object
        If (Object.ReferenceEquals(orig, Nothing)) Then Return Nothing

        Dim formatter As New BinaryFormatter()
        Dim stream As New MemoryStream()

        formatter.Serialize(stream, orig)
        stream.Seek(0, SeekOrigin.Begin)

        Return CType(formatter.Deserialize(stream), T)

    End Function

End Module
