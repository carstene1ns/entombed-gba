#ifndef __LAYER2TILELUT__
#define __LAYER2TILELUT__

extern const unsigned short layer2tileLUT[42];

#endif
