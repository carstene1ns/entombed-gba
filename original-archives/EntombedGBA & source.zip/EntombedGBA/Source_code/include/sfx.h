#ifndef SFX_H
#define SFX_H

#include <maxmod.h>
#include "soundbank.h"

extern mm_sound_effect title_bounce;

#endif
