#ifndef __LEVEL_DATA__
#define __LEVEL_DATA__

extern const unsigned char map_layer0[19200];
extern const unsigned char map_layer1[19200];
extern const unsigned char map_layer3[213];
extern const signed short map_layer1_properties[1351];
extern const signed short map_layer3_properties[479];
extern const signed short map_containers[151];
extern const signed short map_sequences[10086];
extern const signed short map_checkpoints[146];
extern const unsigned short map_mapProperties[3];
extern const char* map_description[1];
extern const unsigned int map_dataOffsets[30];

#endif

