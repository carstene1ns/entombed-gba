
//{{BLOCK(pal_oam)

//======================================================================
//
//	pal_oam, 256x128@4, 
//	+ palette 16 entries, not compressed
//	Total size: 32 = 32
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAL_OAM_H
#define GRIT_PAL_OAM_H

#define pal_oamPalLen 32
extern const unsigned short pal_oamPal[16];

#endif // GRIT_PAL_OAM_H

//}}BLOCK(pal_oam)
