
//{{BLOCK(tilemap_fixtures)

//======================================================================
//
//	tilemap_fixtures, 256x128@4, 
//	+ 512 tiles Metatiled by 4x2 not compressed
//	Total size: 16384 = 16384
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TILEMAP_FIXTURES_H
#define GRIT_TILEMAP_FIXTURES_H

#define tilemap_fixturesTilesLen 16384
extern const unsigned short tilemap_fixturesTiles[8192];

#endif // GRIT_TILEMAP_FIXTURES_H

//}}BLOCK(tilemap_fixtures)
