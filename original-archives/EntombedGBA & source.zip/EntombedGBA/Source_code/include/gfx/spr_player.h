
//{{BLOCK(spr_player)

//======================================================================
//
//	spr_player, 256x128@4, 
//	+ 512 tiles Metatiled by 4x4 not compressed
//	Total size: 16384 = 16384
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_PLAYER_H
#define GRIT_SPR_PLAYER_H

#define spr_playerTilesLen 16384
extern const unsigned short spr_playerTiles[8192];

#endif // GRIT_SPR_PLAYER_H

//}}BLOCK(spr_player)
