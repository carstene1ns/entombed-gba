
//{{BLOCK(spr_coinscores)

//======================================================================
//
//	spr_coinscores, 128x8@4, 
//	+ 16 tiles Metatiled by 4x1 not compressed
//	Total size: 512 = 512
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_COINSCORES_H
#define GRIT_SPR_COINSCORES_H

#define spr_coinscoresTilesLen 512
extern const unsigned short spr_coinscoresTiles[256];

#endif // GRIT_SPR_COINSCORES_H

//}}BLOCK(spr_coinscores)
