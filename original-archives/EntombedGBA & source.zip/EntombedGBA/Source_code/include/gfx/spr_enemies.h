
//{{BLOCK(spr_enemies)

//======================================================================
//
//	spr_enemies, 256x64@4, 
//	+ 256 tiles Metatiled by 4x4 not compressed
//	Total size: 8192 = 8192
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_ENEMIES_H
#define GRIT_SPR_ENEMIES_H

#define spr_enemiesTilesLen 8192
extern const unsigned short spr_enemiesTiles[4096];

#endif // GRIT_SPR_ENEMIES_H

//}}BLOCK(spr_enemies)
