
//{{BLOCK(spr_projectiles)

//======================================================================
//
//	spr_projectiles, 64x8@4, 
//	+ 8 tiles not compressed
//	Total size: 256 = 256
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_PROJECTILES_H
#define GRIT_SPR_PROJECTILES_H

#define spr_projectilesTilesLen 256
extern const unsigned short spr_projectilesTiles[128];

#endif // GRIT_SPR_PROJECTILES_H

//}}BLOCK(spr_projectiles)
