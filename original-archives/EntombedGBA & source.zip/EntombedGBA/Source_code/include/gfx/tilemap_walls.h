
//{{BLOCK(tilemap_walls)

//======================================================================
//
//	tilemap_walls, 256x80@4, 
//	+ 320 tiles Metatiled by 4x2 not compressed
//	Total size: 10240 = 10240
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TILEMAP_WALLS_H
#define GRIT_TILEMAP_WALLS_H

#define tilemap_wallsTilesLen 10240
extern const unsigned short tilemap_wallsTiles[5120];

#endif // GRIT_TILEMAP_WALLS_H

//}}BLOCK(tilemap_walls)
