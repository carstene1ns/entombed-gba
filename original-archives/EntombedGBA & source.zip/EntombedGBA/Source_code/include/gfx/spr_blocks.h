
//{{BLOCK(spr_blocks)

//======================================================================
//
//	spr_blocks, 96x16@4, 
//	+ 24 tiles Metatiled by 4x2 not compressed
//	Total size: 768 = 768
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_BLOCKS_H
#define GRIT_SPR_BLOCKS_H

#define spr_blocksTilesLen 768
extern const unsigned short spr_blocksTiles[384];

#endif // GRIT_SPR_BLOCKS_H

//}}BLOCK(spr_blocks)
