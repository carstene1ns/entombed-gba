
//{{BLOCK(spr_urn)

//======================================================================
//
//	spr_urn, 128x32@4, 
//	+ 64 tiles Metatiled by 4x4 not compressed
//	Total size: 2048 = 2048
//
//	Time-stamp: 2015-12-12, 10:40:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPR_URN_H
#define GRIT_SPR_URN_H

#define spr_urnTilesLen 2048
extern const unsigned short spr_urnTiles[1024];

#endif // GRIT_SPR_URN_H

//}}BLOCK(spr_urn)
