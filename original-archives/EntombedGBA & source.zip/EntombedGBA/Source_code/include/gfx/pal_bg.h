
//{{BLOCK(pal_bg)

//======================================================================
//
//	pal_bg, 256x16@8, 
//	Transparent palette entry: 0.
//	+ palette 32 entries, not compressed
//	Total size: 64 = 64
//
//	Time-stamp: 2015-06-25, 10:21:59
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.12
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAL_BG_H
#define GRIT_PAL_BG_H

#define pal_bgPalLen 64
extern const unsigned short pal_bgPal[32];

#endif // GRIT_PAL_BG_H

//}}BLOCK(pal_bg)
